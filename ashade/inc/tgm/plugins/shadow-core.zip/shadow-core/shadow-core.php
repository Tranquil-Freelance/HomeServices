<?php
/*
Plugin Name: Shadow Core (for Shadow Themes)
Plugin URI: https://shadow-themes.com
Description: Additional functional for Shadow Themes Only.
Version: 1.1.3
License: Themeforest
Author: Shadow Themes
Author URI: https://shadow-themes.com
*/

if ( ! defined( 'ABSPATH' ) ) exit;

# Begining Main Class
if ( ! class_exists( 'Shadow_Core' ) ) {
	# Define Plugin URL and PATH
	define( 'SHADOWCORE__FILE__', __FILE__ );
	define( 'SHADOWCORE_BASE', plugin_basename( SHADOWCORE__FILE__ ) );
	define( 'SHADOWCORE_PATH', plugin_dir_path( SHADOWCORE__FILE__ ) );
	define( 'SHADOWCORE_INC_PATH', SHADOWCORE_PATH . 'includes/' );
	define( 'SHADOWCORE_ASSETS_PATH', SHADOWCORE_PATH . 'assets/' );
	define( 'SHADOWCORE_URL', plugins_url( '/', SHADOWCORE__FILE__ ) );
	define( 'SHADOWCORE_ASSETS_URL', SHADOWCORE_URL . 'assets/' );

	class Shadow_Core {
		const VERSION = '1.1.3';

		# Properties
		protected static $config;
		public static $el_def;
		private static $seo_fields;

		# Methods
		private static $_instance = null;

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		public function init( $theme_config ) {
			# i18n
			load_plugin_textdomain( 'shadowcore' );

			# Add Image Sizes
			add_image_size( 'shadowcore-retina-thumb', 300, 300, true );
			add_image_size( 'shadowcore-fhd', 1920, 1280 );
			add_image_size( 'shadowcore-hhd', 960, 1200 );

			# Add Theme Name to Config
			self::$config[ 'theme_name' ] = $theme_config[ 'theme_name' ];
			self::$config[ 'base_class_name' ] = $theme_config[ 'base_class_name' ];

			# Enable Elementor in config, if enabled by theme
			if ( isset( $theme_config[ 'elementor' ] ) && is_array( $theme_config[ 'elementor' ] ) ) {
				self::$config[ 'elementor' ] = $theme_config[ 'elementor' ];
				# Elementor Defaults
				if ( array_key_exists( 'defaults', self::$config[ 'elementor' ] ) && is_array( self::$config[ 'elementor' ][ 'defaults' ] ) ) {
					self::$el_def = self::$config[ 'elementor' ][ 'defaults' ];
				} else {
					self::$el_def = false;
				}
			} else {
				self::$config[ 'elementor' ] = false;
			}

			# Enable Custom Widgets in config, if enabled by theme
			if ( isset( $theme_config[ 'widgets' ] ) && is_array( $theme_config[ 'widgets' ] ) ) {
				self::$config[ 'widgets' ] = $theme_config[ 'widgets' ];
			} else {
				self::$config[ 'widgets' ] = false;
			}

			# Enable Custom Post Types in config, if enabled by theme
			if ( isset( $theme_config[ 'cpt' ] ) && is_array( $theme_config[ 'cpt' ] ) ) {
				self::$config[ 'cpt' ] = $theme_config[ 'cpt' ];
			} else {
				self::$config[ 'cpt' ] = false;
			}

			# Enable MegaMenu in config, if enabled by theme
			if ( isset( $theme_config[ 'mega_menu' ] ) ) {
				self::$config[ 'mega_menu' ] = $theme_config[ 'mega_menu' ];
			} else {
				self::$config[ 'mega_menu' ] = false;
			}

			# Begin Loading
			self::loader();

			# Enqueue Scripts and Styles
			add_action( 'wp_enqueue_scripts', [ $this, 'shadow_core_enqueue'] );
			add_action( 'admin_enqueue_scripts', [ $this, 'shadow_core_enqueue_admin'] );

			# SEO and Analytics
			if ( get_theme_support( 'shadowcore-seo' ) ) {
				self::$seo_fields = array(
					# OG State
					'shadowcore-og-state' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Enable Open Graph Features', 'shadowcore' ),
						'description' => esc_attr__( 'This option enables basic "Open Graph" meta tags. But if you use any SEO plugins, like Yoast SEO, this option must be disabled.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
					),
					# OG:TYPE
					'shadowcore-og-type' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: Type', 'shadowcore' ),
						'description' => esc_attr__( 'Adds "og:type" as "article".', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# OG:TITLE
					'shadowcore-og-title' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: Title', 'shadowcore' ),
						'description' => esc_attr__( 'Generates "og:title" using the post/page title, if specified.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# OG:IMAGE
					'shadowcore-og-image' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: Image', 'shadowcore' ),
						'description' => esc_attr__( 'Generates "og:image" using the post/page featured image, if specified.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# OG:URL
					'shadowcore-og-url' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: URL', 'shadowcore' ),
						'description' => esc_attr__( 'Generates "og:url" using the post/page URL.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# OG:SITE_NAME
					'shadowcore-og-site-name' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: Site Name', 'shadowcore' ),
						'description' => esc_attr__( 'Generates "og:site_name" using the information from your Site Identity.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# OG:DESCRIPTION
					'shadowcore-og-descr' => array (
						'type' => 'switcher',
						'default' => false,
						'label' => esc_attr__( 'Open Graph: Description', 'shadowcore' ),
						'description' => esc_attr__( 'Generates "og:description" using the page excerpt, if specified.', 'shadowcore' ),
						'custom_class' => 'shadow-title-switcher',
						'condition' => array(
							'shadowcore-og-state' => true,
						)
					),
					# Code before the </HEAD>
					'shadowcore-code-head' => array (
						'type' => 'textarea',
						'default' => '',
						'label' => esc_attr__( 'Custom code before </HEAD>', 'shadowcore' ),
						'description' => esc_attr__( 'Can be used for Google Analytics, SEO, etc.', 'shadowcore' ),
						'callback' => 'wp_specialchars_decode',
						'divider' => Array(
							'position' => 'before',
						)
					),
					# Code before the </BODY>
					'shadowcore-code-body' => array (
						'type' => 'textarea',
						'default' => '',
						'label' => esc_attr__( 'Custom code before </BODY>', 'shadowcore' ),
						'description' => esc_attr__( 'This code will be placed at the very end of the site.', 'shadowcore' ),
						'callback' => 'wp_specialchars_decode'
					),
				);

				add_action( 'customize_register', [ $this, 'shadow_core_seo_customizer'] );
				add_action ( 'wp_head', function() {
					if ( get_theme_mod( 'shadowcore-og-state', self::$seo_fields[ 'shadowcore-og-state' ]['default'] ) ) {
						# OG:TYPE 
						if ( get_theme_mod( 'shadowcore-og-type', self::$seo_fields[ 'shadowcore-og-type' ]['default'] ) ) { 
							echo '<meta property="og:type" content="article" />';
						}
						# OG:TITLE 
						if ( get_theme_mod( 'shadowcore-og-title', self::$seo_fields[ 'shadowcore-og-title' ]['default'] ) ) { 
							echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '" />';
						}
						# OG:IMAGE
						if ( get_theme_mod( 'shadowcore-og-image', self::$seo_fields[ 'shadowcore-og-image' ]['default'] ) && has_post_thumbnail() ) { 
							$featured_image_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
							?>
							<meta property="og:image" content="<?php echo esc_url( wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' ) ); ?>" />
							<meta property="og:image:width" content="<?php echo esc_attr( $featured_image_meta[ 'width' ] ); ?>" />
							<meta property="og:image:height" content="<?php echo esc_attr( $featured_image_meta[ 'height' ] ); ?>" />
							<?php
						}
						# OG:URL
						if ( get_theme_mod( 'shadowcore-og-url', self::$seo_fields[ 'shadowcore-og-url' ]['default'] ) ) { 
							echo '<meta property="og:url" content="' . esc_url( get_site_url() ) . '" />';
						}
						# OG:SITE_NAME
						if ( get_theme_mod( 'shadowcore-og-site-name', self::$seo_fields[ 'shadowcore-og-site-name' ]['default'] ) ) { 
							echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '" />';
						}
						# OG:DESCRIPTION
						if ( get_theme_mod( 'shadowcore-og-descr', self::$seo_fields[ 'shadowcore-og-descr' ]['default'] ) ) { 
							if ( strlen( get_the_excerpt() && ! is_home() ) ) {
								echo '<meta property="og:description" content="' . esc_attr( get_the_excerpt() ) . '" />';
							} else {
								echo '<meta property="og:description" content="' . esc_attr( get_bloginfo( 'description' ) ) . '" />';
							}
						}
					}
					# Code Before the </HEAD>
					if ( '' !== get_theme_mod( 'shadowcore-code-head', self::$seo_fields[ 'shadowcore-code-head' ]['default'] ) ) {
						echo wp_specialchars_decode( get_theme_mod( 'shadowcore-code-head', self::$seo_fields[ 'shadowcore-code-head' ]['default'] ) );
					}
				});
				add_action ( 'wp_footer', function() {
					# Code Before the </BODY>
					if ( '' !== get_theme_mod( 'shadowcore-code-body', self::$seo_fields[ 'shadowcore-code-body' ]['default'] ) ) {
						echo wp_specialchars_decode( get_theme_mod( 'shadowcore-code-body', self::$seo_fields[ 'shadowcore-code-body' ]['default'] ) );
					}
				});
			}
		}
		public static function shadow_core_seo_customizer( $wp_customize ) {
			if ( class_exists( 'Shadow_Customizer' ) ) {
				$shadow_customize = new Shadow_Customizer;
			}
			$section_id = 'shadowcore_seo_section';
			$wp_customize->add_section( $section_id, array(
				'name' => $section_id,
				'title' => esc_attr__( 'Open Graph and Analytics', 'shadowcore' ),
			));
			foreach( self::$seo_fields as $id => $item ) {
				if ( empty( $item['callback'] ) ) {
					$callback = 'esc_attr';
				} else {
					$callback = $item['callback'];
				}
				$wp_customize->add_setting( $id, array(
					'default' => $item['default'],
					'capability' => 'edit_theme_options',
					'transport' => 'refresh',
					'sanitize_callback' => $callback
				));
				$shadow_customize->add_field( $wp_customize, $id, $item, $section_id );
			}
		}
		public function shadow_core_enqueue() {
			# Enqueue Styles
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );

			# Enqueue Scripts
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery', 'jquery-ui-core', 'jquery-ui-slider', 'jquery-ui-draggable'), false, true);
		}

		public function shadow_core_enqueue_admin() {
			# Enqueue Styles
			wp_enqueue_style( 'shadow-core-admin-css', SHADOWCORE_ASSETS_URL . 'css/shadow-core-admin.css' );
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );

			# Enqueue Scripts
			wp_enqueue_media();
			wp_enqueue_script('shadow-media-upload', SHADOWCORE_ASSETS_URL . 'js/shadow-media-upload.js', array( 'jquery', 'media-upload', 'thickbox' )) ;
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery', 'jquery-ui-core', 'jquery-ui-slider', 'iris'), false, true);
		}

		public static function loader() {
			# Load Files
			require_once( SHADOWCORE_INC_PATH . 'ajax.php' );

			# Load Customizer Controls
			require_once( SHADOWCORE_INC_PATH . 'controls/control-choose.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-dimension.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-divider.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-number.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-switcher.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-title.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-typography.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-indents.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-border.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-multicolor.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-socials.php' );
			require_once( SHADOWCORE_INC_PATH . 'controls/control-multi-switcher.php' );

			# Activate Shadow Customizer
			require_once( SHADOWCORE_INC_PATH . 'classes/class-customizer.php' );

			# Activate Elementor Addons
			if ( self::$config['elementor'] && is_array( self::$config['elementor'] ) )	{
				if ( did_action( 'elementor/loaded' ) ) {
					require_once( SHADOWCORE_INC_PATH . 'classes/class-elementor.php' );
				}
			}

			# Activate Sidebar Widgets
			if ( self::$config['widgets'] && is_array( self::$config['widgets'] ) ) {
				foreach( self::$config['widgets'] as $name ) {
					require_once( SHADOWCORE_INC_PATH . 'widgets/widget-'. $name .'.php' );
				}
			}

			# Register Custom Post Types
			if ( self::$config['cpt'] && is_array( self::$config['cpt'] ) ) {
				$el_cpt_support = get_option( 'elementor_cpt_support' );
				if ( ! $el_cpt_support ) {
					$el_cpt_support = ['page', 'post'];
				}

				foreach ( self::$config['cpt'] as $cpt_config )	{
					register_post_type( $cpt_config['cpt_name'], $cpt_config['cpt_config'] );
					
					if ( array_key_exists('cpt_el', $cpt_config) && $cpt_config['cpt_el'] === true ) {
						if( ! in_array( $cpt_config['cpt_name'], $el_cpt_support ) ) {
							$el_cpt_support[] = $cpt_config['cpt_name'];
						}
					}

					if ( isset( $cpt_config['cpt_tax'] ) ) {
						register_taxonomy( $cpt_config['cpt_tax']['tax_name'], $cpt_config['cpt_tax']['tax_post_name'], $cpt_config['cpt_tax']['tax_array'] );

						# Category Images
						if ( isset( $cpt_config[ 'cpt_tax_thumbnail' ] ) && $cpt_config[ 'cpt_tax_thumbnail' ] === true) {							
							$tax_name = $cpt_config['cpt_tax']['tax_name'];
							$tax_args = Array(
								'tax_name' => $tax_name,
							);
							# Add Image Field
							add_action( $tax_name . '_add_form_fields', 'shadowcore_add_category_fields', 10, 2 );
							add_action( $tax_name . '_edit_form_fields', 'shadowcore_edit_category_fields', 10, 2 );
							
							# Edit and Save Image Field
							add_action( 'created_term', 'shadowcore_save_category_fields', 10, 2 );
							add_action( 'edit_term', 'shadowcore_save_category_fields', 10, 2 );
						}
					}
				}

				update_option( 'elementor_cpt_support', $el_cpt_support ); 
			}
		}
	}		
}

# Add Category Image Functions
if ( ! function_exists( 'shadowcore_add_category_fields' ) ) {
	function shadowcore_add_category_fields( $taxonomy ) {
		?>
		<div class="shadow-categ-image-wrap">
			<label><?php esc_html_e( 'Category Image', 'shadowcore' ); ?></label>
			<div class="shadow-media-control"
				data-title="<?php esc_attr_e( 'Choose Image', 'shadowcore' ); ?>"
				data-update-text="<?php esc_attr_e( 'Update Image', 'shadowcore' ); ?>"
				data-target=".shadow-image-id"
				data-remove="<?php esc_attr_e( 'Remove Image', 'shadowcore' ); ?>"
				data-select-multiple="false">
				
				<input type="hidden" id="<?php echo esc_attr( $taxonomy );?>_thumb_id" name="<?php echo esc_attr( $taxonomy );?>_thumb_id" class="shadow-image-id shadow-media-control-target"/>
				<span class="shadow-image-select-wrap"></span>
				<div class="shadow-categ-image--tools">
					<?php
					echo '<a href="#" 
							data-caption-select="'. esc_attr__( 'Select Image', 'shadowcore' ) .'"
							data-caption-change="'. esc_attr__( 'Change Image', 'shadowcore' ) .'"
							class="button shadow-media-control-choose">'. esc_html__( 'Select Image', 'shadowcore' ) .'</a>';
					?>
				</div><!-- .shadow-categ-image--add -->
			</div><!-- .shadow-media-control -->
		</div><!-- .shadow-categ-image-wrap -->
		<?php
	}
}
if ( ! function_exists( 'shadowcore_edit_category_fields' ) ) {
	function shadowcore_edit_category_fields( $term, $taxonomy ) {
		$thumb_id = absint( get_term_meta( $term->term_id, 'thumb_id', true ) );
		if ( $thumb_id ) {
			$image = wp_get_attachment_thumb_url( $thumb_id );
		} else {
			$image = false;
		}
		?>
		<tr class="form-field category-thumb-wrap">
			<th scope="row" valign="top">
				<label><?php esc_html_e( 'Category Image', 'shadowcore' ); ?></label>
			</th>
			<td>
				<div class="shadow-categ-image-wrap">
					<div class="shadow-media-control"
						data-title="<?php esc_attr_e( 'Choose Image', 'shadowcore' ); ?>"
						data-update-text="<?php esc_attr_e( 'Update Image', 'shadowcore' ); ?>"
						data-target=".shadow-image-id"
						data-remove="<?php esc_attr_e( 'Remove Image', 'shadowcore' ); ?>"
						data-select-multiple="false">

						<input type="hidden" id="<?php echo esc_attr( $taxonomy );?>_thumb_id" name="<?php echo esc_attr( $taxonomy );?>_thumb_id" value="<?php echo esc_attr( $thumb_id ); ?>" class="shadow-image-id shadow-media-control-target"/>
						<span class="shadow-image-select-wrap"><?php 
						if ( ! empty ( $thumb_id ) ) {
							echo wp_get_attachment_image( $thumb_id, 'thumbnail', false );
						}
						?></span>
						<div class="shadow-categ-image--tools">
							<?php
							if ( ! empty ( $thumb_id ) ) {
								echo '<a href="#" class="button shadow-media-control-remove">'. esc_attr__( 'Remove Image', 'shadowcore' ) .'</a>';
							}
							echo '<a href="#" 
								data-caption-select="'. esc_attr__( 'Select Image', 'shadowcore' ) .'"
								data-caption-change="'. esc_attr__( 'Change Image', 'shadowcore' ) .'"
								class="button shadow-media-control-choose">
								'. (empty ( $thumb_id ) ? esc_html__( 'Select Image', 'shadowcore' ) : esc_html__( 'Change an Image', 'shadowcore' ) ) .'
							</a>';
							?>
						</div><!-- .shadow-categ-image--add -->
					</div><!-- .shadow-media-control -->
				</div><!-- .shadow-categ-image-wrap -->
			</td>
		</tr>
		<?php
	}
}
if ( ! function_exists( 'shadowcore_save_category_fields' ) ) {
	function shadowcore_save_category_fields( $term_id ) {
		if ( isset( $_POST[ 'taxonomy' ] ) ) {
			$tax_name = $_POST['taxonomy'];
			if ( isset( $_POST[ $tax_name . '_thumb_id' ] ) && $_POST[ $tax_name . '_thumb_id' ] !== '' ) {
				update_term_meta( $term_id, 'thumb_id', absint( $_POST[ $tax_name . '_thumb_id' ] ) );
			}
		}
	}
}

# Get Elementor Widget Defaults
if ( ! function_exists( 'shadowcore_get_widget_defaults' ) ) {
	function shadowcore_get_widget_defaults( $id ) {
		$def = Shadow_Core::$el_def;
		if ( $def && array_key_exists( $id, $def ) ) {
			return $def[ $id ];
		} else {
			return Array();
		}		
	}
}

# Author Notify Function
if ( ! function_exists( 'shadowcore_proofing_notify' ) ) {
	add_action('wp_ajax_shadowcore_proofing_notify', 'shadowcore_proofing_notify');
	add_action('wp_ajax_nopriv_shadowcore_proofing_notify', 'shadowcore_proofing_notify');
	
	function shadowcore_proofing_notify() {
		$client_data = $_POST[ 'client_data' ];
		
		# Demo Mode
		if ( 'demo' == $client_data[ 'mailto' ] ) {
			die( esc_html( $client_data[ 'done_message' ] ) . ' ' . esc_html__( 'Demo Mode.', 'shadowcore' ) );
		}
		
		# Images Link
		$notify_message = $client_data['message'] . ' <a href="' . esc_url( $client_data['url'] ) . '" target="_blank">' . esc_html( $client_data['title'] ) . '</a>';
		if ( 'yes' == $client_data[ 'includes' ] ) {
			$notify_message .= "\n\r" . '<hr>';
			$notify_message .= "\n\r" . '<h4>' . esc_html( $client_data[ 'photos_title' ] ) . '</h4>' . "\n\r";
			if ( is_array( $client_data[ 'images' ] ) && ! empty( $client_data[ 'images' ] ) ) {
				$notify_message .= '<ul>';
				foreach ( $client_data[ 'images' ] as $image_id ) {
					$image_post = get_post( $image_id );
					$image_title = $image_post->post_title;
					$image_url = wp_get_attachment_url( $image_id );
					$notify_message .= '<li><a href="' . esc_url( $image_url ) . '" target="_blank">' . esc_html( $image_title ) . '</a></li>' . "\n\r";
				}
				$notify_message .= '</ul>';
			} else {
				$notify_message .= "\n\r" . $client_data[ 'no_photos' ] . "\n\r";
			}
		}
		
		# Email Headers
        $headers = 	"From: " . get_bloginfo( 'admin_email' ) . "\r\n" . 
					"MIME-Version: 1.0" . "\r\n" . 
					"Content-type: text/html; charset=utf-8" . "\r\n";
		
		# Send Notify Email
		if( wp_mail( $client_data[ 'mailto' ], $client_data[ 'subject' ], $notify_message, $headers ) ) {
			# Success
			echo esc_html( $client_data[ 'done_message' ] );
		} else {
			# Error
			echo esc_html( $client_data[ 'error_message' ] );
		}
		
		# Exit
		die();
	}
}

# Debug Functions
if ( ! function_exists( 'print_pre' ) ) {
	function print_pre ( $array = Array() ) {
		echo '<pre>';
		print_r( $array );
		echo '</pre>';
	}
}