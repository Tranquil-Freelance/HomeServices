<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_MultiSwitcher_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_MultiSwitcher_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'm-switcher'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
		# Display Control Content
		public function render_content() {
            
            # Get Config and define Defs
            $this_config = $this->config;
            $this_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
			$this_list = Array();
			
			if ( array_key_exists( 'list', $this_config ) && is_array( $this_config[ 'list' ] ) ) {
                $list = $this_config[ 'list' ];
            } else {
				echo "Multi Switcher List Error for #" . $this->id;
			}
            
            if ( ! is_array( $this_values ) || ! is_array( $this_list ) ) {
                echo "Socials Values Error for #" . $this->id;
            }
			
            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) . '</span>';
            endif;

			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-m-switcher-wrapper cc-socials--<?php echo esc_attr( $type ); ?>">
                  	<?php
					if ( is_array( $list ) ) {
						foreach ( $list as $id => $item ) {
							if ( '-' == $item ) {
								echo '<hr>';
							} else {
							?>
							<div class="cc-m-switch-item <?php echo esc_attr( $this_values[ $id ] ? 'is-active' : '' ); ?>" data-id="<?php echo esc_attr( $id ); ?>">
								<span><?php echo esc_attr__( $item ); ?></span>
							</div>
							<?php
							}
						}
					} else {
						echo "Socials List is Empty for #" . $this->id;
					}
                    ?>
                    <input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
				</div><!-- .cc-m-switcher-wrapper -->
			</div><!-- .customize-control-content -->
			<?php
		}
	}
endif;