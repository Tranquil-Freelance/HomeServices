<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_Number_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_Number_Control extends WP_Customize_Control {
		# Set Type
		public $options = array();
		public $custom_class = '';
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'jquery-ui-slider', array( 'jquery' ) );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array( 'jquery', 'jquery-ui-slider' ), false, true) ;
    	}
        
		# Get Input Field
		private function get_number_field( $type = false, $value = '', $min = 0, $max = 100, $step = 1 ) {
			$id = $type[0];
			echo '
			<div class="cc-number-input ' . ( $type ? 'responsive-input--' . $type : '' ) . '"' . ( $id ? ' data-id="' . esc_attr( $id ) . '"' : '' ) . '>
                <input type="number" value="' . esc_attr( $value ) . '" class="cc-number-value'. ( $type ? '--' . $type : '' ) .'" '. ( $min !== false ? 'min="'. esc_attr( $min ) .'"' : '' ) .' '. ( $max !== false ? 'max="'. esc_attr( $max ) .'"' : '' ) .' '. ( $step !== false ? 'step="'. esc_attr( $step ) .'"' : '' ) .'>
            </div><!-- .cc-number-input -->';
		}
		
		# Get Slider Field
		private function get_number_slider( $type = false, $value = '', $min = 0, $max = 100, $step = 1 ) {
			$id = $type[0];
			echo '
			<div class="cc-slider-input ' . ( $type ? 'responsive-input--' . $type : '' ) . '"' . ( $id ? ' data-id="' . esc_attr( $id ) . '"' : '' ) . '>
                <div class="cc-slider-wrap"' . ( $step !== '' ? ' data-step="'. esc_attr( $step ) .'"' : '' ) . '></div>
                <input type="number" value="' . esc_attr( $value ) . '" class="cc-slider-value'. ( $type ? '--' . $type : '' ) .'" '. ( $min !== false ? 'min="'. esc_attr( $min ) .'"' : '' ) .' '. ( $max !== false ? 'max="'. esc_attr( $max ) .'"' : '' ) .' '. ( $step !== false ? 'step="'. esc_attr( $step ) .'"' : '' ) .'>
            </div><!-- .cc-slider-input-wrap -->';
		}
		
		# Display Control Content
		public function render_content() {
			$responsive = false;
			$units = false;
			$this_value = false;
			$this_defaults = false;
			
			if ( isset( $this->options[ 'responsive' ] ) ) {
                $responsive = $this->options[ 'responsive' ];
            }
			if ( $responsive ) {
				$this_value = json_decode( stripslashes( html_entity_decode( $this->value() ) ), true );
				$this_defaults = json_decode( stripslashes( html_entity_decode( $this->setting->default ) ), true );
			} else {
				$this_value = $this->value();
				$this_defaults = $this->setting->default;
			}
			
			if ( isset( $this->options[ 'units' ] ) ) {
                $units = $this->options[ 'units' ];
            }
			
			if ( !empty( $this->label ) ) :
				echo '<span class="customize-control-title">'. esc_html( $this->label ) .'</span>';
			endif;
			
			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
            
            if ( isset( $this->options[ 'min' ] ) && !empty( $this->options[ 'min' ] ) ) {
                $min = $this->options[ 'min' ];
            } else {
                $min = '0';
            }
            
            if ( isset( $this->options[ 'max' ] ) && !empty( $this->options[ 'max' ] ) ) {
                $max = $this->options[ 'max' ];
            } else {
                $max = '100';
            }
            
            if ( isset( $this->options[ 'step' ] ) && !empty( $this->options[ 'step' ] ) ) {
                $step = $this->options[ 'step' ];
            } else {
                $step = '1';
            }
			
			if ( ! $responsive ) {
				# Old Simple Number
				if ( isset( $this->options[ 'style' ] ) && $this->options[ 'style' ] == 'slider' ) {
					?>
					<div class="customize-control-content customize-control-slider" <?php echo ( $this->custom_class !== '' ? 'data-class=" '. esc_attr( $this->custom_class ) .' "' : '' ) ?> data-default="<?php echo $this->setting->default; ?>">
						<span class="cc-number-reset" title="<?php echo esc_attr__( 'Reset to default', 'shadowcore' ); ?>"><?php echo esc_html__( 'Default', 'shadowcore' ); ?></span>
						<div class="cc-number-slider" <?php echo ( $step !== '' ? 'data-step="'. esc_attr( $step ) .'"' : '' ); ?>></div>
						<div class="cc-number-value-wrapper">
							<input type="number" <?php $this->link(); ?> class="cc-number-value" value="<?php echo $this->value(); ?>" <?php echo ( $min !== '' ? 'min="'. esc_attr( $min ) .'"' : '' ); ?> <?php echo ( $max !== '' ? 'max="'. esc_attr( $max ) .'"' : '' ); ?> <?php echo ( $step !== '' ? 'step="'. esc_attr( $step ) .'"' : '' ); ?>/>
						</div>
					</div><!-- .customize-control-content -->
					<?php
				} else {
					?>
					<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
						<input type="number" <?php $this->link(); ?> class="cc-number-value" value="<?php echo $this->value(); ?>" <?php echo ( $min !== '' ? 'min="'. esc_attr( $min ) .'"' : '' ); ?> <?php echo ( $max !== '' ? 'max="'. esc_attr( $max ) .'"' : '' ); ?> <?php echo ( $step !== '' ? 'step="'. esc_attr( $step ) .'"' : '' ); ?>/>
					</div><!-- .customize-control-content -->
					<?php
				}
			} else {
				# New Responsive Number
				?>
				<div class="customize-control-content cc-responsive-number" <?php echo ( $this->custom_class !== '' ? 'data-class=" '. esc_attr( $this->custom_class ) .' "' : '' ) ?>>
					<div class="cc-responsive-control-wrap">
						<div class="cc-responsive-control-states">
							<a href="#" class="responsive-control-state is-active" data-state="desktop">
								<i class="dashicons dashicons-desktop"></i>
							</a>
							<a href="#" class="responsive-control-state" data-state="tablet">
								<i class="dashicons dashicons-tablet"></i>
							</a>
							<a href="#" class="responsive-control-state" data-state="mobile">
								<i class="dashicons dashicons-smartphone"></i>
							</a>
						</div>
						<?php
						$d_value = array_key_exists( 'd', $this_value ) ? $this_value['d'] : '';
						$t_value = array_key_exists( 't', $this_value ) ? $this_value['t'] : '';
						$m_value = array_key_exists( 'm', $this_value ) ? $this_value['m'] : '';
				
						if ( isset( $this->options[ 'style' ] ) && $this->options[ 'style' ] == 'slider' ) {
							$this->get_number_slider( 'desktop', $d_value, $min, $max, $step );
							$this->get_number_slider( 'tablet', $t_value, $min, $max, $step );
							$this->get_number_slider( 'mobile', $m_value, $min, $max, $step );
						} else {
							$this->get_number_field( 'desktop', $d_value, $min, $max, $step );
							$this->get_number_field( 'tablet', $t_value, $min, $max, $step );
							$this->get_number_field( 'mobile', $m_value, $min, $max, $step );
						}
						?>
					</div><!-- .cc-responsive-control-wrap -->
					<input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
            	</div><!-- .customize-control-content -->
				<?php
			}   
		}
	}
endif;