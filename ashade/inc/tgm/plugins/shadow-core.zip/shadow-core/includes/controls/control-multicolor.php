<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_MultiColor_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_MultiColor_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'color'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
		# Display Control Content
		public function render_content() {
            
            # Get Config and define Defs
            $this_config = $this->config;
            
            if ( ! is_array( $this_config[ 'colors' ] ) ) {
                # Throw the Error if list is empty
                echo "Color List Error for #" . $this->id;
                return;
            } else {
                $colors = $this_config[ 'colors' ];
            }
            
            $this_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
            $this_defaults = json_decode(stripslashes(html_entity_decode($this->setting->default)), true);
            $hasValues = false;
            
            if ( is_array( $this_values ) ) {
                $hasValues = true;
            } else {
                $this_values = Array();
            }
            $toggler = 'no';
            $reset = 'reset';
            
            if ( array_key_exists( 'toggler', $this_config ) && $this_config[ 'toggler' ] ) {
                $toggler = 'off';
                if ( array_key_exists( 'toggled', $this_values ) ) {
                    $toggler = $this_values[ 'toggled' ];
                }
            }
            if ( array_key_exists( 'reset', $this_config ) && 'defaults' == $this_config[ 'reset' ] ) {
                $reset = 'defaults';
            }
            
            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) . ( $toggler !== 'no' ? '<a href="#" class="cc-multicolor-toggler '. ( $toggler == 'on' ? 'is-active' : '' ) .'"></a>' : '' ) . '</span>';
            endif;

			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-multi-color-wrapper <?php echo esc_attr( $toggler !== 'no' ? 'has-toggler' : '' ); ?>">
                    <?php
                    foreach ( $colors as $id => $title ) {
                        ?>
                        <div class="cc-multicolor-item <?php echo ( $hasValues && array_key_exists( $id, $this_values ) ? 'has-value' : 'no-value' ); ?>">
                            <div class="cc-multicolor-item--head">
                                <?php
                                    if ( is_array( $title ) ) {
                                        echo '<label>'. esc_html( $title[ 'title' ] ) .'<span>'. esc_html( $title[ 'descr' ] ) .'</span></label>';
                                    } else {
                                        echo '<label>'. esc_html( $title ) .'</label>';
                                    }
                                ?>
                                <div class="cc-multicolor-item--tools">
                                    <a href="#" class="cc-multicolor-item--clear" <?php echo 'defaults' == $reset ? 'data-defaults="'. esc_attr( $this_defaults[ $id ] ) .'"' : ''; ?>>
                                        <i class="dashicons dashicons-no-alt"></i>
                                    </a>
                                    <div class="cc-multicolor-item--preview" data-color="<?php echo esc_attr( $hasValues && array_key_exists( $id, $this_values ) ? $this_values[ $id ] : '' ); ?>"></div>
                                </div><!-- .cc-multicolor-item--tools -->
                            </div><!-- .cc-multicolor-item--head -->
                            <div class="cc-multicolor-item--body">
                                <input class="cc-multiclor-item--input" type="text" data-id="<?php echo esc_attr( $id ); ?>" maxlength="7" placeholder="#" <?php echo ( $hasValues && array_key_exists( $id, $this_values ) ? 'value="'. $this_values[ $id ] .'"' : '' ); ?> />
                            </div><!-- .cc-multicolor-item--body -->
                        </div>
                        <?php
                    }
                    ?>
                    <input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
				</div><!-- .cc-indents-wrapper -->
			</div><!-- .customize-control-content -->
			<?php
		}
	}
endif;