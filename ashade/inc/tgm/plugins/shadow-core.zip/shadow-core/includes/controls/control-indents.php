<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_Indents_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_Indents_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'indents'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
        # Generate Indetns Field
        private function get_indents_field( $values = '', $locked = '', $class = '', $pattern = false ) {
            if ( strpos( $values, 'x' ) === false ) {
                $values_arr = array( $values, $values, $values, $values );
            } else {
                $values_arr = explode( 'x', $values );
            }
            
            if ( is_array( $pattern ) ) {
                $d_values = $pattern;
            } else {
                $d_values = $values_arr;
            }
            
            return '
            <ul class="shadow-indents-field-wrap '. ( $locked ? 'is-locked' : '') .' '. esc_attr($class !== '' ? 'responsive-input--' . $class : '') .'" data-type="'. esc_attr( $class ) .'">
                <li>
                    <input type="number" data-pos="t" '. ( $d_values[0] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[0] !== 'd' && $values_arr[0] !== 'n' ? $values_arr[0] : '' ) .'">
                    <label>'. esc_html__( 'Top', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="r" '. ( $d_values[1] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[1] !== 'd' && $values_arr[1] !== 'n' ? $values_arr[1] : '' ) .'">
                    <label>'. esc_html__( 'Right', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="b" '. ( $d_values[2] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[2] !== 'd' && $values_arr[2] !== 'n' ? $values_arr[2] : '' ) .'">
                    <label>'. esc_html__( 'Bottom', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="l" '. ( $d_values[3] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[3] !== 'd' && $values_arr[3] !== 'n' ? $values_arr[3] : '' ) .'">
                    <label>'. esc_html__( 'Left', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <a href="#" class="shadow-indents-field-lock">
                        <i class="dashicons dashicons-lock"></i>
                        <i class="dashicons dashicons-unlock"></i>
                    </a>
                </li>
            </ul>
            <!-- .shadow-indents-field-wrap -->
            ';
        }
        
        # Get Responsive Field
        private function get_responsive_field( $id, $values = false, $locked = '1/1/1' ) {
            $dom = '';
            $values_arr = Array(
                'd' => '',
                't' => '',
                'm' => ''
            );
            $pattern = false;
            if ( $values ) {
                $multi = strpos( $values, '/' );
                if ( $multi === false ) {
                    $values_arr['d'] = $values;
                    $hasPattern = strpos( $values, 'd' );
                    if ( $hasPattern === false) {
                        $pattern = false;                        
                    } else {
                        $pattern = explode( 'x', $values );
                        if ( count( $pattern ) !== 4 ) {
                            $pattern = false;
                        }
                    }
                } else {
                    $values_exp = explode( '/', $values );
                    
                    if ( count( $values_exp ) !== 3) {
                        return 'Values Array Error for: ' . $id;
                    } else {
                        $values_arr['d'] = $values_exp[0];
                        $values_arr['t'] = $values_exp[1];
                        $values_arr['m'] = $values_exp[2];
                    }
                }
            }
            $locked_arr = explode( '/', $locked );
            $dom .= '
            <div class="cc-responsive-control-wrap" data-id="'. esc_attr( $id ) .'">
                <div class="cc-responsive-control-states">
                    <a href="#" class="responsive-control-state is-active" data-state="desktop">
                        <i class="dashicons dashicons-desktop"></i>
                    </a>
                    <a href="#" class="responsive-control-state" data-state="tablet">
                        <i class="dashicons dashicons-tablet"></i>
                    </a>
                    <a href="#" class="responsive-control-state" data-state="mobile">
                        <i class="dashicons dashicons-smartphone"></i>
                    </a>
                </div>';
            $dom .= $this->get_indents_field( $values_arr['d'], $locked_arr[0], 'desktop', $pattern);
            $dom .= $this->get_indents_field( $values_arr['t'], $locked_arr[1], 'tablet', $pattern);
            $dom .= $this->get_indents_field( $values_arr['m'], $locked_arr[2], 'mobile', $pattern);
            $dom .= '
            </div><!-- .cc-responsive-control-wrap -->';
            return $dom;
        }
        
		# Display Control Content
		public function render_content() {
            
            # Get Config and define Defs
            $config_defs = Array(
                'hide_p' => false,
                'hide_m' => false,
                'p_label' => true,
                'm_label' => true,
            );
            
            if ( is_array( $this->config ) ) {
				foreach ($this->config as $i => $v) {
                    $config_defs[ $i ] = $v;
                }
            }

            # Create Default Values
            $current_obj = array(
                'p' => '',
                'p_lock' => '1/1/1',
                'm' => '',
                'm_lock' => '1/1/1'
            );
            
            # Get Current Values
            $current_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
            if ( is_array( $current_values ) ) {
                foreach ( $current_values as $i => $value ) {
                    $current_obj[ $i ] = $value;
                }
            }

            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) .'</span>';
            endif;
            ?>
            <?php
			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-indents-wrapper">
                    <?php
                    if ( ! $config_defs[ 'hide_p' ] ) {
                        if ( $config_defs[ 'p_label' ] ) {
                            echo '<label>' . ( is_bool( $config_defs[ 'p_label' ] ) ? esc_html__( 'Padding', 'shadowcore' ) : esc_html( $config_defs[ 'p_label' ] ) ) . '</label>';
                        }
                        echo $this->get_responsive_field( 'p', strtolower( $current_obj[ 'p' ] ), $current_obj[ 'p_lock' ] );
                    }
                    if ( ! $config_defs[ 'hide_m' ] ) {
                        if ( $config_defs[ 'm_label' ] ) {
                            echo '<label>' . ( is_bool( $config_defs[ 'm_label' ] ) ? esc_html__( 'Margin', 'shadowcore' ) : esc_html( $config_defs[ 'm_label' ] ) ) . '</label>';
                        }
                        echo $this->get_responsive_field( 'm', strtolower( $current_obj[ 'm' ] ), $current_obj[ 'm_lock' ] );
                    }
                    ?>
                    
                    <input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
				</div><!-- .cc-indents-wrapper -->
			</div><!-- .customize-control-content -->
			<?php
		}
	}
endif;