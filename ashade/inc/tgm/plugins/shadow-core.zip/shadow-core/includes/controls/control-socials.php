<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_Socials_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_Socials_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'socials'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
		# Display Control Content
		public function render_content() {
            
            # Get Config and define Defs
            $this_config = $this->config;
            $this_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
            $type = 'text';
            $target = 'blank';
			$socials = false;
			$list = false;
			$labels = array(
				'use_icons' => esc_attr__( 'Use Icons', 'shadowcore' ),
				'use_icons_descr' => esc_attr__( 'Disable this option to use the text labels.', 'shadowcore' ),
				'target_blank' => esc_attr__( 'Open Links in new Window', 'shadowcore' ),
			);
			
			if ( array_key_exists( 'list', $this_config ) && is_array( $this_config[ 'list' ] ) ) {
                $list = $this_config[ 'list' ];
            } else {
				echo "Socials List Error for #" . $this->id;
			}

			if ( array_key_exists( 'labels', $this_config ) && is_array( $this_config[ 'labels' ] ) ) {
                $labels = $this_config[ 'labels' ];
            }
            
            if ( is_array( $this_values ) ) {
				$type = $this_values['type'];
				$target = $this_values['target'];
                $socials = $this_values['socials'];
            } else {
                echo "Socials Values Error for #" . $this->id;
            }
			
            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) . '</span>';
            endif;

			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-socials-wrapper cc-socials--<?php echo esc_attr( $type ); ?>">
                   	<div class="cc-socials-type">
                   		<span><?php echo esc_attr( $labels['use_icons'] ); ?></span>
                   		<span class="description customize-control-description"><?php echo esc_attr( $labels['use_icons_descr'] ); ?></span>
                   	</div>
                   	<div class="cc-socials-target" data-target="<?php echo esc_attr( $target ); ?>">
                   		<span><?php echo esc_attr( $labels['target_blank'] ); ?></span>
                   	</div>
                    <?php
					if ( is_array( $socials ) ) {
						?>
						<div class="cc-sortable-list cc-socials-list">
							<?php
							foreach ( $socials as $id => $value ) {
								$this_id = $id;
								if ( strrpos( $this_id, '-' ) ) {
									$this_id = explode('-', $this_id)[0];
								}
								$this_value = strtolower( $this_id );
								?>
								<div class="cc-socials-item cc-sortable-item <?php echo esc_attr( empty( $value['url'] ) ? 'is-inactive' : '' ); ?>" data-type="<?php echo esc_attr( $this_id ); ?>">
									<div class="cc-socials-item--head cc-sortable-drag">
										<i class="cc-socials-item-icon"></i>
										<?php
											echo '<label>'. esc_html( $this_id ) .'</label>';
										?>
										<i class="dashicons dashicons-edit cc-socials-item-toggler" title="<?php echo esc_attr__('Toggle', 'shadowcore'); ?>"></i>
										<i class="dashicons dashicons-no-alt cc-socials-item--remove" title="<?php echo esc_attr__('Remove', 'shadowcore'); ?>"></i>
									</div>
									<div class="cc-socials-item--fields">
										<?php if ( $list ) { ?>
										<label class="cc-socials-field--type">
											<span><?php echo esc_attr__('Select Social Network:', 'shadowcore'); ?></span>
											<select value="<?php echo esc_attr( $this_value); ?>">
												<option value="select"><?php echo esc_attr__('Select', 'shadowcore'); ?></option>
												<?php foreach ( $list as $name ) { ?>
												<option value="<?php echo esc_attr(strtolower( $name )); ?>" <?php echo esc_attr( $this_value == strtolower( $name ) ? 'selected' : '' ); ?>><?php echo esc_attr( $name ); ?></option>
												<?php } ?>
											</select>
										</label>
										<?php } ?>
										<label class="cc-socials-field--url">
											<span><?php echo esc_attr__('URL:', 'shadowcore'); ?></span>
											<input type="text" value="<?php echo esc_url( $value['url'] ); ?>">
										</label>
										<label class="cc-socials-field--label">
											<span><?php echo esc_attr__('Label:', 'shadowcore'); ?></span>
											<input type="text" value="<?php echo esc_attr( $value['label'] ); ?>">
										</label>
									</div><!-- .cc-socials-item--fields -->
								</div>
								<?php
							}
							?>
						</div><!-- .cc-sortable-list -->
						<div class="cc-socials-new-item cc-socials-item cc-sortable-item is-inactive">
							<div class="cc-socials-item--head cc-sortable-drag">
								<i class="cc-socials-item-icon"></i>
								<?php
									echo '<label>&nbsp;</label>';
								?>
								<i class="dashicons dashicons-arrow-up cc-socials-item-toggler"></i>
								<i class="dashicons dashicons-no-alt cc-socials-item--remove"></i>
							</div>
							<div class="cc-socials-item--fields is-new" data-type="">
								<?php if ( $list ) { ?>
								<label class="cc-socials-field--type">
									<span><?php echo esc_attr__('Select Social Network:', 'shadowcore'); ?></span>
									<select value="select">
										<option value="select"><?php echo esc_attr__('Select', 'shadowcore'); ?></option>
										<?php foreach ( $list as $name ) { ?>
										<option value="<?php echo esc_attr(strtolower( $name )); ?>"><?php echo esc_attr( $name ); ?></option>
										<?php } ?>
									</select>
								</label>
								<?php } ?>
								<label class="cc-socials-field--url">
									<span><?php echo esc_attr__('URL:', 'shadowcore'); ?></span>
									<input type="text" value="">
								</label>
								<label class="cc-socials-field--label">
									<span><?php echo esc_attr__('Label:', 'shadowcore'); ?></span>
									<input type="text" value="">
								</label>
							</div><!-- .cc-socials-item--fields -->
						</div>
						<a href="#" class="cc-socials-add"><?php echo esc_html__('+ Add Item', 'shadowcore'); ?></a>
						<?php
					} else {
						echo "Socials List is Empty for #" . $this->id;
					}
                    ?>
                    <input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
				</div><!-- .cc-socials-wrapper -->
			</div><!-- .customize-control-content -->
			<?php
		}
	}
endif;