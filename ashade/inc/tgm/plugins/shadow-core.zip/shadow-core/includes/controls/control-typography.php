<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_Typography_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_Typography_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'typography'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
        # Get Slider Field
        private function get_slider_field( $id = false, $value = '', $type = false, $min = false, $max = false, $step = false ) {
            return '
            <div class="cc-slider-input ' . ( $type ? 'responsive-input--' . $type : '' ) . '"' . ( $id ? ' data-id="' . esc_attr( $id) . '"' : '' ) . '>
                <div class="cc-slider-wrap"' . ( $step !== '' ? ' data-step="'. esc_attr( $step ) .'"' : '' ) . '></div>
                <input type="number" value="' . esc_attr( $value ) . '" class="cc-slider-value'. ( $type ? '--' . $type : '' ) .'" '. ( $min !== false ? 'min="'. esc_attr( $min ) .'"' : '' ) .' '. ( $max !== false ? 'max="'. esc_attr( $max ) .'"' : '' ) .' '. ( $step !== false ? 'step="'. esc_attr( $step ) .'"' : '' ) .'>
            </div><!-- .cc-slider-input-wrap -->';
        }

        # Get Responsive Field
        private function get_responsive_field( $id, $values = false ) {
            $value_d = '';
            $value_t = '';
            $value_m = '';
            if ( $values ) {
                $multi = strpos( $values, '/' );
                if ( $multi === false ) {
                    $value_d = $values;
                } else {
                    $values_arr = explode( '/', $values );
                    if ( count( $values_arr ) !== 3) {
                        return 'Values Array Error for: ' . $id;
                    } else {
                        $value_d = $values_arr[0];
                        $value_t = $values_arr[1];
                        $value_m = $values_arr[2];
                    }
                }
            }
            return '
            <div class="cc-responsive-control-wrap is-desktop" data-id="'. esc_attr( $id ) .'">
                <div class="cc-responsive-control-states">
                    <a href="#" class="responsive-control-state is-active" data-state="desktop">
                        <i class="dashicons dashicons-desktop"></i>
                    </a>
                    <a href="#" class="responsive-control-state" data-state="tablet">
                        <i class="dashicons dashicons-tablet"></i>
                    </a>
                    <a href="#" class="responsive-control-state" data-state="mobile">
                        <i class="dashicons dashicons-smartphone"></i>
                    </a>
                </div>
                '. $this->get_slider_field( '', $value_d, 'desktop', 0, 200, 1 ) .'
                '. $this->get_slider_field( '', $value_t, 'tablet', 0, 200, 1 ) .'
                '. $this->get_slider_field( '', $value_m, 'mobile', 0, 200, 1 ) .'
            </div><!-- .cc-responsive-control-wrap -->';
        }
        
		# Display Control Content
		public function render_content() {

            $margin = 0;
            # Get Additional Config for Extend
            $this_config = $this->config;

            # Create Default Values
            $current_obj = array(
                'ff' => 'default',
                'fs' => '0',
                'lh' => '0',
                'ls' => '0',
                'tt' => 'default',
                'ts' => 'default',
                'td' => 'default',
            );
            
            # Get Current Values
            $current_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
            if ( is_array( $current_values ) ) {
                foreach ( $current_values as $i => $value ) {
                    $current_obj[ $i ] = $value;
                }
            }
            
            $toggler = 'no';   
            if ( array_key_exists( 'toggler', $this_config ) && $this_config[ 'toggler' ] ) {
                $toggler = 'off';
                if ( array_key_exists( 'toggled', $current_obj ) ) {
                    $toggler = $current_obj[ 'toggled' ];
                }
            }
            
            // List Values
            $tt = array(
                'default'    => esc_attr__( 'Default', 'shadowcore' ),
                'none'       => esc_attr__( 'None', 'shadowcore' ),
                'uppercase'  => esc_attr__( 'Uppercase', 'shadowcore' ),
                'lowercase'  => esc_attr__( 'Lowercase', 'shadowcore' ),
                'capitalize' => esc_attr__( 'Capitalize', 'shadowcore' ),
            );
            $ts = array(
                'default' => esc_attr__( 'Default', 'shadowcore' ),
                'normal'  => esc_attr__( 'Normal', 'shadowcore' ),
                'italic'  => esc_attr__( 'Italic', 'shadowcore' ),
                'oblique' => esc_attr__( 'Oblique', 'shadowcore' ),
            );
            $td = array(
                'default'   => esc_attr__( 'Default', 'shadowcore' ),
                'none'      => esc_attr__( 'None', 'shadowcore' ),
                'underline' => esc_attr__( 'Underline', 'shadowcore' ),
                'overline'  => esc_attr__( 'Overline', 'shadowcore' ),
                'line-through' => esc_attr__( 'Line Through', 'shadowcore' ),
            );

            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) . ( $toggler !== 'no' ? '<a href="#" class="cc-typography-toggler '. ( $toggler == 'on' ? 'is-active' : '' ) .'"></a>' : '' ) . '</span>';
            endif;

			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-typography-wrapper <?php echo esc_attr( $toggler !== 'no' ? 'has-toggler' : '' ); ?>" data-margin="<?php echo esc_attr( $margin ); ?>">
                    <div class="cc-typography-body">
                        <?php
                            if ( ! empty( $this_config[ 'families' ] ) ) {
                                echo '<label>'. esc_html__( 'Use Font Family', 'shadowcore' ) .':</label>';
                                echo '<select data-id="ff">';
                                $families = $this_config[ 'families' ];
                                echo '<option value="default" '. ( $current_obj[ 'ff' ] == 'default' ? 'selected' : '') .'>'. esc_html__( 'Default', 'shadowcore' ) .'</option>';
                                foreach ( $families as $value => $caption ) {
                                    echo '<option value="'. esc_attr( $value ) .'" '. ( $current_obj[ 'ff' ] == $value ? 'selected' : '' ) .'>'. esc_html( $caption ) .'</option>';
                                }
                                echo '</select>';
                            };
                        ?>

                        <label><?php echo esc_html__( 'Font Size, PX', 'shadowcore' ); ?>:</label>
                        <?php echo $this->get_responsive_field('fs', $current_obj['fs'] ); ?>

                        <label><?php echo esc_html__( 'Line Height, PX', 'shadowcore' ); ?>:</label>
                        <?php echo $this->get_responsive_field('lh', $current_obj['lh'] ); ?>

                        <label><?php echo esc_html__( 'Letter Spacing', 'shadowcore' ); ?>:</label>
                        <?php echo $this->get_slider_field( 'ls', esc_attr( $current_obj[ 'ls' ] ), false, -200, 200, 5 ); ?>
                        <!-- <input type="number" value="<?php echo esc_attr( $current_obj[ 'ls' ] ); ?>" data-id="ls" class="is-single"> -->

                        <label><?php echo esc_html__( 'Text Transform', 'shadowcore' ); ?>:</label>
                        <select data-id="tt">
                            <?php
                            foreach ( $tt as $value => $caption ) {
                                echo '<option value="'. esc_attr( $value) .'" '. esc_attr( $current_obj[ 'tt' ] == $value ? 'selected' : '' ) .'>'. $caption .'</option>';
                            }
                            ?>
                        </select>

                        <label><?php echo esc_html__( 'Font Style', 'shadowcore' ); ?>:</label>
                        <select data-id="ts">
                            <?php
                            foreach ( $ts as $value => $caption ) {
                                echo '<option value="'. esc_attr( $value) .'" '. esc_attr( $current_obj[ 'ts' ] == $value ? 'selected' : '' ) .'>'. $caption .'</option>';
                            }
                            ?>
                        </select>

                        <label><?php echo esc_html__( 'Text Decoration', 'shadowcore' ); ?>:</label>
                        <select data-id="td">
                            <?php
                            foreach ( $td as $value => $caption ) {
                                echo '<option value="'. esc_attr( $value) .'" '. esc_attr( $current_obj[ 'td' ] == $value ? 'selected' : '' ) .'>'. $caption .'</option>';
                            }
                            ?>
                        </select>
                    </div><!-- .cc-typography-body -->
				</div><!-- .cc-typography-wrapper -->
			</div><!-- .customize-control-content -->
			<input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
			<?php
		}
	}
endif;