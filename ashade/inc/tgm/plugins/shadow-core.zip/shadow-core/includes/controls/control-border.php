<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'Shadow_Customize_Border_Control' ) && class_exists( 'WP_Customize_Control' ) ) :
	class Shadow_Customize_Border_Control extends WP_Customize_Control {
		
		# Set Type
		public $type = 'border'; 
		public $custom_class = ''; // Custom Class
        public $config = array(); // Additional Settings
		
		# Enqueue Scrits and Styles
		public function enqueue() {
			wp_enqueue_style( 'shadow-customize-controls-css', SHADOWCORE_ASSETS_URL . 'css/customize-controls.css' );
			wp_enqueue_script( 'shadow-customize-controls-js', SHADOWCORE_ASSETS_URL . 'js/customize-controls.js', array('jquery'), false, true);
    	}
        
        # Generate Indetns Field
        private function get_indents_field( $values = '', $locked = '', $class = '') {
            if ( strpos( $values, 'x' ) === false ) {
                $values_arr = array( $values, $values, $values, $values );
            } else {
                $values_arr = explode( 'x', $values );
            }
            $d_values = $values_arr;
            return '
            <ul class="shadow-indents-field-wrap '. ( $locked ? 'is-locked' : '') .'" data-id="'. esc_attr( $class ) .'">
                <li>
                    <input type="number" data-pos="t" '. ( $d_values[0] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[0] !== 'd' && $values_arr[0] !== 'n' ? $values_arr[0] : '' ) .'" min="0">
                    <label>'. esc_html__( 'Top', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="r" '. ( $d_values[1] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[1] !== 'd' && $values_arr[1] !== 'n' ? $values_arr[1] : '' ) .'" min="0">
                    <label>'. esc_html__( 'Right', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="b" '. ( $d_values[2] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[2] !== 'd' && $values_arr[2] !== 'n' ? $values_arr[2] : '' ) .'" min="0">
                    <label>'. esc_html__( 'Bottom', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <input type="number" data-pos="l" '. ( $d_values[3] === 'd' ? 'disabled' : '' ) .' value="'. esc_attr( $values_arr[3] !== 'd' && $values_arr[3] !== 'n' ? $values_arr[3] : '' ) .'" min="0">
                    <label>'. esc_html__( 'Left', 'shadowcore' ) .'</label>
                </li>
                <li>
                    <a href="#" class="shadow-indents-field-lock">
                        <i class="dashicons dashicons-lock"></i>
                        <i class="dashicons dashicons-unlock"></i>
                    </a>
                </li>
            </ul>
            <!-- .shadow-indents-field-wrap -->
            ';
        }
        
		# Display Control Content
		public function render_content() {
            
            # Get Config and define Defs
            if ( is_array( $this->config ) ) {
				foreach ($this->config as $i => $v) {
                    $config_defs[ $i ] = $v;
                }
            }
            
            # Create Default Values
            $this_values = array(
                'bs'  => 'default', // Border Type (Style)
                'bw'  => '', // Border Width
                'bwl' => '1', // Border Width Locker
                'br'  => '', // Border Radius
                'brl' => '1', // Border Radius Locker
                'bru' => 'px', // Border Radius Unit (%, px)
            );
            
            # Border Styles
            $styles = Array(
                'default' => 'Default',
                'none'    => 'None',
				'solid'   => 'Solid',
				'double'  => 'Double',
				'dotted'  => 'Dotted',
				'dashed'  => 'Dashed',
				'groove'  => 'Groove'
            );
            
            # Get Current Values
            $current_values = json_decode(stripslashes(html_entity_decode($this->value())), true);
            if ( is_array( $current_values ) ) {
                foreach ( $current_values as $i => $value ) {
                    $this_values[ $i ] = $value;
                }
            }

            # Check values and Unlock for not equal
            if ( strpos( $this_values['bw'], 'x' ) === false ) {
                $this_values['bwl'] = 1;
            } else {
                $this_values['bwl'] = 0;
            }
            if ( strpos( $this_values['br'], 'x' ) === false ) {
                $this_values['brl'] = 1;
            } else {
                $this_values['brl'] = 0;
            }
            
            if ( !empty( $this->label ) ) :
                echo '<span class="customize-control-title">'. esc_html( $this->label ) .'</span>';
            endif;
            ?>
            <?php
			if ( !empty( $this->description ) ) :
				echo '<span class="description customize-control-description">'. $this->description .'</span>';
			endif;
			
			?>
			<div class="customize-control-content" <?php echo ( $this->custom_class !== '' ? 'data-class="'. esc_attr( $this->custom_class ) .'"' : '' ) ?>>
				<div id="_customize-input-<?php echo esc_attr( $this->id ); ?>" class="cc-border-control-wrapper">
                    <label><?php echo esc_html__( 'Border Style', 'shadowcore' ); ?>:</label>
                    <select data-id="bs" class="cc-border-control--style">
                        <?php
                        foreach ( $styles as $value => $caption ) {
                            echo '<option value="'. esc_attr( $value) .'" '. esc_attr( $this_values[ 'bs' ] == $value ? 'selected' : '' ) .'>'. $caption .'</option>';
                        }
                        ?>
                    </select>
                    <div class="cc-border-control--width <?php echo esc_attr( ( $this_values[ 'bs' ] == 'default' || $this_values[ 'bs' ] == 'none' ) ? 'is-hidden' : ''); ?>">
                        <label><?php echo esc_html__( 'Border Width', 'shadowcore' ); ?>:</label>
                        <?php
                            echo $this->get_indents_field( $this_values[ 'bw' ], $this_values[ 'bwl' ], 'bw' );
                        ?>
                    </div>
                    <div class="cc-border-control--radius">
                    <label class="cc-unit-selector-wrap">
                        <?php echo esc_html__( 'Border Radius', 'shadowcore' ); ?>:
                        <div class="cc-unit-selector" data-id="bru" data-value="<?php echo esc_attr( $this_values[ 'bru' ] ); ?>">
                            <a href="#" data-val="px" class="<?php echo esc_attr( $this_values[ 'bru' ] == 'px' ? 'is-active' : ''); ?>">Px</a>
                            <a href="#" data-val="%" class="<?php echo esc_attr( $this_values[ 'bru' ] == '%' ? 'is-active' : ''); ?>">%</a>
                        </div>
                    </label>
                    <?php
                        echo $this->get_indents_field( $this_values[ 'br' ], $this_values[ 'brl' ], 'br' );
                    ?>
                    </div>
                    <input type="hidden" <?php $this->link(); ?> value="<?php echo $this->value(); ?>" />
				</div><!-- .cc-indents-wrapper -->
			</div><!-- .customize-control-content -->
			<?php
		}
	}
endif;