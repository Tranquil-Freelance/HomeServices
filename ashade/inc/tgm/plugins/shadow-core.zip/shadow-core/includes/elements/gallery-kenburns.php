<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Gallery_Kenburns_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-gallery-kenburns';
	}
	
	public function get_title() {
		return esc_html__( 'Gallery: Kenburns', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-slideshow';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
    
    public function get_script_depends() {
		return [ 'gsap' ];
	}
	
	protected function register_controls() {	
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );
        	
		# TAB: CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Gallery Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$this->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Images', 'shadowcore' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		$this->add_control(
			'randomize_images',
			[
				'label' => esc_html__( 'Randomize Gallery?', 'shadowcore' ),
				'description' => esc_html__( 'Shuffle images on each time gallery loads.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('randomize_images', $defs) ? $defs[ 'randomize_images' ] : 'no' ),
			]
		);
		$this->add_control(
			'divider-gallery',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        $this->add_control(
			'caption_state',
			[
				'label' => esc_html__( 'Show Image Caption?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('caption_state', $defs) ? $defs[ 'caption_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-kenburns-captions--',
			]
		);
        $this->add_control(
			'descr_state',
			[
				'label' => esc_html__( 'Show Image Description?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('descr_state', $defs) ? $defs[ 'descr_state' ] : 'no' ),
                'condition' => [
					'caption_state' => 'yes'
				],
                'prefix_class' => 'shadowcore-kenburns-descr--',
			]
		);
        
        $this->add_control(
			'divider-caption',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'height_type',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('height_type', $defs) ? $defs[ 'height_type' ] : 'screen' ),
                'options' => [
					'screen'  => esc_attr__( 'Fit to Screen', 'shadowcore' ),
					'custom'  => esc_attr__( 'Custom', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-kenburns-height--',
			]
		);
        
        $this->add_responsive_control(
			'custom_height',
			[
				'label' => esc_attr__( 'Gallery Height, px', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height', $defs) ? $defs[ 'custom_height' ] : [ 
					'unit' => 'vh',
                    'size' => 100,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-kenburns-height--custom .shadowcore-kenburns-wrap' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'height_type' => 'custom'
				],
			]
		);
        
		$this->add_control(
			'divider-gallery-dim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
            'transition',
            [
				'label' => esc_attr__( 'Transition Speed, ms', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
				'default' => ( array_key_exists('transition', $defs) ? $defs[ 'transition' ] : '2000' ),
                'min' => '500',
				'step' => '100',
            ]
		);
        
        $this->add_control(
            'delay',
            [
				'label' => esc_attr__( 'Slide Delay, ms', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
				'default' => ( array_key_exists('delay', $defs) ? $defs[ 'delay' ] : '4000' ),
                'min' => '1000',
				'step' => '100',
            ]
		);
        
        $this->add_control(
            'zoom',
            [
				'label' => esc_attr__( 'Zoom Value, %', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'min' => '100',
				'step' => '1',
				'default' => ( array_key_exists('zoom', $defs) ? $defs[ 'zoom' ] : '120' ),
            ]
		);

		$this->end_controls_section();

		# TAB: STYLE
		# Section: Image
		$this->start_controls_section(
			'section_style_template',
			[
				'label' => esc_html__( 'Gallery', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'overlay_state',
			[
				'label' => esc_html__( 'Gallery Overlay', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'shadowcore' ),
				'label_off' => esc_html__( 'Off', 'shadowcore' ),
				'default' => ( array_key_exists('overlay_state', $defs) ? $defs[ 'overlay_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-kenburns-overlay--',
			]
		);
        $this->add_control(
			'overlay_color',
			[
				'label' => esc_html__( 'Overlay Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'overlay_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-overlay' => 'background-color: {{VALUE}};'
				]
			]
		);
        $this->add_control(
			'divider-gallery-overlay',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-kenburns',
			]
		);
		# EOS
		$this->end_controls_section();
		# Section: Caption Styles
		$this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Content Styles', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typo',
				'label' => esc_html__( 'Caption Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-kenburns-caption',
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        $this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Caption Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-caption' => 'color: {{VALUE}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'descr_typo',
				'label' => esc_html__( 'Description Typography', 'shadowcore' ),
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
				'selector' => '{{WRAPPER}} .shadowcore-kenburns-description'
			]
		);
        $this->add_control(
			'descr_color',
			[
				'label' => esc_html__( 'Description Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-description' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'divider-caption-typo',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'caption_text_align',
			[
				'label' => esc_attr__( 'Caption Text Align', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_text_align', $defs) ? $defs[ 'caption_text_align' ] : 'left' ),
                'options' => [
					'left' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-title > div' => 'text-align: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_v_position',
			[
				'label' => esc_attr__( 'Caption Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_v_position', $defs) ? $defs[ 'caption_v_position' ] : 'flex-end' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-slide' => 'align-items: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_h_position',
			[
				'label' => esc_attr__( 'Caption Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_h_position', $defs) ? $defs[ 'caption_h_position' ] : 'flex-start' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-slide' => 'justify-content: {{VALUE}};',
				],
			]
		);
        
        $this->add_control(
			'divider-caption-padding',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_responsive_control(
			'caption_padding',
			[
				'label' => esc_html__( 'Caption Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_padding', $defs) ? $defs[ 'caption_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_responsive_control(
			'description_spacing',
			[
				'label' => esc_html__( 'Description Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('description_spacing', $defs) ? $defs[ 'description_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-kenburns-description' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
			]
		);
        
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$gallery = $settings[ 'gallery' ];
		$randomize_images = $settings[ 'randomize_images' ];

		if ( empty( $gallery ) ) {
            echo '<div class="shadowcore-widget-holder"><i class="'. esc_attr( $this->get_icon() ) .'"></i><span>'. esc_html__( 'No Images', 'shadowcore' ) .'</span></div>';
		} else {
            if ( 'yes' == $randomize_images ) {
                shuffle( $gallery );
            }
            ?>
            <div class="shadowcore-kenburns-wrap">
                <div class="shadowcore-kenburns" 
                    data-id    = "<?php echo esc_attr( $this->get_id() ); ?>" 
                    data-delay = "<?php echo esc_attr( $settings[ 'delay' ] ); ?>" 
                    data-zoom  = "<?php echo esc_attr( $settings[ 'zoom' ] ); ?>" 
                    data-speed = "<?php echo esc_attr( $settings[ 'transition' ] ); ?>" 
                >
                    <?php 
                    foreach ( $gallery as $item ) {
                        $image_post = get_post( $item[ 'id' ] );
                        $image_url = wp_get_attachment_url( $item[ 'id' ] );
                        $caption = $image_post->post_excerpt;
                        $descr = $image_post->post_content;
                        ?>
                        <div class="shadowcore-kenburns-slide" data-src="<?php echo esc_url( $image_url ); ?>">
                            <div class="shadowcore-kenburns-slide-image"></div>
                            <div class="shadowcore-kenburns-overlay"></div>
                            <div class="shadowcore-kenburns-title">
                                <div class="shadowcore-kenburns-caption"><?php echo esc_html( $caption ); ?></div>
                                <div class="shadowcore-kenburns-description"><?php echo esc_html( $descr ); ?></div>
                            </div><!-- .shadowcore-kenburns-title -->
                        </div>
                    <?php } ?>
                </div><!-- .shadowcore-kenburns -->
                <!-- .shadowcore-kenburns-overlay -->
            </div><!-- .shadowcore-kenburns-wrap -->
            <?php
        }
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Gallery_Kenburns_Widget() );