<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Gallery_Ribbon_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-gallery-ribbon';
	}
	
	public function get_title() {
		return esc_html__( 'Gallery: Ribbon', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-slider-push';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
    
    public function get_script_depends() {
		return [ 'shadowcore_ribbon_gallery' ];
	}
	
	protected function register_controls() {	
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );
        
		# TAB: CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Gallery Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$this->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Images', 'shadowcore' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		$this->add_control(
			'randomize_images',
			[
				'label' => esc_html__( 'Randomize Gallery?', 'shadowcore' ),
				'description' => esc_html__( 'Shuffle images on each time gallery loads.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('randomize_images', $defs) ? $defs[ 'randomize_images' ] : 'no' ),
			]
		);
        $this->add_control(
			'lightbox',
			[
				'label' => esc_html__( 'Open images in the Lightbox?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lightbox', $defs) ? $defs[ 'lightbox' ] : 'no' ),
			]
		);
        $this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Images Lazy Loading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lazy', $defs) ? $defs[ 'lazy' ] : 'yes' ),
			]
		);
		$this->add_control(
			'vertical_mobile',
			[
				'label' => esc_html__( 'Vertical Layout for Mobile', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('vertical_mobile', $defs) ? $defs[ 'vertical_mobile' ] : 'no' ),
			]
		);
		$this->add_control(
			'divider-gallery',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        $this->add_control(
			'caption_state',
			[
				'label' => esc_html__( 'Show Image Caption?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('caption_state', $defs) ? $defs[ 'caption_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-ribbon-captions--',
			]
		);
        $this->add_control(
			'descr_state',
			[
				'label' => esc_html__( 'Show Image Description?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('descr_state', $defs) ? $defs[ 'descr_state' ] : 'no' ),
                'condition' => [
					'caption_state' => 'yes'
				],
                'prefix_class' => 'shadowcore-ribbon-descr--',
			]
		);
        
        $this->add_control(
			'divider-caption',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'height_type',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('height_type', $defs) ? $defs[ 'height_type' ] : 'screen' ),
                'options' => [
					'screen'  => esc_attr__( 'Screen Height', 'shadowcore' ),
					'custom'  => esc_attr__( 'Custom', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-ribbon-height--',
			]
		);
        
        $this->add_responsive_control(
			'custom_height',
			[
				'label' => esc_attr__( 'Gallery Height, px', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height', $defs) ? $defs[ 'custom_height' ] : [ 
					'unit' => 'vh',
                    'size' => 100,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-ribbon-height--custom .shadowcore-ribbon-wrap' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'height_type' => 'custom'
				],
			]
		);

		$this->add_control(
			'custom_height_reduce',
			[
				'label' => esc_html__( 'Reduce Height?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'prefix_class' => 'shadowcore-ribbon-height-reduce--',
				'default' => ( array_key_exists('custom_height_reduce', $defs) ? $defs[ 'custom_height_reduce' ] : 'no' ),
				'condition' => [
					'height_type' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'custom_height_reduce_val',
			[
				'label' => esc_attr__( 'Height Reduction Value', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
                        'max' => 1280
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height_reduce_val', $defs) ? $defs[ 'custom_height_reduce_val' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-ribbon-height--custom.shadowcore-ribbon-height-reduce--yes .shadowcore-ribbon-wrap' => 'height: calc({{custom_height.SIZE}}{{custom_height.UNIT}} - {{SIZE}}{{UNIT}});',
				],
                'condition' => [
					'height_type' => 'custom',
					'custom_height_reduce' => 'yes',
				],
			]
		);
        
        $this->add_control(
			'divider-gallery-spacing',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'Items Spacing, PX', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 5
					],
				],
				'default' => ( array_key_exists('items_spacing', $defs) ? $defs[ 'items_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 40,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}:not(.shadowcore-ribbon-side-spacing--yes) .shadowcore-ribbon' => 'margin-left: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-ribbon > div' => 'margin-left: {{SIZE}}{{UNIT}};',

					'(mobile) {{WRAPPER}}:not(.shadowcore-ribbon-side-spacing--yes) .shadowcore-ribbon.vertical-mobile-layout' => 'margin-left: 0;',
					'(mobile) {{WRAPPER}}.shadowcore-ribbon-side-spacing--yes .shadowcore-ribbon.vertical-mobile-layout' => 'margin-left: 0; padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}; margin-top: -{{SIZE}}{{UNIT}}',
					'(mobile) {{WRAPPER}} .shadowcore-ribbon.vertical-mobile-layout > div' => 'margin-left: 0; margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_control(
			'side_spacing',
			[
				'label' => esc_html__( 'Side Spacings', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('side_spacing', $defs) ? $defs[ 'side_spacing' ] : 'no' ),
				'prefix_class' => 'shadowcore-ribbon-side-spacing--',
			]
		);

		$this->add_control(
			'divider-gallery-anim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'd-speed',
			[
				'label' => esc_html__( 'Mouse Scroll Speed, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 300,
						'step' => 5
					],
				],
				'default' => ( array_key_exists('d-speed', $defs) ? $defs[ 'd-speed' ] : [ 
					'unit' => '%',
                    'size' => 150,
				 ] ),
			]
		);
		
		$this->add_responsive_control(
			't-speed',
			[
				'label' => esc_html__( 'Touch Scroll Speed, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 300
					],
				],
				'default' => ( array_key_exists('t-speed', $defs) ? $defs[ 't-speed' ] : [ 
					'unit' => '%',
                    'size' => 200,
				 ] ),
			]
		);
        
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Caption Styles
		$this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Gallery', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'overlay_state',
			[
				'label' => esc_html__( 'Gallery Overlay', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'shadowcore' ),
				'label_off' => esc_html__( 'Off', 'shadowcore' ),
				'default' => ( array_key_exists('overlay_state', $defs) ? $defs[ 'overlay_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-ribbon-overlay--',
			]
		);
        $this->add_control(
			'overlay_color',
			[
				'label' => esc_html__( 'Overlay Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'overlay_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-overlay' => 'background-color: {{VALUE}};'
				]
			]
		);
        $this->add_control(
			'divider-br',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->end_controls_section();
        
        $this->start_controls_section(
			'section_styles_caption',
			[
				'label' => esc_html__( 'Caption and Description', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        # Captions Style Section
        $this->add_control(
			'no_captions',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Captions are disabled by the element settings.', 'shadowcore' ),
				'content_classes' => 'shadowcore-elementor-message shadowcore-no-captions',
				'condition' => [
					'caption_state!' => 'yes'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typo',
				'label' => esc_html__( 'Caption Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-ribbon-caption',
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        $this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Caption Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-caption' => 'color: {{VALUE}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'descr_typo',
				'label' => esc_html__( 'Description Typography', 'shadowcore' ),
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
				'selector' => '{{WRAPPER}} .shadowcore-ribbon-description'
			]
		);
        $this->add_control(
			'descr_color',
			[
				'label' => esc_html__( 'Description Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-description' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'divider-caption-typo',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'caption_text_align',
			[
				'label' => esc_attr__( 'Caption Text Align', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_text_align', $defs) ? $defs[ 'caption_text_align' ] : 'left' ),
                'options' => [
					'left' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title > div' => 'text-align: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_v_position',
			[
				'label' => esc_attr__( 'Caption Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_v_position', $defs) ? $defs[ 'caption_v_position' ] : 'flex-end' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title-wrap' => 'align-items: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_h_position',
			[
				'label' => esc_attr__( 'Caption Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_h_position', $defs) ? $defs[ 'caption_h_position' ] : 'flex-start' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title-wrap' => 'justify-content: {{VALUE}};',
				],
			]
		);
        
        $this->add_control(
			'divider-caption-padding',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
		$this->add_responsive_control(
			'caption_margin',
			[
				'label' => esc_html__( 'Caption Margin', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_margin', $defs) ? $defs[ 'caption_margin' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        $this->add_responsive_control(
			'caption_padding',
			[
				'label' => esc_html__( 'Caption Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_padding', $defs) ? $defs[ 'caption_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'caption_br',
			[
				'label' => esc_html__( 'Caption Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_br', $defs) ? $defs[ 'caption_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_responsive_control(
			'description_spacing',
			[
				'label' => esc_html__( 'Description Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('description_spacing', $defs) ? $defs[ 'description_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-description' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'caption_shadow',
				'label' => esc_html__( 'Caption Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-ribbon-title',
				'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$gallery = $settings[ 'gallery' ];
		$randomize_images = $settings[ 'randomize_images' ];
        $lazy_state = $settings[ 'lazy' ];
		if ( empty( $gallery ) ) {
			echo '<div class="shadowcore-widget-holder"><i class="'. esc_attr( $this->get_icon() ) .'"></i><span>'. esc_html__( 'No Images', 'shadowcore' ) .'</span></div>';
		}
		?>
		<div class="shadowcore-ribbon-wrap <?php echo esc_attr( $settings[ 'vertical_mobile' ] ? 'vertical-mobile-wrap' : '' ); ?> <?php echo esc_attr( empty( $gallery ) ? 'is-hidden' : '' ); ?>">
			<div class="shadowcore-ribbon shadowcore-cursor--scrollH <?php echo esc_attr( count($gallery) == 1 ? 'is-single' : ''); ?> <?php echo esc_attr( $settings[ 'vertical_mobile' ] ? 'vertical-mobile-layout' : '' ); ?>" 
				data-id="<?php echo esc_attr( $this->get_id() ); ?>" 
				data-side-spacing="<?php echo esc_attr( $settings[ 'side_spacing' ] == 'yes' ? 'yes' : 'no'); ?>" 
				data-dspeed="<?php echo esc_attr( $settings[ 'd-speed' ][ 'size' ] ); ?>" 
				data-tspeed="<?php echo esc_attr( $settings[ 't-speed' ][ 'size' ] ); ?>" 
				data-lazy="<?php echo esc_attr( $lazy_state == 'yes' ? '1' : '0' ); ?>">
				<?php
				if ( ! empty( $gallery ) ) {        
					if ( 'yes' == $randomize_images ) {
						shuffle( $gallery );
					}
					$i = 0;
					foreach ( $gallery as $item ) {
						$image_post = get_post( $item[ 'id' ] );
						$image_meta = wp_get_attachment_metadata( $item[ 'id' ] );
						$image_url = wp_get_attachment_url( $item[ 'id' ] );
						
						$caption = $image_post->post_excerpt;
						$descr = $image_post->post_content;
						$alt_text = get_post_meta( $item[ 'id' ], '_wp_attachment_image_alt', true );
						
						$image_width = $image_meta[ 'width' ];
						$image_height = $image_meta[ 'height' ];
						$image_ratio = round( $image_width / $image_height, 3 );
						?>
						<div class="shadowcore-ribbon-item <?php echo esc_attr( $lazy_state == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>" data-ind="<?php echo esc_attr( $i ); ?>" data-ratio="<?php echo esc_attr( $image_ratio); ?>">
							<div class="shadowcore-ribbon-item--image <?php echo esc_attr( $lazy_state == 'yes' ? 'shadowcore-lazy' : '' ); ?>" data-src="<?php echo esc_url( $image_url ); ?>">
								<?php if ( 'yes' == $settings[ 'lightbox' ] ) {?>
								<a href="<?php echo esc_url( $image_url ); ?>" 
									class="shadowcore-lightbox-link" 
									data-elementor-open-lightbox="no"
									data-gallery = "grid_<?php echo esc_attr( $this->get_id() ); ?>" 
									<?php if ( ! empty( $lightbox_text ) ) { ?>
									data-caption="<?php echo esc_attr( $lightbox_text ); ?>"
									<?php } ?>
									data-size="<?php echo esc_attr( $image_width ); ?>x<?php echo esc_attr( $image_height ); ?>">
								<?php } ?>
								<img 
									src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $image_width ); ?>%20<?php echo absint( $image_height ); ?>'%3E%3C/svg%3E" 
									alt="<?php echo esc_attr( $alt_text ); ?>" 
									width="<?php echo intval( $image_width ); ?>" 
									height="<?php echo intval( $image_height ); ?>"/>
								<?php if ( 'yes' == $settings[ 'lightbox' ] ) {?>
								</a>
								<?php } ?>
							</div>
							<div class="shadowcore-ribbon-overlay"></div>
							<div class="shadowcore-ribbon-title-wrap">
								<div class="shadowcore-ribbon-title">
									<div class="shadowcore-ribbon-caption"><?php echo esc_html( $caption ); ?></div>
									<div class="shadowcore-ribbon-description"><?php echo esc_html( $descr ); ?></div>
								</div><!-- .shadowcore-ribbon-title -->
							</div><!-- .shadowcore-ribbon-title-wrap -->
						</div>
					<?php 
						$i++;
					}
				}
				?>
			</div><!-- .shadowcore-ribbon -->
		</div><!-- .shadowcore-ribbon-wrap -->
		<?php
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Gallery_Ribbon_Widget() );