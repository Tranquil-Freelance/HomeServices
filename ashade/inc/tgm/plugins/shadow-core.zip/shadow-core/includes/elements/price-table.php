<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Price_Table_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-price-table';
	}
	
	public function get_title() {
		return esc_html__( 'Price Table', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-price-table';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
	
	protected function register_controls() {		
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		
		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Item Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$features = new Repeater();
		$features->add_control(
			'feature_text',
			[
				'label' => esc_html__( 'Feature Text', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ''
			]
		);
	
		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Price Item', 'shadowcore' )
			]
		);
		$this->add_control(
			'price',
			[
				'label' => esc_html__( 'Item Price', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '$100', 'shadowcore' )
			]
		);
		$this->add_control(
			'price_descr',
			[
				'label' => esc_html__( 'Item Price Label', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('price_descr', $defs) ? $defs[ 'price_descr' ] : 'Monthly' ),
			]
		);
		$this->add_control(
			'most_popular',
			[
				'label' => esc_html__( 'Most Popular', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('most_popular', $defs) ? $defs[ 'most_popular' ] : 'no' ),
			]
		);
		$this->add_control(
			'most_popular_label',
			[
				'label' => esc_html__( 'Most Popular Label', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('most_popular_label', $defs) ? $defs[ 'most_popular_label' ] : esc_html__( 'Most Popular', 'shadowcore' ) ),
				'condition' => [
					'most_popular' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-features',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_state' => 'yes'
				]
			]
		);
		$this->add_control(
			'features_heading',
			[
				'label' => esc_html__( 'Features List Heading', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('features_heading', $defs) ? $defs[ 'features_heading' ] : esc_html__( 'What is included', 'shadowcore' ) ),
			]
		);
		$this->add_control(
			'features_type',
			[
				'label' => esc_html__( 'Features List Type', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'list' => [
						'title' => esc_html__( 'List', 'shadowcore' ),
						'icon' => 'eicon-editor-list-ul',
					],
					'descr' => [
						'title' => esc_html__( 'Description', 'shadowcore' ),
						'icon' => 'eicon-text-area',
					],
					'html' => [
						'title' => esc_html__( 'HTML', 'shadowcore' ),
						'icon' => 'eicon-editor-code',
					],
				],
				'default' => ( array_key_exists('features_type', $defs) ? $defs[ 'features_type' ] : 'list' ),
				'toggle' => false,
			]
		);
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__( 'Features List', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::REPEATER,
				'fields' => $features->get_controls(),
				'title_field' => '{{{ feature_text }}}',
				'default' => [
					[
						'feature_text' => 'Lorem ipsum dolor'
					],
					[
						'feature_text' => 'Lorem ipsum dolor'
					],
					[
						'feature_text' => 'Lorem ipsum dolor'
					],
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_control(
            'features_descr',
            [
                'label' => esc_html__( 'Description', 'shadowcore' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
				'condition' => [
					'features_type' => 'descr'
				]
            ]
		);
		$this->add_control(
            'features_html',
            [
                'label' => esc_html__( 'HTML Code', 'shadowcore' ),
				'type' => Controls_Manager::CODE,
				'default' => '',
				'condition' => [
					'features_type' => 'html'
				]
            ]
		);
		$this->add_control(
			'divider-button',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'button_state',
			[
				'label' => esc_html__( 'Show Button', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('button_state', $defs) ? $defs[ 'button_state' ] : 'yes' ),
			]
		);
		$this->add_control(
            'button_text',
            [
                'label' => esc_html__( 'Button Text', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('button_text', $defs) ? $defs[ 'button_text' ] : esc_html__( 'Order Now', 'shadowcore' ) ),
				'condition' => [
					'button_state' => 'yes'
				]
            ]
		);
		$this->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'true',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
				'condition' => [
					'button_state' => 'yes'
				]
            ]
		);
		
		$this->end_controls_section();

		# TAB: STYLE
		# Section: General Style
		$this->start_controls_section(
			'section_style_general',
			[
				'label' => esc_html__( 'General', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item',
			]
		);
		$this->add_responsive_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-price-item--head' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} 0 0;',
					'{{WRAPPER}} .shadowcore-price-item > div:last-child' => 'border-radius: 0 0 {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('border_radius', $defs) ? $defs[ 'border_radius' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_control(
			'divider-style-general01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-style-general02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item',
			]
		);
		$this->end_controls_section();

		# Section: Most Popular Label Style
		$this->start_controls_section(
			'section_style_popular',
			[
				'label' => esc_html__( 'Popular Label', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'most_popular' => 'yes'
				]
			]
		);
		$this->add_control(
			'mp_label_align',
			[
				'label' => esc_html__( 'Label Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('mp_label_align', $defs) ? $defs[ 'mp_label_align' ] : 'flex-end' ),
				'toggle' => false,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label-wrap' => 'justify-content: {{VALUE}};'
				]
			]
		);
		$this->add_responsive_control(
			'mp_wrap_padding',
			[
				'label' => esc_html__( 'Outer Spacing', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('mp_wrap_padding', $defs) ? $defs[ 'mp_wrap_padding' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_responsive_control(
			'mp_label_padding',
			[
				'label' => esc_html__( 'Inner Spacing', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('mp_label_padding', $defs) ? $defs[ 'mp_label_padding' ] : [ 
					'top' => '10',
					'right' => '11',
					'bottom' => '10',
					'left' => '20',
					'isLinked' => false,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_control(
			'divider-style-mp01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'mp_border',
				'label' => esc_html__( 'Border', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item-mp-label',
			]
		);
		$this->add_responsive_control(
			'mp_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('mp_border_radius', $defs) ? $defs[ 'mp_border_radius' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'mp_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item-mp-label',
			]
		);
		$this->add_control(
			'divider-style-mp02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'mp_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item-mp-label'
			]
		);
		$this->add_control(
			'divider-style-mp03',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'mp_text_color',
			[
				'label' => esc_html__( 'Text Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'mp_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-mp-label' => 'background: {{VALUE}};'
				]
			]
		);
		$this->end_controls_section();

		# Section: Head and Price
		$this->start_controls_section(
			'section_style_heading',
			[
				'label' => esc_html__( 'Heading and Price', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'head_swap',
			[
				'label' => esc_html__( 'Price before Heading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('head_swap', $defs) ? $defs[ 'head_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-price-item-head-swap--',
			]
		);
		$this->add_responsive_control(
			'head_padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--head' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('head_padding', $defs) ? $defs[ 'head_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				]),
				'condition' => [
					'most_popular!' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'head_padding_popular',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--head' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('head_padding_popular', $defs) ? $defs[ 'head_padding_popular' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				]),
				'condition' => [
					'most_popular' => 'yes'
				]
			]
		);
		$this->add_control(
			'head_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--head' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-style-head01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'heading_spacing',
			[
				'label' => esc_html__( 'Heading Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('heading_spacing', $defs) ? $defs[ 'heading_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--heading' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-top: 0;',
					'{{WRAPPER}}.shadowcore-price-item-head-swap--yes .shadowcore-price-item--heading' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typo',
				'label' => esc_html__( 'Heading Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item--heading'
			]
		);
		$this->add_control(
			'heading_color',
			[
				'label' => esc_html__( 'Heading Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--heading' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-style-head02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'price_layout',
			[
				'label' => esc_html__( 'Price Layout', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'horizontal' => [
						'title' => esc_html__( 'Horizontal', 'shadowcore' ),
						'icon' => 'eicon-h-align-stretch',
					],
					'vertical' => [
						'title' => esc_html__( 'Vertical', 'shadowcore' ),
						'icon' => 'eicon-v-align-stretch',
					],
				],
				'default' => ( array_key_exists('price_layout', $defs) ? $defs[ 'price_layout' ] : 'vertical' ),
				'toggle' => false,
				'prefix_class' => 'shadowcore-price-item-price-layout--',
			]
		);
		$this->add_control(
			'price_swap',
			[
				'label' => esc_html__( 'Label before Price', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('price_swap', $defs) ? $defs[ 'price_swap' ] : 'yes' ),
				'prefix_class' => 'shadowcore-price-item-price-swap--',
			]
		);
		$this->add_control(
			'price_v_align',
			[
				'label' => esc_html__( 'Vertical Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => esc_html__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => ( array_key_exists('price_v_align', $defs) ? $defs[ 'price_v_align' ] : 'top' ),
				'toggle' => false,
				'prefix_class' => 'shadowcore-price-item-valign--',
				'condition' => [
					'price_layout' => 'horizontal'
				]
			]
		);
		$this->add_control(
			'price_h_align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('price_h_align', $defs) ? $defs[ 'price_h_align' ] : 'left' ),
				'prefix_class' => 'shadowcore-price-item-halign--',
				'toggle' => false,
			
			]
		);
		$this->add_responsive_control(
			'price_spacing',
			[
				'label' => esc_html__( 'Price and Label Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('price_spacing', $defs) ? $defs[ 'price_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 10,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-price-item-price-layout--horizontal .shadowcore-price-item--price-descr' => 'margin: 0 0 0 {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.shadowcore-price-item-price-swap--yes.shadowcore-price-item-price-layout--horizontal .shadowcore-price-item--price-descr' => 'margin: 0 {{SIZE}}{{UNIT}} 0 0;',
					'{{WRAPPER}}.shadowcore-price-item-price-layout--vertical .shadowcore-price-item--price-descr' => 'margin: {{SIZE}}{{UNIT}} 0 0 0;',
					'{{WRAPPER}}.shadowcore-price-item-price-swap--yes.shadowcore-price-item-price-layout--vertical .shadowcore-price-item--price-descr' => 'margin: 0 0 {{SIZE}}{{UNIT}} 0;',
				],
			]
		);
		$this->add_control(
			'divider-style-head03',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--price' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'price_label_color',
			[
				'label' => esc_html__( 'Price Label Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--price-descr' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typo',
				'label' => esc_html__( 'Price Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item--price'
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_label_typo',
				'label' => esc_html__( 'Price Label Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item--price-descr'
			]
		);
		
		$this->end_controls_section();

		# Section: Content Style
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_responsive_control(
			'content_padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('content_padding', $defs) ? $defs[ 'content_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_control(
			'content_bg',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--content' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-style-content01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Text Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--content' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-price-item--list-heading' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-price-item--list li' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item--content, {{WRAPPER}} .shadowcore-price-item--content li'
			]
		);
		$this->add_control(
			'divider-style-content02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_control(
			'list_icon',
			[
				'label' => esc_html__( 'List Icon', 'shadowcore' ),
				'type' => Controls_Manager::ICONS,
				'default' => ( array_key_exists('list_icon', $defs) ? $defs[ 'list_icon' ] : [ 
					'value' => 'eicon-check-circle-o',
					'library' => '',
				 ] ),
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--list li i' => 'color: {{VALUE}};'
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('icon_size', $defs) ? $defs[ 'icon_size' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--list li i' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_responsive_control(
			'icon_spacing',
			[
				'label' => esc_html__( 'Icon Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('icon_spacing', $defs) ? $defs[ 'icon_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 15,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--list li i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_responsive_control(
			'icon_v_shift',
			[
				'label' => esc_html__( 'Icon Vertical Shift', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -20,
						'max' => 20
					],
				],
				'default' => ( array_key_exists('icon_v_shift', $defs) ? $defs[ 'icon_v_shift' ] : [ 
					'unit' => 'px',
                    'size' => 3,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--list li i' => 'transform: translateY({{SIZE}}{{UNIT}})',
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_control(
			'divider-style-content03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'features_type' => 'list'
				]
			]
		);
		$this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'List Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('items_spacing', $defs) ? $defs[ 'items_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--list li:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'features_type' => 'list'
				]
			]
		);

		$this->end_controls_section();

		# Section: Button Style
		$this->start_controls_section(
			'section_style_button',
			[
				'label' => esc_html__( 'Footer and Button', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'button_state' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'footer_padding',
			[
				'label' => esc_html__( 'Footer Spacing', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('footer_padding', $defs) ? $defs[ 'footer_padding' ] : [ 
					'top' => '0',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => false,
					'unit' => 'px'
				 ] ),
			]
		);
		$this->add_control(
			'footer_bg',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--footer' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-style-footer01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'button_align',
			[
				'label' => esc_html__( 'Button Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('button_align', $defs) ? $defs[ 'button_align' ] : 'center' ),
				'toggle' => false,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item--footer' => 'justify-content: {{VALUE}};'
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => esc_html__( 'Button Inner Spacing', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-price-item-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('button_padding', $defs) ? $defs[ 'button_padding' ] : [] ),
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-price-item-button'
			]
		);
		$this->add_control(
			'divider-style-footer02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->start_controls_tabs(
			'button_styles'
		);
			$this->start_controls_tab(
				'button_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' ),
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_normal_border',
						'label' => esc_html__( 'Border', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-price-item-button',
					]
				);
				$this->add_responsive_control(
					'button_normal_radius',
					[
						'label' => esc_html__( 'Border Radius', 'shadowcore' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .shadowcore-price-item-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						'default' => ( array_key_exists('button_normal_radius', $defs) ? $defs[ 'button_normal_radius' ] : [ 
							'top' => '0',
							'right' => '0',
							'bottom' => '0',
							'left' => '0',
							'isLinked' => true,
							'unit' => 'px'
						] ),
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_normal_shadow',
						'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-price-item-button',
					]
				);
				$this->add_control(
					'divider-style-button01',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_control(
					'button_normal_bg',
					[
						'label' => esc_html__( 'Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-price-item-button' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_normal_color',
					[
						'label' => esc_html__( 'Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-price-item-button' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'button_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' ),
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_hover_border',
						'label' => esc_html__( 'Hover: Border', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-price-item-button:hover',
					]
				);
				$this->add_responsive_control(
					'button_hover_radius',
					[
						'label' => esc_html__( 'Hover: Border Radius', 'shadowcore' ),
						'type' => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-price-item-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						'default' => ( array_key_exists('button_hover_radius', $defs) ? $defs[ 'button_hover_radius' ] : [ 
							'top' => '0',
							'right' => '0',
							'bottom' => '0',
							'left' => '0',
							'isLinked' => true,
							'unit' => 'px'
						] ),
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_hover_shadow',
						'label' => esc_html__( 'Hover: Box Shadow', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-price-item-button:hover',
					]
				);
				$this->add_control(
					'divider-style-button02',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_control(
					'button_hover_bg',
					[
						'label' => esc_html__( 'Hover: Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-price-item-button:hover' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_hover_color',
					[
						'label' => esc_html__( 'Hover: Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-price-item-button:hover' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings();
		?>
		<div class="shadowcore-price-item-wrap">
			<div class="shadowcore-price-item <?php echo ( 'yes' == $settings[ 'most_popular' ] ? 'is-popular' : '' ); ?>">
				<?php
				if ( 'yes' == $settings[ 'most_popular' ] ) {
					echo '<div class="shadowcore-price-item-mp-label-wrap">';
					echo '<div class="shadowcore-price-item-mp-label">'. esc_html( $settings[ 'most_popular_label' ] ) .'</div>';
					echo '</div><!-- .shadowcore-price-item-mp-label-wrap -->';
				}
				
				?>
				<div class="shadowcore-price-item--head">
					<div class="shadowcore-price-item--heading">
						<?php echo esc_html( $settings[ 'heading' ] ); ?>
					</div><!-- .shadowcore-price-item--heading -->
					<div class="shadowcore-price-item--price-wrap">
						<div class="shadowcore-price-item--price">
							<?php echo esc_html( $settings[ 'price' ] ); ?>
						</div>
						<div class="shadowcore-price-item--price-descr">
							<?php echo esc_html( $settings[ 'price_descr' ] ); ?>
						</div>
					</div><!-- .shadowcore-price-item--price-wrap -->
				</div><!-- .shadowcore-price-item--head -->
				<div class="shadowcore-price-item--content">
					<?php
					echo '<div class="shadowcore-price-item--list-heading">'. wp_specialchars_decode( $settings[ 'features_heading' ] ) .'</div>';
					switch ( $settings[ 'features_type' ] ) {
						# List Features
						case 'list':
							echo '<ul class="shadowcore-price-item--list">';
							foreach (  $settings[ 'features_list' ] as $item ) {
								echo '<li><i class="'. esc_attr( $settings[ 'list_icon' ][ 'value' ] ) .'"></i>'. esc_html( $item[ 'feature_text' ] ) .'</li>';
							}
							echo '</ul><!-- .shadowcore-price-item--list -->';
						break;
						# Description Features
						case 'descr':
							echo '<div class="shadowcore-price-item--descr">'. esc_html( $settings[ 'features_descr' ] ) .'</div>';
						break;
						# HTML Code Features
						case 'html':
							echo wp_specialchars_decode( $settings[ 'features_html' ] );
						break;
					}
					?>
				</div><!-- .shadowcore-price-item--content -->
				<?php
				if ( 'yes' == $settings[ 'button_state' ] ) {
					$link_url = $settings[ 'link_url' ];
					echo '
					<div class="shadowcore-price-item--footer">
						<a href="' . esc_url( $link_url[ 'url' ] ) . '"' . ( $link_url[ 'is_external' ] ? ' target="_blank"' : ' target="_self"' ) . ( $link_url[ 'nofollow' ] ? ' rel="nofollow"' : '' ) . ' class="shadowcore-price-item-button '. st_get_theme_prefix() . '-button">'. esc_html( $settings[ 'button_text' ] ) .'</a>
					</div><!-- .shadowcore-price-item--footer -->
					';
				}
				?>
			</div><!-- .shadowcore-price-item -->
		</div><!-- .shadowcore-price-item-wrap -->
		<?php
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Price_Table_Widget() );