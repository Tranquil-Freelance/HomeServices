<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Gallery_Slider_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-gallery-slider';
	}
	
	public function get_title() {
		return esc_html__( 'Gallery: Slider', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-slides';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
    
    public function get_script_depends() {
		return [ 'shadowcore_slide_gallery' ];
	}
	
	protected function register_controls() {	
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );
        	
		# TAB: CONTENT
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Gallery Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$this->add_control(
			'gallery',
			[
				'label' => esc_html__( 'Add Images', 'shadowcore' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		$this->add_control(
			'randomize_images',
			[
				'label' => esc_html__( 'Randomize Gallery?', 'shadowcore' ),
				'description' => esc_html__( 'Shuffle images on each time gallery loads.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('randomize_images', $defs) ? $defs[ 'randomize_images' ] : 'no' ),
			]
		);
		$this->add_control(
			'divider-gallery',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        $this->add_control(
			'caption_state',
			[
				'label' => esc_html__( 'Show Image Caption?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('caption_state', $defs) ? $defs[ 'caption_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-slider-captions--',
			]
		);
        $this->add_control(
			'descr_state',
			[
				'label' => esc_html__( 'Show Image Description?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('descr_state', $defs) ? $defs[ 'descr_state' ] : 'no' ),
                'condition' => [
					'caption_state' => 'yes'
				],
                'prefix_class' => 'shadowcore-slider-descr--',
			]
		);
        
        $this->add_control(
			'divider-caption',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'height_type',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('height_type', $defs) ? $defs[ 'height_type' ] : 'screen' ),
                'options' => [
					'screen'  => esc_attr__( 'Fit to Screen', 'shadowcore' ),
					'custom'  => esc_attr__( 'Custom', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-slider-height--',
			]
		);
        
        $this->add_responsive_control(
			'custom_height',
			[
				'label' => esc_attr__( 'Gallery Height, px', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height', $defs) ? $defs[ 'custom_height' ] : [ 
					'unit' => 'vh',
                    'size' => 100,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-height--custom .shadowcore-slider-wrap' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'height_type' => 'custom'
				],
			]
		);
        
		$this->add_control(
			'custom_height_reduce',
			[
				'label' => esc_html__( 'Reduce Height?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'prefix_class' => 'shadowcore-slider-height-reduce--',
				'default' => ( array_key_exists('custom_height_reduce', $defs) ? $defs[ 'custom_height_reduce' ] : 'no' ),
				'condition' => [
					'height_type' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'custom_height_reduce_val',
			[
				'label' => esc_attr__( 'Height Reduction Value', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
                        'max' => 1280
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height_reduce_val', $defs) ? $defs[ 'custom_height_reduce_val' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-height--custom.shadowcore-slider-height-reduce--yes .shadowcore-slider-wrap' => 'height: calc({{custom_height.SIZE}}{{custom_height.UNIT}} - {{SIZE}}{{UNIT}});',
				],
                'condition' => [
					'height_type' => 'custom',
					'custom_height_reduce' => 'yes',
				],
			]
		);
		$this->add_control(
			'divider-gallery-fit',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'fit_type',
			[
				'label' => esc_attr__( 'Content Fitting', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('fit_type', $defs) ? $defs[ 'fit_type' ] : 'cover' ),
                'options' => [
					'cover'  => esc_attr__( 'Cover', 'shadowcore' ),
					'fit-all'  => esc_attr__( 'Fit Always', 'shadowcore' ),
					'fit-v'  => esc_attr__( 'Fit Vertical', 'shadowcore' ),
					'fit-h'  => esc_attr__( 'Fit Horizontal', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-slider--',
			]
		);
        
        $this->add_control(
			'slide_type',
			[
				'label' => esc_attr__( 'Transition Effect', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('slide_type', $defs) ? $defs[ 'slide_type' ] : 'simple' ),
                'options' => [
					'simple'  => esc_attr__( 'Simple', 'shadowcore' ),
					'parallax'  => esc_attr__( 'Parallax', 'shadowcore' ),
					'fade'  => esc_attr__( 'Fade', 'shadowcore' )
				]
			]
		);
        
        $this->add_control(
			'divider-gallery-nav',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'slider_nav',
			[
				'label' => esc_attr__( 'Navigation Type', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('slider_nav', $defs) ? $defs[ 'slider_nav' ] : 'none' ),
                'options' => [
					'none'  => esc_attr__( 'None', 'shadowcore' ),
					'arrows'  => esc_attr__( 'Arrows', 'shadowcore' ),
					'text'  => esc_attr__( 'Text Labels', 'shadowcore' ),
					'dots'  => esc_attr__( 'Dots', 'shadowcore' ),
				]
			]
		);
        
        $this->add_control(
			'slider_nav_label_prev',
			[
				'label' => esc_html__( '"Prev" label:', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Prev', 'shadowcore' ),
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'slider_nav_label_next',
			[
				'label' => esc_html__( '"Next" label:', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Next', 'shadowcore' ),
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'divider-gallery-anim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
			'zoom',
			[
				'label' => esc_html__( 'Zoom Factor, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 200
					],
				],
				'default' => ( array_key_exists('zoom', $defs) ? $defs[ 'zoom' ] : [ 
					'unit' => '%',
                    'size' => 100,
				 ] ),
			]
		);
        $this->add_control(
            'transition',
            [
				'label' => esc_attr__( 'Transition Speed, ms', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
				'default' => ( array_key_exists('transition', $defs) ? $defs[ 'transition' ] : '1000' ),
                'min' => '500',
				'step' => '100',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider[data-type="fade"].is-animating .shadowcore-slider-item' => 'transition: opacity {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider[data-type="simple"].is-animating .shadowcore-slider-item' => 'transition: transform {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider[data-type="parallax"].is-animating .shadowcore-slider-item' => 'transition: transform {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider.is-animating .shadowcore-slider-item .shadowcore-slider-item--image' => 'transition: transform {{VALUE}}ms;',
				],
            ]
		);
        
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Caption Styles
		$this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Gallery', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'overlay_state',
			[
				'label' => esc_html__( 'Gallery Overlay', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'shadowcore' ),
				'label_off' => esc_html__( 'Off', 'shadowcore' ),
				'default' => ( array_key_exists('overlay_state', $defs) ? $defs[ 'overlay_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-slider-overlay--',
			]
		);
        $this->add_control(
			'overlay_color',
			[
				'label' => esc_html__( 'Overlay Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'overlay_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-overlay' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-br',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider',
			]
		);
        
		$this->end_controls_section();
        
        $this->start_controls_section(
			'section_styles_caption',
			[
				'label' => esc_html__( 'Caption and Description', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        # Captions Style Section
        $this->add_control(
			'no_captions',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Captions are disabled by the element settings.', 'shadowcore' ),
				'content_classes' => 'shadowcore-elementor-message shadowcore-no-captions',
				'condition' => [
					'caption_state!' => 'yes'
				],
			]
		);
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typo',
				'label' => esc_html__( 'Caption Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-caption',
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        $this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Caption Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-caption' => 'color: {{VALUE}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'descr_typo',
				'label' => esc_html__( 'Description Typography', 'shadowcore' ),
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
				'selector' => '{{WRAPPER}} .shadowcore-slider-description'
			]
		);
        $this->add_control(
			'descr_color',
			[
				'label' => esc_html__( 'Description Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-description' => 'color: {{VALUE}};'
				]
			]
		);
        
        $this->add_control(
			'divider-caption-typo',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'caption_text_align',
			[
				'label' => esc_attr__( 'Caption Text Align', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_text_align', $defs) ? $defs[ 'caption_text_align' ] : 'left' ),
                'options' => [
					'left' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-title > div' => 'text-align: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_v_position',
			[
				'label' => esc_attr__( 'Caption Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_v_position', $defs) ? $defs[ 'caption_v_position' ] : 'flex-end' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-item' => 'align-items: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'caption_h_position',
			[
				'label' => esc_attr__( 'Caption Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('caption_h_position', $defs) ? $defs[ 'caption_h_position' ] : 'flex-start' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition' => [
					'caption_state' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-item' => 'justify-content: {{VALUE}};',
				],
			]
		);
        
        $this->add_control(
			'divider-caption-padding',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
		$this->add_responsive_control(
			'caption_margin',
			[
				'label' => esc_html__( 'Caption Margin', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_margin', $defs) ? $defs[ 'caption_margin' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);

        $this->add_responsive_control(
			'caption_padding',
			[
				'label' => esc_html__( 'Caption Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_padding', $defs) ? $defs[ 'caption_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'caption_br',
			[
				'label' => esc_html__( 'Caption Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_br', $defs) ? $defs[ 'caption_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
        $this->add_responsive_control(
			'description_spacing',
			[
				'label' => esc_html__( 'Description Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('description_spacing', $defs) ? $defs[ 'description_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-description' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'descr_state' => 'yes',
                    'caption_state' => 'yes'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'caption_shadow',
				'label' => esc_html__( 'Caption Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-title',
				'condition' => [
					'caption_state' => 'yes'
				],
			]
		);
        
		$this->end_controls_section();
        
        # Navigation Style Section
        $this->start_controls_section(
			'section_styles_nav',
			[
				'label' => esc_html__( 'Navigation', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'no_nav',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Navigation elements are disabled by the "Navigation Type" option.', 'shadowcore' ),
				'content_classes' => 'shadowcore-elementor-message shadowcore-no-captions',
				'condition' => [
					'slider_nav' => 'none'
				],
			]
		);
        
        $this->add_control(
			'nav_v_position',
			[
				'label' => esc_attr__( 'Navigation Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('nav_v_position', $defs) ? $defs[ 'nav_v_position' ] : 'bottom' ),
                'options' => [
					'top' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
                'prefix_class' => 'shadowcore-slider-nav--',
			]
		);
        $this->add_control(
			'nav_h_position',
			[
				'label' => esc_attr__( 'Navigation Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('nav_h_position', $defs) ? $defs[ 'nav_h_position' ] : 'center' ),
                'options' => [
					'left' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
                'prefix_class' => 'shadowcore-slider-nav--',
			]
		);
        
        $this->add_control(
			'divider-nav-position',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'nav_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('nav_spacing', $defs) ? $defs[ 'nav_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--arrows a:last-child' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-slider-nav--text a:last-child' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a:not(:first-child)' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_responsive_control(
			'nav_padding',
			[
				'label' => esc_html__( 'Navigation Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('nav_padding', $defs) ? $defs[ 'nav_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_control(
			'divider-nav-spacing',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'nav_size',
			[
				'label' => esc_html__( 'Items Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('nav_size', $defs) ? $defs[ 'nav_size' ] : [ 
					'unit' => 'px',
                    'size' => 12,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a i' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'slider_nav' => [ 'dots','arrows' ]
				],
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'nav_typo',
				'label' => esc_html__( 'Labels Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a',
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'divider-nav-borders',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'nav_dots_border',
                'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a',
                'condition' => [
                    'slider_nav' => 'dots'
                ]
            ]
        );
        $this->add_control(
			'nav_dots_radius',
			[
				'label' => esc_html__( 'Dots Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ '%', 'px' ],
				'default' => ( array_key_exists('nav_dots_radius', $defs) ? $defs[ 'nav_dots_radius' ] : [ 
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'isLinked' => true,
					'unit' => '%'
				 ] ),
                'condition' => [
					'slider_nav' => 'dots',
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'nav_dots_shadow',
				'label' => esc_html__( 'Dots Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a',
				'condition' => [
					'slider_nav' => 'dots',
				],
			]
		);
        
        $this->add_control(
			'divider-nav-block',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        
        $this->add_control(
			'nav_dots_wrapper',
			[
				'label' => esc_html__( 'Show Dots Wrapper?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('nav_dots_wrapper', $defs) ? $defs[ 'nav_dots_wrapper' ] : 'no' ),
                'prefix_class' => 'shadowcore-slider-nav-wrap--',
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        $this->add_control(
			'nav_wrapper_bg',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'background-color: {{VALUE}};'
				]
			]
		);
        $this->add_responsive_control(
			'nav_wrapper_padding',
			[
				'label' => esc_html__( 'Inner Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('nav_wrapper_padding', $defs) ? $defs[ 'nav_wrapper_padding' ] : [ 
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'divider-before-wrap-border',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav' => 'dots',
				],
			]
		);
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'nav_wrapper_border',
                'selector' => '{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots',
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
            ]
        );
        $this->add_control(
			'divider-after-wrap-border',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav' => 'dots',
				],
			]
		);
        
        $this->add_control(
			'nav_wrapper_radius',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ '%', 'px' ],
				'default' => ( array_key_exists('nav_wrapper_radius', $defs) ? $defs[ 'nav_wrapper_radius' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'nav_wrapper_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots',
				'condition' => [
					'slider_nav' => 'dots',
				],
			]
		);
        
        $this->add_control(
			'divider-nav-colors',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_control(
			'nav_color_n',
			[
				'label' => esc_html__( 'Normal Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav!' => 'none'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a' => 'color: {{VALUE}}',
				]
			]
		);
        $this->add_control(
			'nav_color_h',
			[
				'label' => esc_html__( 'Hover Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav!' => 'none'
				],
                'return_value' => 'no',
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a:hover' => 'background-color: {{VALUE}};',
                    'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a:hover' => 'color: {{VALUE}}',
                    'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a:hover' => 'color: {{VALUE}}',
				]
			]
		);
        $this->add_control(
			'nav_color_a',
			[
				'label' => esc_html__( 'Active Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a.is-active' => 'background-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'divider-nav-border-colors',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
			]
		);
        $this->add_control(
			'nav_border_n',
			[
				'label' => esc_html__( 'Normal Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'border-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'nav_border_h',
			[
				'label' => esc_html__( 'Hover Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a:hover' => 'border-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'nav_border_a',
			[
				'label' => esc_html__( 'Active Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a.is-active' => 'border-color: {{VALUE}};',
				]
			]
		);
        
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$gallery = $settings[ 'gallery' ];
		$randomize_images = $settings[ 'randomize_images' ];
        $nav_type = $settings[ 'slider_nav' ];
        
		if ( empty( $gallery ) ) {
            echo '<div class="shadowcore-widget-holder"><i class="'. esc_attr( $this->get_icon() ) .'"></i><span>'. esc_html__( 'No Images', 'shadowcore' ) .'</span></div>';
		} else {
            if ( count( $gallery ) == 2 ) {
                $gallery = array_merge($gallery, $gallery);
			}
            if ( 'yes' == $randomize_images ) {
                shuffle( $gallery );
			}
            ?>
            <div class="shadowcore-slider-wrap shadowcore-slider-nav--<?php echo esc_attr( $nav_type ); ?>" data-nav="<?php echo esc_attr( $nav_type ); ?>">
                <div class="shadowcore-slider <?php echo esc_attr( count($gallery) == 1 ? 'is-single' : ''); ?>" data-type="<?php echo esc_attr( $settings['slide_type'] ); ?>" data-zoom="<?php echo esc_attr( $settings[ 'zoom' ][ 'size' ] ); ?>">
                    <?php
                    $i = 0;
                    foreach ( $gallery as $item ) {
                        $image_post = get_post( $item[ 'id' ] );
                        $image_url = wp_get_attachment_url( $item[ 'id' ] );
                        $caption = $image_post->post_excerpt;
                        $descr = $image_post->post_content;
                        ?>
                        <div class="shadowcore-slider-item" data-ind="<?php echo esc_attr( $i ); ?>">
                            <div class="shadowcore-slider-item--image" data-src="<?php echo esc_url( $image_url ); ?>"></div>
                            <div class="shadowcore-slider-overlay"></div>
                            <div class="shadowcore-slider-title">
                                <div class="shadowcore-slider-caption"><?php echo esc_html( $caption ); ?></div>
                                <div class="shadowcore-slider-description"><?php echo esc_html( $descr ); ?></div>
                            </div><!-- .shadowcore-slider-title -->
                        </div>
                    <?php 
                        $i++;
                    } 
                    ?>
                </div><!-- .shadowcore-slider -->
                <?php 
                # Navigation
                if ( 'none' !== $nav_type && count( $gallery) > 1 ) {
                    echo '<nav class="shadowcore-slider-nav">';
                    if ( 'arrows' == $nav_type) {
                        # Arrows Navigation
                        echo '
                        <a href="javascript:void(0)" class="shadowcore-slider-prev">
                            <i class="eicon-chevron-left"></i>
                        </a>
                        <a href="javascript:void(0)" class="shadowcore-slider-next">
                            <i class="eicon-chevron-right"></i>
                        </a>
                        ';
                    }
                    if ( 'text' == $nav_type) {
                        # Text Navigation
                        echo '
                        <a href="javascript:void(0)" class="shadowcore-slider-prev">
                            '. esc_html( $settings[ 'slider_nav_label_prev' ]) .'
                        </a>
                        <a href="javascript:void(0)" class="shadowcore-slider-next">
                            '. esc_html( $settings[ 'slider_nav_label_next' ]) .'
                        </a>
                        ';

                    }
                    if ( 'dots' == $nav_type) {
                        echo '<div class="shadowcore-slider-dots">';
                        # Dots Navigation
                        $c = 0;
                        while ( $c < count($gallery) ) {
                            echo '<a href="javascript:void(0)" data-ind="'. esc_attr( $c ) .'" class="shadowcore-slider-dot"></a>';
                            $c++;
                        }
                        echo '</div><!-- .shadowcore-slider-dots -->';
                    }
                    echo '</nav><!-- .shadowcore-slider-nav -->';
                }
                ?>
            </div><!-- .shadowcore-slider-wrap -->
            <?php
        }
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Gallery_Slider_Widget() );