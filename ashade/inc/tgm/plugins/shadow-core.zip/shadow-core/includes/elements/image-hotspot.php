<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Image_Hotspot_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-image-hotspot';
	}
	
	public function get_title() {
		return esc_html__( 'Image Hotspot', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-image-hotspot';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
	
	protected function register_controls() {		
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );

		# TAB: CONTENT
		# Section: Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Select Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'divider-image',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'crop_image',
			[
				'label' => esc_html__( 'Customize Size', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);		
		$this->add_control(
			'image_width',
			[
				'label' => esc_html__( 'Image Width', 'shadowcore' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 0,
				'default' => 1920,
				'condition' => [
					'crop_image' => 'yes'
				]
			]
		);
		$this->add_control(
			'image_height',
			[
				'label' => esc_html__( 'Image Height', 'shadowcore' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 0,
				'default' => 1280,
				'condition' => [
					'crop_image' => 'yes'
				]
			]
		);
		$this->add_control(
			'display_on',
			[
				'label' => esc_html__( 'Show Description on', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('display_on', $defs) ? $defs[ 'display_on' ] : 'hover' ),
				'options' => [
					'hover' => esc_html__( 'Hover', 'shadowcore' ),
					'click' => esc_html__( 'Click', 'shadowcore' )
				]
			]
		);
		$this->add_control(
			'divider-content01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		# Spots
		$repeater = new Repeater();

		$repeater->add_responsive_control(
			'pos_x',
			[
				'label' => esc_html__( 'Position X', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => [ 
					'unit' => '%',
                    'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$repeater->add_responsive_control(
			'pos_y',
			[
				'label' => esc_html__( 'Position Y', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => [ 
					'unit' => '%',
                    'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$repeater->add_control(
			'divider-item02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'link_state',
			[
				'label' => esc_html__( 'Add Link?', 'shadowcore' ),
				'description' => esc_html__( 'Use it combine with "Show on Hover" option.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'true',
				],
				'condition' => [
					'link_state' => 'yes',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);
		$repeater->add_control(
			'divider-item03',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'info_pos',
			[
				'label' => esc_html__( 'Info Position', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('info_pos', $defs) ? $defs[ 'info_pos' ] : 'top' ),
				'options' => [
					'top' => esc_html__( 'On Top', 'shadowcore' ),
					'right' => esc_html__( 'On Right', 'shadowcore' ),
					'bottom' => esc_html__( 'On Bottom', 'shadowcore' ),
					'left' => esc_html__( 'On Left', 'shadowcore' ),
				],
			]
		);
		$repeater->add_control(
			'divider-item04',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'item_descr',
			[
				'label' => esc_html__( 'Description', 'shadowcore' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'shadowcore' ),
				'placeholder' => __( 'Type your description here', 'shadowcore' ),
			]
		);
		$this->add_control(
			'hotspots',
			[
				'label' => esc_html__( 'Hotspots', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'prevent_empty' => false,
				'default' => [
				]
			]
		);
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Image
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Image Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-hotspot-image',
			]
		);
		$this->end_controls_section();
		
		# Section: Main Dot
		$this->start_controls_section(
			'section_main_dot',
			[
				'label' => esc_html__( 'Main Dot', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_responsive_control(
			'dot_size',
			[
				'label' => esc_html__( 'Dot Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('dot_size', $defs) ? $defs[ 'dot_size' ] : [ 
					'unit' => 'px',
                    'size' => 12,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot' => 'width: calc({{SIZE}}{{UNIT}} * 2); height: calc({{SIZE}}{{UNIT}} * 2);',
					'{{WRAPPER}} .shadowcore-hotspot:after' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'dot_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-hotspot:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('dot_br', $defs) ? $defs[ 'dot_br' ] : [ 
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'isLinked' => true,
					'unit' => '%'
				]),
			]
		);
		$this->add_control(
			'divider-dot-main01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		# State Tabs
		$this->start_controls_tabs( 'dot_styles_tab' );
		
			# Tab: Normal
			$this->start_controls_tab(
				'dot_main_normal',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' )
				]
			);
				$this->add_control(
					'dot_color',
					[
						'label' => esc_html__( 'Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-hotspot:after' => 'background-color: {{VALUE}};',
						]
					]
				);
				$this->add_control(
					'divider-dot-main01_n',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'dot_border',
						'selector' => '{{WRAPPER}} .shadowcore-hotspot:after',
					]
				);
				$this->add_control(
					'divider-dot-main02_n',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'dot_box_shadow',
						'label' => esc_html__( 'Shadow', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-hotspot:after',
					]
				);
			$this->end_controls_tab();

			# Tab: Hover
			$this->start_controls_tab(
				'dot_main_hover',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' )
				]
			);
				$this->add_responsive_control(
					'dot_scale',
					[
						'label' => esc_html__( 'Hoveres Dot Size, %', 'shadowcore' ),
						'type' => Controls_Manager::SLIDER,
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 200
							],
						],
						'default' => ( array_key_exists('dot_scale', $defs) ? $defs[ 'dot_scale' ] : [ 
							'unit' => 'px',
							'size' => 120,
						] ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:after' => 'transform: 	scale(calc({{SIZE}} * 0.01));',
						],
					]
				);
				$this->add_control(
					'divider-dot-main00_h',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_control(
					'dot_color_h',
					[
						'label' => esc_html__( 'Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:after' => 'background-color: {{VALUE}};',
						]
					]
				);
				$this->add_control(
					'divider-dot-main01_h',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'dot_border_h',
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:after',
					]
				);
				$this->add_control(
					'divider-dot-main02_h',
					[
						'type' => Controls_Manager::DIVIDER,
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'dot_box_shadow_h',
						'label' => esc_html__( 'Shadow', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:after',
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();
		
		$this->end_controls_section();

		# Section: Additional Dot
		$this->start_controls_section(
			'section_add_dot',
			[
				'label' => esc_html__( 'Additional Dot', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'add_dot',
			[
				'label' => esc_html__( 'Show Additional Dot', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('add_dot', $defs) ? $defs[ 'add_dot' ] : 'yes' ),
				'prefix_class' => 'shadowcore-hotspot-add--',
			]
		);
		$this->add_responsive_control(
			'add_dot_size',
			[
				'label' => esc_html__( 'Dot Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('add_dot_size', $defs) ? $defs[ 'add_dot_size' ] : [ 
					'unit' => 'px',
                    'size' => 24,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot:before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'add_dot' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'add_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('add_br', $defs) ? $defs[ 'add_br' ] : [ 
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'isLinked' => true,
					'unit' => '%'
				]),
				'condition' => [
					'add_dot' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-dot-add01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'add_dot' => 'yes'
				]
			]
		);
		# State Tabs
		$this->start_controls_tabs( 'add_dot_styles_tab' );
		
			# Tab: Normal
			$this->start_controls_tab(
				'dot_add_normal',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' ),
					'condition' => [
						'add_dot' => 'yes'
					]
				]
			);
				$this->add_control(
					'add_color',
					[
						'label' => esc_html__( 'Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-hotspot:before' => 'background-color: {{VALUE}};',
						],
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'divider-dot-add01_n',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'add_border',
						'selector' => '{{WRAPPER}} .shadowcore-hotspot:before',
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'divider-dot-add02_n',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'add_box_shadow',
						'label' => esc_html__( 'Shadow', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-hotspot:before',
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
			$this->end_controls_tab();

			# Tab: Hover
			$this->start_controls_tab(
				'dot_add_hover',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' ),
					'condition' => [
						'add_dot' => 'yes'
					]
				]
			);
				$this->add_responsive_control(
					'add_scale',
					[
						'label' => esc_html__( 'Hoveres Dot Size, %', 'shadowcore' ),
						'type' => Controls_Manager::SLIDER,
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 200
							],
						],
						'default' => ( array_key_exists('add_scale', $defs) ? $defs[ 'add_scale' ] : [ 
							'unit' => 'px',
							'size' => 100,
						] ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:before' => 'transform: translate(-50%, -50%) scale(calc({{SIZE}} * 0.01));',
						],
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'divider-dot-add00_h',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'add_color_h',
					[
						'label' => esc_html__( 'Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:before' => 'background-color: {{VALUE}};',
						],
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'divider-dot-add01_h',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'add_border_h',
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:before',
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_control(
					'divider-dot-add02_h',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'add_box_shadow_h',
						'label' => esc_html__( 'Shadow', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-hotspot:hover:before',
						'condition' => [
							'add_dot' => 'yes'
						]
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'content_width',
			[
				'label' => esc_html__( 'Content Width, PX', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 480
					],
				],
				'default' => ( array_key_exists('content_width', $defs) ? $defs[ 'content_width' ] : [ 
					'unit' => 'px',
					'size' => 150,
				] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'content_spacing',
			[
				'label' => esc_html__( 'Content Spacing, PX', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200
					],
				],
				'default' => ( array_key_exists('content_spacing', $defs) ? $defs[ 'content_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot--on-top .shadowcore-hotspot-descr' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-hotspot--on-right .shadowcore-hotspot-descr' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-hotspot--on-bottom .shadowcore-hotspot-descr' => 'margin-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-hotspot--on-left .shadowcore-hotspot-descr' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('padding', $defs) ? $defs[ 'padding' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
					] ),
			]
		);
		$this->add_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('align', $defs) ? $defs[ 'align' ] : 'left' ),
				'toggle' => false,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'text-align: {{VALUE}}',
				],
			
			]
		);
		$this->add_control(
			'divider-style-content00',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'content_triangle',
			[
				'label' => esc_html__( 'Show Triangle', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('content_triangle', $defs) ? $defs[ 'content_triangle' ] : 'no' ),
				'prefix_class' => 'shadowcore-hotspot-triangles--',
			]
		);
		$this->add_responsive_control(
			'triangle_scale',
			[
				'label' => esc_html__( 'Triangle Size, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200
					],
				],
				'default' => ( array_key_exists('triangle_scale', $defs) ? $defs[ 'triangle_scale' ] : [ 
					'unit' => 'px',
					'size' => 100,
				] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr:before' => 'transform: scale(calc({{SIZE}} * 0.01));',
				],
				'condition' => [
					'content_triangle' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-content01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.shadowcore-hotspot-triangles--yes .shadowcore-hotspot--on-top .shadowcore-hotspot-descr:before' => 'border-color: {{VALUE}} transparent transparent transparent;',
					'{{WRAPPER}}.shadowcore-hotspot-triangles--yes .shadowcore-hotspot--on-right .shadowcore-hotspot-descr:before' => 'border-color: transparent {{VALUE}} transparent transparent;',
					'{{WRAPPER}}.shadowcore-hotspot-triangles--yes .shadowcore-hotspot--on-bottom .shadowcore-hotspot-descr:before' => 'border-color: transparent transparent {{VALUE}} transparent;',
					'{{WRAPPER}}.shadowcore-hotspot-triangles--yes .shadowcore-hotspot--on-left .shadowcore-hotspot-descr:before' => 'border-color: transparent transparent transparent {{VALUE}};',
				]
			]
		);
		$this->add_responsive_control(
			'content_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('content_br', $defs) ? $defs[ 'content_br' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'content_border',
				'selector' => '{{WRAPPER}} .shadowcore-hotspot-descr',
			]
		);
		$this->add_control(
			'divider-style-content02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'content_text_color',
			[
				'label' => esc_html__( 'Text Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-hotspot-descr',
			]
		);
		$this->add_control(
			'divider-style-content03',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'content_shadow',
				'label' => esc_html__( 'Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-hotspot-descr',
			]
		);
		$this->end_controls_section();
		
		# Section: Animation
		$this->start_controls_section(
			'section_animation',
			[
				'label' => esc_html__( 'Animation Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'dot_anim_speed',
			[
				'label' => esc_html__( 'Dot Animation Speed, ms', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'step' => 50,
						'max' => 1000
					],
				],
				'default' => ( array_key_exists('dot_anim_speed', $defs) ? $defs[ 'dot_anim_speed' ] : [ 
					'unit' => 'px',
                    'size' => 200,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot:before' => 'transition: all {{SIZE}}ms;',
					'{{WRAPPER}} .shadowcore-hotspot:after' => 'transition: transform {{SIZE}}ms, background-color {{SIZE}}ms, border {{SIZE}}ms, box-shadow {{SIZE}}ms;',
				],
			]
		);

		$this->add_responsive_control(
			'content_anim_speed',
			[
				'label' => esc_html__( 'Content Animation Speed, ms', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'step' => 50,
						'max' => 1000
					],
				],
				'default' => ( array_key_exists('content_anim_speed', $defs) ? $defs[ 'content_anim_speed' ] : [ 
					'unit' => 'px',
                    'size' => 200,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-hotspot-descr' => 'transition: opacity {{SIZE}}ms;',
				],
			]
		);
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$image = $settings[ 'image' ];
		$image_width = $settings[ 'image_width' ];
		$image_height = $settings[ 'image_height' ];
		$meta = wp_get_attachment_metadata( $image[ 'id' ] );
		$hotspots = $settings[ 'hotspots' ];

		if (is_array( $meta ) ) {
			$o_width = $meta[ 'width' ];
			$o_height = $meta[ 'height' ];
		} else {
			$orig_width = 1200;
			$orig_height = 800;
		}

		if ( ! empty( $image[ 'id' ] ) ) {
			$image_url = wp_get_attachment_url( $image[ 'id' ] );
			if ( 'yes' !== $settings[ 'crop_image' ] ) {
				$image_width = $o_width;
				$image_height = $o_height;
			}
		} else {
			$image_width = 1200;
			$image_height = 800;
			$image_url = Utils::get_placeholder_image_src();
		}
		?>
		<div class="shadowcore-hotspot-wrap <?php echo esc_attr( $settings['display_on'] == 'click' ? 'show-on-click' : 'show-on-hover'); ?>">
			<div class="shadowcore-hotspot-image shadowcore-div-image" data-src="<?php echo esc_url( $image_url ); ?>">
				<img 
					src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $image_width ); ?>%20<?php echo absint( $image_height ); ?>'%3E%3C/svg%3E"
					alt="<?php echo esc_attr( get_post_meta( $image[ 'id' ], '_wp_attachment_image_alt', true ) ); ?>" 
					width="<?php echo esc_attr( $image_width ); ?>" 
					height="<?php echo esc_attr( $image_height ); ?>">
				<?php
					if ( count( $hotspots ) ) {
						foreach (  $hotspots as $item ) {
							?>
							<div class="shadowcore-hotspot elementor-repeater-item-<?php echo esc_attr( $item['_id'] ) . ' shadowcore-hotspot--on-' . esc_attr( $item['info_pos'] ); ?>">
								<?php
								if ( $item['link_state'] )	 {
									$link = $item[ 'link_url' ];
									if ( ! empty( $link[ 'url' ] ) ) {
										echo '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . '></a>';
									}
								}
								?>
								<div class="shadowcore-hotspot-descr">
									<?php echo wp_specialchars_decode( $item['item_descr'] ); ?>
								</div><!-- .shadowcore-hotspot-descr -->
							</div><!-- .shadowcore-carousel-card -->
							<?php		
						}	
					}
				?>
			</div><!-- .shadowcore-hotspot-image -->
        </div><!-- .shadowcore-hotspot-wrap -->
		<?php
	}
	protected function content_template() {
		?>
		<div class="shadowcore-hotspot-wrap edit-mode">
			<div class="shadowcore-hotspot-image shadowcore-div-image is-loaded" data-src="{{ settings.image.url }}" style="background-image:url({{ settings.image.url }});">
				<# if ( settings.crop_image == 'yes' ) { #>
				<img 
					src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20{{ settings.image_width }}%20{{ settings.image_height }}'%3E%3C/svg%3E"
					width="{{ settings.image_width }}" 
					height="{{ settings.image_height }}">
				<# } else { #>
					<img src="{{ settings.image.url }}">
				<# } #>
				<# if ( settings.hotspots.length ) { #>
					<# _.each( settings.hotspots, function( item ) { #>
						<div class="shadowcore-hotspot elementor-repeater-item-{{ item._id }} shadowcore-hotspot--on-{{ item.info_pos }}">
							<div class="shadowcore-hotspot-descr">{{{ item.item_descr }}}</div>
						</div>
					<# }); #>
				<# } #>
			</div>
        </div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Image_Hotspot_Widget() );