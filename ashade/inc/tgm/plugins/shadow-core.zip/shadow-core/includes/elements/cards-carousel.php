<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Cards_Carousel_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-cards-carousel';
	}
	
	public function get_title() {
		return esc_html__( 'Cards Carousel', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-carousel';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
	
	public function get_script_depends() {
		return [ 'owl-carousel' ];
	}
		
	public function get_style_depends() {
		return [ 'owl-carousel' ];
	}

	protected function register_controls() {	
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );
        	
		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
				],
			]
		);
		$repeater->add_control(
			'divider-content01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Heading', 'shadowcore' )
			]
		);
		$repeater->add_control(
			'caption',
			[
				'label' => esc_html__( 'Caption', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Caption', 'shadowcore' )
			]
		);
		
		$repeater->add_control(
			'divider-content02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'true',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);

		$this->add_control(
			'card_item',
			[
				'label' => esc_html__( 'Cards', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ heading }}}',
				'default' => [
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'heading' => esc_html__( 'Item Heading', 'shadowcore' ),
						'caption' => esc_html__( 'Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'heading' => esc_html__( 'Item Heading', 'shadowcore' ),
						'caption' => esc_html__( 'Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'heading' => esc_html__( 'Item Heading', 'shadowcore' ),
						'caption' => esc_html__( 'Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
				]
			]
		);
		$this->add_control(
			'divider-content',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'columns',
			[
				'label' => esc_html__( 'Items on Screen', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 5,
						'step' => 0.5
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'default' => ( array_key_exists('columns_desktop', $defs) ? $defs[ 'columns_desktop' ] : [ 
					'unit' => 'px',
                    'size' => 3,
				]),
				'tablet_default' => ( array_key_exists('columns_tablet', $defs) ? $defs[ 'columns_tablet' ] : [ 
					'unit' => 'px',
                    'size' => 3,
				]),
				'mobile_default' => ( array_key_exists('columns_mobile', $defs) ? $defs[ 'columns_mobile' ] : [ 
					'unit' => 'px',
                    'size' => 1.5,
				]),
			]
		);
		$this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'default' => ( array_key_exists('items_spacing_desktop', $defs) ? $defs[ 'items_spacing_desktop' ] : [ 
					'unit' => 'px',
                    'size' => 40,
				]),
				'tablet_default' => ( array_key_exists('items_spacing_tablet', $defs) ? $defs[ 'items_spacing_tablet' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				]),
				'mobile_default' => ( array_key_exists('items_spacing_mobile', $defs) ? $defs[ 'items_spacing_mobile' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				]),
			]
		);
		$this->add_control(
			'divider-image-size',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'crop_custom',
			[
				'label' => esc_html__( 'Crop Image', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('crop_custom', $defs) ? $defs[ 'crop_custom' ] : 'no' ),
			]
		);
		$this->add_control(
            'image_width',
            [
                'label' => esc_html__( 'Image Width', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('image_width', $defs) ? $defs[ 'image_width' ] : '800' ),
                'min' => '100',
				'max' => '3840',
				'step' => '1',
				'condition' => [
					'crop_custom' => 'yes'
				],
            ]
		);
		$this->add_control(
            'image_height',
            [
                'label' => esc_html__( 'Image Height', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('image_height', $defs) ? $defs[ 'image_height' ] : '1200' ),
                'min' => '100',
				'max' => '2160',
				'step' => '1',
				'condition' => [
					'crop_custom' => 'yes'
				],
            ]
		);
		$this->add_control(
			'divider-toggles',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'items_center',
			[
				'label' => esc_html__( 'Center Items', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('items_center', $defs) ? $defs[ 'items_center' ] : 'no' ),
			]
		);
		$this->add_control(
			'loop',
			[
				'label' => esc_html__( 'Loop', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('loop', $defs) ? $defs[ 'loop' ] : 'yes' ),
			]
		);
		$this->add_control(
			'auto_height',
			[
				'label' => esc_html__( 'Auto Height', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('auto_height', $defs) ? $defs[ 'auto_height' ] : 'yes' ),
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('autoplay', $defs) ? $defs[ 'autoplay' ] : 'no' ),
			]
		);
		$this->add_control(
			'pause',
			[
				'label' => esc_html__( 'Pause on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('autoplay', $defs) ? $defs[ 'autoplay' ] : 'yes' ),
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-transitions',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);
		$this->add_control(
			'play_speed',
			[
				'label' => esc_html__( 'Autoplay Speed, ms', 'shadowcore' ),
				'label_block' => false,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('play_speed', $defs) ? $defs[ 'play_speed' ] : '3000' ),
				'condition' => [
					'autoplay' => 'yes'
				]
			]
		);
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Image Style
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'image_swap',
			[
				'label' => esc_html__( 'Heading about the Image', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('image_swap', $defs) ? $defs[ 'image_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-cards-carousel-image-swap--',
			]
		);
		$this->add_responsive_control(
			'image_spacing',
			[
				'label' => esc_html__( 'Image Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('image_spacing', $defs) ? $defs[ 'image_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 12,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-carousel-card__image' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-top: 0;',
					'{{WRAPPER}}.shadowcore-cards-carousel-image-swap--yes .shadowcore-carousel-card__image' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
				],
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-div-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-div-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				] ),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Image Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-div-image',
			]
		);
		$this->end_controls_section();

		# Section: Heading Style
		$this->start_controls_section(
			'section_style_heading',
			[
				'label' => esc_html__( 'Heading and Caption', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'heading_swap',
			[
				'label' => esc_html__( 'Caption below Heading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('heading_swap', $defs) ? $defs[ 'heading_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-cards-carousel-heading-swap--',
			]
		);
		$this->add_responsive_control(
			'heading_spacing',
			[
				'label' => esc_html__( 'Heading Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('heading_spacing', $defs) ? $defs[ 'heading_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 5,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-carousel-card__heading' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-top: 0;',
					'{{WRAPPER}}.shadowcore-cards-carousel-heading-swap--yes .shadowcore-carousel-card__heading' => 'margin-top: {{SIZE}}{{UNIT}}; margin-bottom: 0;',
				],
			]
		);
		$this->add_control(
			'divider-style-heading01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typo',
				'label' => esc_html__( 'Heading Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-carousel-card__heading'
			]
		);
		$this->add_control(
			'heading_color',
			[
				'label' => esc_html__( 'Heading Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-carousel-card__heading' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-carousel-card__heading a' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_control(
			'divider-style-heading02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typo',
				'label' => esc_html__( 'Caption Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-carousel-card__caption'
			]
		);
		$this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Caption Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-carousel-card__caption' => 'color: {{VALUE}};',
				]
			]
		);
		$this->end_controls_section();
	}
	
	protected function render() {
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$settings = $this->get_settings();
		
		$items_spacing_t = ( array_key_exists('items_spacing_tablet', $defs) ? $defs[ 'items_spacing_tablet' ] : [ 
			'unit' => 'px',
            'size' => 20,
		]);
		$items_spacing_m = ( array_key_exists('items_spacing_mobile', $defs) ? $defs[ 'items_spacing_mobile' ] : [ 
			'unit' => 'px',
            'size' => 20,
		]);

		$columns_t = ( array_key_exists('columns_tablet', $defs) ? $defs[ 'columns_tablet' ] : [ 
			'unit' => 'px',
            'size' => 3,
		]);
		$columns_m = ( array_key_exists('columns_mobile', $defs) ? $defs[ 'columns_mobile' ] : [ 
			'unit' => 'px',
            'size' => 1.5,
		]);

		if ( array_key_exists( 'items_spacing_tablet', $settings ) ) {
			$items_spacing_t = $settings[ 'items_spacing_tablet' ];
		}
		if ( array_key_exists( 'items_spacing_mobile', $settings ) ) {
			$items_spacing_m = $settings[ 'items_spacing_mobile' ];
		}
		if ( array_key_exists( 'columns_tablet', $settings ) ) {
			$columns_t = $settings[ 'columns_tablet' ];
		}
		if ( array_key_exists( 'columns_mobile', $settings ) ) {
			$columns_m = $settings[ 'columns_mobile' ];
		}
		
		?>
		<div class="shadowcore-cards-carousel-wrap">
			<div 
				class="shadowcore-owl-container owl-carousel owl-theme" 
				id="<?php echo esc_attr( $this->get_id() ); ?>" 

				data-gutter-d="<?php echo esc_attr( $settings[ 'items_spacing' ][ 'size' ] ); ?>" 
				data-gutter-t="<?php echo esc_attr( $items_spacing_t[ 'size' ] ); ?>" 
				data-gutter-m="<?php echo esc_attr( $items_spacing_m[ 'size' ] ); ?>" 

				data-columns-d="<?php echo esc_attr( $settings['columns']['size'] ) ?>" 
				data-columns-t="<?php echo esc_attr( $columns_t['size'] ) ?>" 
				data-columns-m="<?php echo esc_attr( $columns_m['size'] ) ?>" 

				data-center="<?php echo esc_attr( 'yes' == $settings[ 'items_center' ] ? '1' : '0'  ); ?> " 
				data-loop="<?php echo esc_attr( 'yes' == $settings[ 'loop' ] ? '1' : '0'  ); ?> " 
				data-autoheight="<?php echo esc_attr( 'yes' == $settings[ 'auto_height' ] ? '1' : '0'  ); ?> " 
				data-autoplay="<?php echo esc_attr( 'yes' == $settings[ 'autoplay' ] ? '1' : '0'  ); ?> " 
				data-pause="<?php echo esc_attr( 'yes' == $settings[ 'pause' ] ? '1' : '0'  ); ?> " 
				data-delay="<?php echo esc_attr( $settings[ 'play_speed' ] ); ?>">
				<?php
				foreach (  $settings[ 'card_item' ] as $item ) {
					$image = $item[ 'image' ];
					if ( ! empty ( $image[ 'id' ] ) ) {
						$image_url = wp_get_attachment_image_url( $image[ 'id' ], 'large' );
						if ( 'yes' == $settings[ 'crop_custom' ] ) {
							$thmb_image_width = $settings[ 'image_width' ];
							$thmb_image_height = $settings[ 'image_height' ];
						} else {
							$meta = wp_get_attachment_metadata( $image[ 'id' ] );
							$thmb_image_width = $meta[ 'width' ];
							$thmb_image_height = $meta[ 'height' ];
						}
					} else {
						$image_url = $image[ 'url' ];
						$thmb_image_width = $thmb_image_height = 600;
					}
					$link = $item[ 'link_url' ];
					if ( ! empty( $link[ 'url' ] ) ) {
						$link_start = '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . '>';
						$link_end = '</a>';
					} else {
						$link_start = '';
						$link_end = '';
					}
					?>
					<div class="shadowcore-carousel-card">
						<div class="shadowcore-carousel-card__image-wrap">
							<div class="shadowcore-carousel-card__image shadowcore-div-image" data-src="<?php echo esc_url( $image_url ); ?>">
								<?php echo $link_start; ?>
								<img 
								src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_image_width ); ?>%20<?php echo absint( $thmb_image_height ); ?>'%3E%3C/svg%3E"
								alt="<?php echo esc_attr( get_post_meta( $image[ 'id' ], '_wp_attachment_image_alt', true ) ); ?>">
								<?php echo $link_end; ?>
							</div><!-- .shadowcore-carousel-card__image -->
						</div><!-- .shadowcore-carousel-card__image-wrap -->
						<div class="shadowcore-carousel-card__content">
							<div class="shadowcore-carousel-card__heading">
								<?php 
									echo $link_start;
									echo esc_html( $item[ 'heading' ] ); 
									echo $link_end;
								?>
							</div>
							<div class="shadowcore-carousel-card__caption">
								<?php echo esc_html( $item[ 'caption' ] ); ?>
							</div>
						</div><!-- .shadowcore-carousel-card__content -->
					</div><!-- .shadowcore-carousel-card -->
					<?php		
				}
				?>
			</div><!-- .shadowcore-owl-container  -->
		</div><!-- .shadowcore-cards-carousel-wrap -->
		<?php
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Cards_Carousel_Widget() );