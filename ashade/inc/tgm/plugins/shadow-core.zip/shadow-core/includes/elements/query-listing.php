<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Query_Listing_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-query-listing';
	}
	
	public function get_title() {
		return esc_html__( 'Posts Listing', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-post-list';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
	
	protected function register_controls() {	
		# Defaults
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$post_types_list = array();
		if ( array_key_exists('post_types', $defs ) ) {
			foreach ( $defs['post_types'] as $s => $n ) {
				if ( post_type_exists($s) ) {
					$post_types_list[$s] = $n;
				}
			}
		} else {
			foreach ( get_post_types(false, 'objects') as $slug => $obj ) {
				$this_post = get_object_vars($obj);
				if ( ! $this_post[ 'exclude_from_search' ] && $this_post[ 'name' ] !== 'attachment' ) {
					$post_types_list[ $this_post[ 'name' ] ] = $this_post[ 'label' ];
				}
			}
		}		
		$post_types_list['custom'] = esc_html__( 'Custom Items', 'shadowcore' );

		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Query Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);
		$this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Select Post Type', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_type', $defs) ? $defs[ 'post_type' ] : 'post' ),
				'options' => $post_types_list
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Select Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Title', 'shadowcore' )
			]
		);
		$repeater->add_control(
			'caption',
			[
				'label' => esc_html__( 'Meta (Caption)', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Caption', 'shadowcore' )
			]
		);
		$repeater->add_control(
            'excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
            ]
		);
		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'false',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);
		
		$this->add_control(
			'custom_items',
			[
				'label' => esc_html__( 'Custom Items', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default' => [
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 01', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 02', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 03', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
				],
				'condition' => [
					'post_type' => 'custom'
				]
			]
		);

		# Advanced Query
		$tax_filter_opts = array();
		$tax_filter_cond = array();
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				$tax_filter_opts[$type] = array();
				array_push($tax_filter_cond, $type);
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
							'list' => array()
						);
						$tax_filter_opts[$type][$n] = $props[ 'label' ];
						foreach ( $terms as $term ) {
							$term_arr['list'][$term->slug] = $term->name;
						}
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}
				if ( count( $tax_arr ) > 0 ) {
					$this->add_control(
						$type . '-tax-filter',
						[
							'label' => esc_html__( 'Taxonomies Arguments', 'shadowcore' ),
							'type' => Controls_Manager::POPOVER_TOGGLE,
							'condition' => [
								'post_type' => $type
							]
						]
					);
					$this->start_popover();
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							$type . '-' . $term_arr['slug'] . '-tax',
							[
								'label' => $term_arr['label'],
								'type' => Controls_Manager::SELECT2,
								'options' => $term_arr['list'],
								'multiple' => true,
							]
						);
					}
					$this->end_popover();
				}
			}
		}
		$this->add_control(
			'divider-order',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Sort Posts By', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('orderby', $defs) ? $defs[ 'orderby' ] : 'date' ),
				'options' => [
					'title' => esc_html__( 'Title', 'shadowcore' ),
					'date' => esc_html__( 'Date', 'shadowcore' ),
					'name' => esc_html__( 'Name (slug)', 'shadowcore' ),
					'rand' => esc_html__( 'Random', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Posts Order', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('order', $defs) ? $defs[ 'order' ] : 'DESC' ),
				'options' => [
					'DESC' => esc_html__( 'Descending', 'shadowcore' ),
					'ASC' => esc_html__( 'Ascending', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-post-type',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'listing_type',
			[
				'label' => esc_html__( 'Image Layout Style', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('listing_type', $defs) ? $defs[ 'listing_type' ] : 'medium' ),
				'options' => [
					'small' => esc_html__( 'Small', 'shadowcore' ),
					'medium' => esc_html__( 'Medium', 'shadowcore' ),
					'large' => esc_html__( 'Large', 'shadowcore' ),
				],
			]
		);
		$this->add_control(
			'divider-layout-type',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 240,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'default' => ( array_key_exists('items_spacing_desktop', $defs) ? $defs[ 'items_spacing_desktop' ] : [ 
					'unit' => 'px',
                    'size' => 80,
				]),
				'tablet_default' => ( array_key_exists('items_spacing_tablet', $defs) ? $defs[ 'items_spacing_tablet' ] : [ 
					'unit' => 'px',
                    'size' => 60,
				]),
				'mobile_default' => ( array_key_exists('items_spacing_mobile', $defs) ? $defs[ 'items_spacing_mobile' ] : [ 
					'unit' => 'px',
                    'size' => 60,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-list--item:not(:last-child)' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'divider-lazy',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Images Lazy Loading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lazy', $defs) ? $defs[ 'lazy' ] : 'yes' ),
			]
		);
		$this->add_control(
			'divider-loading',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'loading',
			[
				'label' => esc_html__( 'Posts Loading/Pagination', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('loading', $defs) ? $defs[ 'loading' ] : 'pagination' ),
				'options' => [
					'none' => esc_html__( 'None (Show all posts)', 'shadowcore' ),
					'button' => esc_html__( '"Load More" button', 'shadowcore' ),
					'scroll' => esc_html__( 'Load on Scroll', 'shadowcore' ),
					'pagination' => esc_html__( 'Pagination', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__( 'Posts per Page', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('posts_per_page', $defs) ? $defs[ 'posts_per_page' ] : get_option( 'posts_per_page' ) ),
                'min' => '1',
                'step' => '1',
				'condition' => [
					'loading!' => 'none',
					'post_type!' => 'custom'
				]
            ]
		);
		$this->add_control(
            'posts_per_load',
            [
                'label' => esc_html__( 'Posts Load per Time', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('posts_per_load', $defs) ? $defs[ 'posts_per_load' ] : get_option( 'posts_per_page' ) ),
                'min' => '1',
                'step' => '1',
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
            ]
		);
		$this->add_control(
			'load_more_label',
			[
				'label' => esc_html__( 'Button Label', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('load_more_label', $defs) ? $defs[ 'load_more_label' ] : 'Load More' ),
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
			]
		);
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Image
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_br_small',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-listing--small .shadowcore-pli-image > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br_small', $defs) ? $defs[ 'image_br_small' ] : [ 
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'isLinked' => true,
					'unit' => '%'
				]),
				'condition' => [
					'listing_type' => 'small',
				]
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-image > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
				'condition' => [
					'listing_type!' => 'small',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Image Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pli-image > div',
			]
		);
		$this->add_control(
			'divider-style-tamplate01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'image_size',
			[
				'label' => esc_html__( 'Image Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 50,
						'max' => 200
					],
				],
				'default' => ( array_key_exists('image_size', $defs) ? $defs[ 'image_size' ] : [ 
					'unit' => 'px',
					'size' => 150,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-listing--small .shadowcore-pli-image' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-posts-listing--small .shadowcore-pli-image > div' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'listing_type' => 'small',
				]
			]
		);
		$this->add_responsive_control(
			'port_image_size',
			[
				'label' => esc_html__( 'Portrait Image Width, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 25,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('port_image_size', $defs) ? $defs[ 'port_image_size' ] : [ 
					'unit' => '%',
					'size' => 50,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-listing--medium .shadowcore-pli-image.shadowcore-pli-image--port > div' => 'max-width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-posts-listing--large .shadowcore-pli-image.shadowcore-pli-image--port > div' => 'max-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'listing_type' => ['medium', 'large'],
				]
			]
		);
		$this->add_responsive_control(
			'image_spacing',
			[
				'label' => esc_html__( 'Image Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120
					],
				],
				'default' => ( array_key_exists('image_spacing', $defs) ? $defs[ 'image_spacing' ] : [ 
					'unit' => 'px',
					'size' => 40,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-listing--large .shadowcore-pli-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'.shadowcore-posts-listing--medium .shadowcore-posts-list--item.has-post-thumbnail .shadowcore-pli--inner > div' => 'width: calc(50% - 0.5 * {{SIZE}}{{UNIT}});',
					'(mobile) {{WRAPPER}} .shadowcore-posts-listing--medium .shadowcore-posts-list--item.has-post-thumbnail .shadowcore-pli--inner > div' => 'width: calc(100% - 0 * {{SIZE}}{{UNIT}});',
					'(mobile) {{WRAPPER}} .shadowcore-posts-listing--medium .shadowcore-posts-list--item.has-post-thumbnail .shadowcore-pli--inner > div.shadowcore-pli-image' => 'margin-bottom: {{SIZE}}{{UNIT}};'
				],
				'condition' => [
					'listing_type!' => 'small',
				]
			]
		);
		$this->add_responsive_control(
			'image_spacing_small',
			[
				'label' => esc_html__( 'Image Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120
					],
				],
				'default' => ( array_key_exists('image_spacing', $defs) ? $defs[ 'image_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-listing--small .shadowcore-pli-image' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'listing_type' => 'small',
				]
			]
		);
		$this->add_control(
			'image_position',
			[
				'label' => esc_html__( 'Image Position', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('image_position', $defs) ? $defs[ 'image_position' ] : 'left' ),
				'options' => [
					'left' => esc_html__( 'On Left', 'shadowcore' ),
					'right' => esc_html__( 'On Right', 'shadowcore' ),
					'alt_l' => esc_html__( 'Alternating (left)', 'shadowcore' ),
					'alt_r' => esc_html__( 'Alternating (right)', 'shadowcore' ),
				],
				'condition' => [
					'listing_type' => 'medium',
				],
				'prefix_class' => 'shadowcore-upl-content--',
			]
		);
		$this->add_control(
			'divider-style-img-companion',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'listing_type' => ['medium', 'large']
				],
			]
		);
		$this->add_control(
			'port_image_holder',
			[
				'label' => esc_html__( 'Portrait Images Placeholder', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('port_image_holder', $defs) ? $defs[ 'port_image_holder' ] : 'yes' ),
				'condition' => [
					'listing_type' => ['medium', 'large']
				],
				'prefix_class' => 'shadowcore-pli-image-add--',
			]
		);
		$this->add_control(
			'port_holder_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--medium .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'background: {{VALUE}};',
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--large .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'background: {{VALUE}};'
				],
				'condition' => [
					'listing_type' => ['medium', 'large'],
					'port_image_holder' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'port_holder_spacing',
			[
				'label' => esc_html__( 'Placeholder Vertical Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200
					],
					'%' => [
						'min' => 0,
						'max' => 99
					],
				],
				'default' => ( array_key_exists('port_holder_spacing', $defs) ? $defs[ 'port_holder_spacing' ] : [ 
					'unit' => 'px',
					'size' => 120,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--medium .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'height: calc(100% - {{SIZE}}{{UNIT}}); top: calc( 0.5 * {{SIZE}}{{UNIT}});',
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--large .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'height: calc(100% - {{SIZE}}{{UNIT}}); top: calc( 0.5 * {{SIZE}}{{UNIT}});'
				],
				'condition' => [
					'listing_type' => ['medium', 'large'],
					'port_image_holder' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'port_holder_br',
			[
				'label' => esc_html__( 'Placeholder Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--medium .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--large .shadowcore-pli-image.shadowcore-pli-image--port:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('port_holder_br', $defs) ? $defs[ 'port_holder_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
				'condition' => [
					'listing_type' => ['medium', 'large'],
					'port_image_holder' => 'yes'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'port_holder_shadow',
				'label' => esc_html__( 'Placeholder Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--medium .shadowcore-pli-image.shadowcore-pli-image--port:before',
				'selector' => '{{WRAPPER}}.shadowcore-pli-image-add--yes .shadowcore-posts-listing--large .shadowcore-pli-image.shadowcore-pli-image--port:before',
				'condition' => [
					'listing_type' => ['medium', 'large'],
					'port_image_holder' => 'yes'
				],
			]
		);

		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'post_title',
			[
				'label' => esc_html__( 'Show Post Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_title', $defs) ? $defs[ 'post_title' ] : 'yes' ),
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-style-content0',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_title' => 'yes',
				]
			]
		);
		$this->add_control(
			'align',
			[
				'label' => esc_html__( 'Title and Meta Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('align', $defs) ? $defs[ 'align' ] : 'left' ),
				'prefix_class' => 'shadowcore-upl-align--',
				'toggle' => false,
				'condition' => [
					'post_title' => 'yes',
				]
			
			]
		);
		$this->add_control(
			'head_swap',
			[
				'label' => esc_html__( 'Meta Before Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('head_swap', $defs) ? $defs[ 'head_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-upl-swap--',
				'condition' => [
					'post_title' => 'yes',
					'post_meta' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-content01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_title' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => esc_html__( 'Title Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('title_spacing', $defs) ? $defs[ 'title_spacing' ] : [ 
					'unit' => 'px',
					'size' => 1,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-title h4' => 'padding-bottom: {{SIZE}}{{UNIT}}; padding-top: 0;',
					'{{WRAPPER}}.shadowcore-upl-swap--yes .shadowcore-pli-title h4' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: 0;',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-title h4' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-pli-title h4 a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Title Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pli-title h4 a',
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_meta',
			[
				'label' => esc_html__( 'Meta', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'post_meta',
			[
				'label' => esc_html__( 'Post Meta', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta', $defs) ? $defs[ 'post_meta' ] : 'yes' ),
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__date',
			[
				'label' => esc_html__( 'Meta: Post Date', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'top' => esc_html__( 'In Top Area', 'shadowcore' ),
					'bottom' => esc_html__( 'In Bottom Area', 'shadowcore' ),
				],
				'default' => ( array_key_exists('post_meta__date', $defs) ? $defs[ 'post_meta__date' ] : 'none' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__author',
			[
				'label' => esc_html__( 'Meta: Post Author', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'top' => esc_html__( 'In Top Area', 'shadowcore' ),
					'bottom' => esc_html__( 'In Bottom Area', 'shadowcore' ),
				],
				'default' => ( array_key_exists('post_meta__author', $defs) ? $defs[ 'post_meta__author' ] : 'none' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		
		# Custom Taxonomies (Default Template)
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
						);
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							'post_meta__' . $term_arr['slug'],
							[
								'label' => esc_html__( 'Meta:', 'shadowcore' ) . ' ' . $term_arr['label'],
								'type' => Controls_Manager::SELECT,
								'options' => [
									'none' => esc_html__( 'None', 'shadowcore' ),
									'top' => esc_html__( 'In Top Area', 'shadowcore' ),
									'bottom' => esc_html__( 'In Bottom Area', 'shadowcore' ),
								],
								'default' => ( array_key_exists('post_meta__' . $term_arr['slug'], $defs) ? $defs[ 'post_meta__' . $term_arr['slug'] ] : 'none' ),
								'condition' => [
									'post_meta' => 'yes',
									'post_type' => $type
								]
							]
						);
					}
				}
			}
		}
		
		$this->add_control(
			'post_meta__comments',
			[
				'label' => esc_html__( 'Comments Count', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'top' => esc_html__( 'In Top Area', 'shadowcore' ),
					'bottom' => esc_html__( 'In Bottom Area', 'shadowcore' ),
				],
				'default' => ( array_key_exists('post_meta__comments', $defs) ? $defs[ 'post_meta__comments' ] : 'top' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_meta' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'meta_item_spacing',
			[
				'label' => esc_html__( 'Meta Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('meta_item_spacing', $defs) ? $defs[ 'meta_item_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-meta > div:not(:first-child):before' => 'margin: 0 calc(0.5 * {{SIZE}}{{UNIT}});',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-pli-meta a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-pli-meta > div:not(:first-child):before' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typo',
				'label' => esc_html__( 'Meta Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pli-meta',
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_excerpt',
			[
				'label' => esc_html__( 'Excerpt', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'post_excerpt',
			[
				'label' => esc_html__( 'Show Post Excerpt', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_excerpt', $defs) ? $defs[ 'post_excerpt' ] : 'yes' ),
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'excerpt_spacing',
			[
				'label' => esc_html__( 'Excerpt Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('excerpt_spacing', $defs) ? $defs[ 'excerpt_spacing' ] : [ 
					'unit' => 'px',
					'size' => 22,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-excerpt' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_control(
			'excerpt_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-excerpt' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typo',
				'label' => esc_html__( 'Excerpt Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pli-excerpt',
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_footer',
			[
				'label' => esc_html__( 'Footer', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'footer_spacing',
			[
				'label' => esc_html__( 'Footer Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('footer_spacing', $defs) ? $defs[ 'footer_spacing' ] : [ 
					'unit' => 'px',
					'size' => 23,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-footer' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'footer_swap',
			[
				'label' => esc_html__( 'Swap Elements', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('footer_swap', $defs) ? $defs[ 'footer_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-upl-footer-swap--',
			]
		);
		$this->add_control(
			'divider-style-footer0',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_control(
			'read_more_label',
			[
				'label' => esc_html__( '"Read More" Label', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Continue Reading', 'shadowcore' )
			]
		);
		$this->add_control(
			'read_more_color',
			[
				'label' => esc_html__( '"Read More" Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => ( array_key_exists('read_more_color', $defs) ? $defs[ 'read_more_color' ] : null ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli-footer .shadowcore-pli--more' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'read_more_hcolor',
			[
				'label' => esc_html__( '"Read More" Hover Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'default' => ( array_key_exists('read_more_hcolor', $defs) ? $defs[ 'read_more_hcolor' ] : null ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-pli-footer .shadowcore-pli--more:hover' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'read_more_typo',
				'label' => esc_html__( 'Read More Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pli-footer .shadowcore-pli--more',
			]
		);
		$this->end_controls_section();

		# Section: Button Style
		$this->start_controls_section(
			'section_style_button',
			[
				'label' => esc_html__( 'Button', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'button_style',
			[
				'label' => esc_html__( 'Button Style', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'theme',
				'options' => [
					'theme' => esc_html__( 'Use Theme Style', 'shadowcore' ),
					'custom' => esc_html__( 'Customize', 'shadowcore' ),
				],	
			]
		);
		$this->add_control(
			'button_align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('button_align', $defs) ? $defs[ 'button_align' ] : 'center' ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli--button-wrap' => 'justify-content: {{VALUE}};',
				],
				'toggle' => false,
			
			]
		);
		$this->add_responsive_control(
			'button_spacing',
			[
				'label' => esc_html__( 'Button Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('button_spacing', $defs) ? $defs[ 'button_spacing' ] : [ 
					'unit' => 'px',
					'size' => 40,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pli--button-wrap' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'divider-style-button00',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-custom-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('button_padding', $defs) ? $defs[ 'button_padding' ] : [ 
					'top' => '18',
					'right' => '32',
					'bottom' => '18',
					'left' => '32',
					'isLinked' => false,
					'unit' => 'px'
				]),
				'condition' => [
					'button_style' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'button_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-custom-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('button_br', $defs) ? $defs[ 'button_br' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
				] ),
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_control(
			'divider-style-button01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-custom-button',
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_control(
			'divider-style-button02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom'
				]
			]
		);
		$this->start_controls_tabs(
			'button_style_tabs'
		);
			$this->start_controls_tab(
				'button_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' ),
					'condition' => [
						'button_style' => 'custom',
					]
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_normal_border',
						'label' => esc_html__( 'Border', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-custom-button',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_normal_shadow',
						'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-custom-button',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'divider-style-button03',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'button_normal_bg',
					[
						'label' => esc_html__( 'Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_normal_bg', $defs) ? $defs[ 'button_normal_bg' ] : '#0F47BF' ),
						'selectors' => [
							'{{WRAPPER}} .shadowcore-custom-button' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_normal_color',
					[
						'label' => esc_html__( 'Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_normal_color', $defs) ? $defs[ 'button_normal_color' ] : '#FFFFFF' ),
						'selectors' => [
							'{{WRAPPER}} .shadowcore-custom-button' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'button_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' ),
					'condition' => [
						'button_style' => 'custom',
					]
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_hover_border',
						'label' => esc_html__( 'Hover: Border', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_hover_shadow',
						'label' => esc_html__( 'Hover: Box Shadow', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'divider-style-button04',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'button_hover_bg',
					[
						'label' => esc_html__( 'Hover: Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_hover_color', $defs) ? $defs[ 'button_hover_color' ] : '#2152BC' ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_hover_color',
					[
						'label' => esc_html__( 'Hover: Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_hover_color', $defs) ? $defs[ 'button_hover_color' ] : '#FFFFFF' ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		# Section: Breadcrumbs
		$this->start_controls_section(
			'section_style_pagination',
			[
				'label' => esc_html__( 'Pagination', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'loading' => 'pagination',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'pagination_spacing',
			[
				'label' => esc_html__( 'Pagination Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('pagination_spacing', $defs) ? $defs[ 'pagination_spacing' ] : [ 
					'unit' => 'px',
					'size' => 80,
					] ),
				'selectors' => [
					'{{WRAPPER}} nav.navigation' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_type = $settings[ 'post_type' ];
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$listing_type = $settings[ 'listing_type' ];
		$settings['image_width'] = 1200;
		$settings['image_height'] = 800;
		$thmb_size = 300;
		//$grid_type = $settings[ 'gallery_type' ];

		if ( 'custom' !== $post_type ) {
			# Paged
			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} else if ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			} else {
				$paged = 1;
			}
			if ( 'none' !== $settings[ 'loading' ] ) {
				$ppp = absint( $settings[ 'posts_per_page' ] );
			} else {
				$ppp = -1;
			}
			
			# Query Args
			$args = array(
				'post_type' 	 => $post_type,
				'post_status' 	 => 'publish',
				'paged' 		 => absint( $paged ),
				'posts_per_page' => $ppp,
				'orderby' 		 => esc_attr( $settings[ 'orderby' ] ),
				'order' 		 => esc_attr( $settings[ 'order' ] ),
			);
			
			# Taxonomies
			$hasTax = get_object_taxonomies( $post_type );
			if ( array_key_exists( $post_type . '-tax-filter', $settings ) ) {
				if ( count( $hasTax ) > 0 && 'yes' == $settings[ $post_type . '-tax-filter' ] ) {
					$taxonomies = get_object_taxonomies( $post_type, 'objects' );
					if ( count( $taxonomies ) > 0 ) {
						$tax_query = array();
						foreach ( $taxonomies as $n => $o) {
							$terms = get_terms( $n );
							if ( count( $terms ) > 0 ) {
								$selected_terms = $settings[ $post_type . '-' . $n . '-tax' ];
								if ( is_array( $selected_terms ) && count( $selected_terms ) > 0 ) {
									$this_term = array(
										'taxonomy' => $n,
										'field'    => 'slug',
										'terms'    => $selected_terms
									);
									array_push( $tax_query, $this_term );
								}
							}
						}
						if ( count( $tax_query ) > 0 ) {
							$args['tax_query'] = $tax_query;
						}
					}
				}
			}

			$display_tax_arr = Array();
			if ( count( $hasTax ) > 0 ) {
				$taxonomies = get_object_taxonomies( $post_type, 'objects' );
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						array_push( $display_tax_arr, $n );
					}
				}
			}
		} else {
			$options = false;
		}
		?>
		<div class="shadowcore-posts-listing-wrap" data-loading="<?php echo esc_attr( $settings[ 'loading' ] ); ?>">
			<?php
			if ( 'custom' !== $post_type ) {
				$options = Array(
					'type' => $listing_type,
					'i_size' => $settings['image_width'],
					'lazy' => $settings[ 'lazy' ],
					'title' => ( $settings[ 'post_title' ] == 'yes' ? true : false),
					'meta' => ( $settings[ 'post_meta' ] == 'yes' ? true : false),
					'meta_values' => array(
						'date' => $settings[ 'post_meta__date' ],
						'author' => $settings[ 'post_meta__author' ],
						'comments' => $settings[ 'post_meta__comments' ],
					),
					'excerpt' => ( $settings[ 'post_excerpt' ] == 'yes' ? true : false),
					'read_more_label' => $settings[ 'read_more_label' ]
				);
				if ( count( $display_tax_arr ) > 0 ) {
					foreach ( $display_tax_arr as $n ) {
						$options[ 'meta_custom_values' ][ $n ] = $settings[ 'post_meta__' . $n ];
					}
				}
			}
			?>
			<div class="shadowcore-posts-listing shadowcore-posts-listing--<?php echo esc_attr( $listing_type ); ?>">
			<?php
			if ( 'custom' !== $post_type ) {
				# Query Grid
				$query = new WP_Query( $args );
				$posts_count = $query->found_posts;
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
						$post_class = 'shadowcore-posts-list--item';
						if ( has_post_thumbnail() ) {
							$post_class .= ' has-post-thumbnail';
						} else {
							$post_class .= ' no-post-thumbnail';
						}
						?>
						<div id="shadowcore-uqli-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( $post_class ); ?>>
							<div class="shadowcore-pli--inner">
							<?php 
								if ( has_post_thumbnail() && 'small' !== $listing_type ) {
									# Get Featured Image
									$thmb_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
									$thmb_width = $thmb_meta[ 'width' ];
									$thmb_height = $thmb_meta[ 'height' ];
									$orient = ( $thmb_width > $thmb_height ? 'land' : 'port' );
									if ( 'port' == $orient ) {
										if ( array_key_exists( 'shadowcore-hhd', $thmb_meta[ 'sizes' ] ) ) {
											$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-hhd' );
											$thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-hhd' ][ 'width' ];
											$thmb_height = $thmb_meta[ 'sizes'] [ 'shadowcore-hhd' ][ 'height' ];
										} else {
											if ( 'medium' == $listing_type ) {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
											} else {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
											}
										}
									} else {
										if ( 'medium' == $listing_type ) {
											if ( array_key_exists( 'large', $thmb_meta[ 'sizes' ] ) ) {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
												$thmb_width  = $thmb_meta[ 'sizes' ][ 'large' ][ 'width' ];
												$thmb_height = $thmb_meta[ 'sizes' ][ 'large' ][ 'height' ];
											} else {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
											}
										} else {
											if ( array_key_exists( 'shadowcore-fhd', $thmb_meta['sizes'] ) ) {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-fhd' );
												$thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'width' ];
												$thmb_height = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'height' ];
											} else {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
											}
										}
									}
									?>
									<div class="shadowcore-pli-image shadowcore-pli-image--<?php echo esc_attr( $orient ); ?> <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
										<div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
											<a href="<?php echo esc_url( get_permalink() ); ?>">
												<img
													src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
													width=<?php echo absint( $thmb_width ); ?> 
													height=<?php echo absint( $thmb_height ); ?> 
													alt="<?php the_title(); ?>">
											</a>
										</div><!-- .shadowcore-div-image -->
									</div><!-- .shadowcore-pli-image -->
									<?php
								}
								# Content Part
								?>
								<div class="shadowcore-pli-content">
									<div class="shadowcore-pli-head">
										<?php
										if ( is_sticky() ) {
							            	echo '<i class="dashicons dashicons-admin-post shadowcore-sticky-marker"></i>';
							            }
										if ( has_post_thumbnail() && 'small' == $listing_type ) {
											# Get Featured Image Thumbnail
											$thmb_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
											if ( array_key_exists( 'shadowcore-retina-thumb', $thmb_meta['sizes'] ) ) {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-retina-thumb' );
											} else {
												$thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'thumbnail' );
											}
											$thmb_width = $thmb_height = $thmb_size;
											?>
											<div class="shadowcore-pli-image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
												<div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
													<a href="<?php echo esc_url( get_permalink() ); ?>">
														<img
															src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
															width=<?php echo absint( $thmb_width ); ?> 
															height=<?php echo absint( $thmb_height ); ?> 
															alt="<?php the_title(); ?>">
													</a>
												</div><!-- .shadowcore-div-image -->
											</div><!-- .shadowcore-pli-image -->
											<?php
										}
										?>
										<div class="shadowcore-pli-title">
											<?php if ( $options[ 'title' ] ) { ?>
											<h4><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
											<?php } ?>
											<?php
											if ( $options[ 'meta' ] ) {
												echo '<div class="shadowcore-pli-meta shadowcore-pli-meta--top">';
													if ( 'top' == $options[ 'meta_values' ][ 'date' ] ) {
														echo '<div class="shadowcore-pli__meta--date">'. get_the_date() .'</div>';
													}
													if ( 'top' == $options[ 'meta_values' ][ 'author' ] ) {
														echo '<div class="shadowcore-pli__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
													}
													if ( array_key_exists('meta_custom_values', $options) ) {
														foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
															if ( 'top' == $state ) {
																$term_list = get_the_terms( get_the_id(), $n );
																$term_string = '';
																if ( is_array( $term_list ) ) {
																	foreach ( $term_list as $term ) {
																		$term_string .= $term->name . ", ";
																	}
																	$term_string = substr( $term_string, 0, -2 );
																	echo '<div class="shadowcore-pli__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
																}
															}
														}
													}
													if ( 'top' == $options[ 'meta_values' ][ 'comments' ] ) {
														$comments_count = get_comments_number();
														echo '<div class="shadowcore-pli__meta--comments">'. esc_attr( $comments_count ) .' '. ( $comments_count == '1' ? esc_html__( 'Comment', 'alessa' ) : esc_html__( 'Comments', 'alessa' ) ) .'</div>';
													}
												echo '</div><!-- .shadowcore-pli-meta--top -->';
											}
											?>
										</div><!-- .shadowcore-pli-title -->
									</div><!-- .shadowcore-pli-head -->
									<?php
									if ( $options[ 'excerpt' ] ) {
										$excerpt = get_the_excerpt();
										if ( ! empty( $excerpt ) && $excerpt !== '&nbsp;' ) {
											echo '<div class="shadowcore-pli-excerpt">'. wp_specialchars_decode( $excerpt ) .'</div>';
										}
									}
									?>
									<div class="shadowcore-pli-footer">
										<?php
										if ( $options[ 'meta' ] ) {
											echo '<div class="shadowcore-pli-footer-lp shadowcore-pli-meta shadowcore-pli-meta--bottom">';
												if ( 'bottom' == $options[ 'meta_values' ][ 'date' ] ) {
													echo '<div class="shadowcore-pli__meta--date">'. get_the_date() .'</div>';
												}
												if ( 'bottom' == $options[ 'meta_values' ][ 'author' ] ) {
													echo '<div class="shadowcore-pli__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
												}
												if ( array_key_exists('meta_custom_values', $options) ) {
													foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
														if ( 'bottom' == $state ) {
															if ( 'post_tag' == $n ) {
																echo '<div class="shadowcore-pli__meta--'. esc_attr( $n ) .'">';
																the_tags( esc_html__( 'Tagged in', 'shadowcore' ).': ', ', ', '' );
																echo '</div>';
															} else {
																$term_list = get_the_terms( get_the_id(), $n );
																$term_string = '';
																if ( is_array( $term_list ) ) {
																	foreach ( $term_list as $term ) {
																		$term_string .= $term->name . ", ";
																	}
																	$term_string = substr( $term_string, 0, -2 );
																	echo '<div class="shadowcore-pli__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
																}
															}
														}
													}
												}
												if ( 'bottom' == $options[ 'meta_values' ][ 'comments' ] ) {
													echo '<div class="shadowcore-pli__meta--comments">'. get_comments_number() .' '. esc_html__( 'Comments', 'shadowcore' ) .'</div>';
												}
											echo '</div><!-- .shadowcore-pli-footer-lp -->';
										}
										echo '
											<div class="shadowcore-pli-footer-rp shadowcore-pli-read-more">
												<a class="shadowcore-pli--more" href="'. esc_url( get_permalink() ) .'"><span>'. esc_html( $settings ['read_more_label' ] ) .'</span></a>
											</div>';
										?>
									</div><!-- .shadowcore-pli--footer -->
								</div><!-- .shadowcore-pli-content -->
							</div><!-- .shadowcore-pli--inner -->
						</div><!-- .shadowcore-posts-list--item -->
						<?php
					}
				} else {
					echo '<p>' . esc_html__( 'Oops! Nothing to show here :(', 'shadowcore' ) . '</p>';
				}
			} else {
				# Custom Listing
				if ( count( $settings[ 'custom_items' ] ) ) {
					foreach ( $settings[ 'custom_items' ] as $item ) {
						$image = $item[ 'image' ];
						$has_post_thumnail = false;
						if ( ! empty ( $image[ 'id' ] ) || ! empty( $image[ 'url' ] ) ) {
							$has_post_thumnail = true;
						}
						?>
						<div class="shadowcore-posts-list--item shadowcore-posts-list--item-custom <?php echo esc_attr( $has_post_thumnail ? 'has-post-thumbnail' : 'no-post-thumbnail' ); ?>">
							<div class="shadowcore-pli--inner">
							<?php 
								$thmb_meta = false;
								if ( ! empty ( $image[ 'id' ] ) ) {
									$thmb_meta = wp_get_attachment_metadata( $image[ 'id' ] );
								}
								$link = $item[ 'link_url' ];
								if ( ! empty( $link[ 'url' ] ) ) {
									$link_start_escaped = '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . ' class="shadowcore-pli--more">';
									$link_end_escaped = '</a>';
								} else {
									$link_start_escaped = $link_end_escaped = '';
								}
								if ( 'small' !== $listing_type ) {
									# Get Featured Image
									if ( $thmb_meta && is_array( $thmb_meta ) ) {
										$thmb_width = $thmb_meta[ 'width' ];
										$thmb_height = $thmb_meta[ 'height' ];

										$orient = ( $thmb_width > $thmb_height ? 'land' : 'port' );
										if ( 'port' == $orient ) {
											if ( array_key_exists( 'shadowcore-hhd', $thmb_meta[ 'sizes' ] ) ) {
												$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-hhd' );
												$thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-hhd' ][ 'width' ];
												$thmb_height = $thmb_meta[ 'sizes'] [ 'shadowcore-hhd' ][ 'height' ];
											} else {
												if ( 'medium' == $listing_type ) {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'large' );
												} else {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'full' );
												}
											}
										} else {
											if ( 'medium' == $listing_type ) {
												if ( array_key_exists( 'large', $thmb_meta[ 'sizes' ] ) ) {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'large' );
													$thmb_width  = $thmb_meta[ 'sizes' ][ 'large' ][ 'width' ];
													$thmb_height = $thmb_meta[ 'sizes' ][ 'large' ][ 'height' ];
												} else {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'full' );
												}
											} else {
												if ( array_key_exists( 'shadowcore-fhd', $thmb_meta['sizes'] ) ) {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-fhd' );
													$thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'width' ];
													$thmb_height = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'height' ];
												} else {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'full' );
												}
											}
										}
									} else if ( ! empty( $image[ 'url' ] ) ) {
										$thmb_meta = true;
										$thmb_url = $image[ 'url' ];
										$thmb_width = 1200;
										$thmb_height = 800;
									}

									if ( $thmb_meta ) {
									?>
									<div class="shadowcore-pli-image shadowcore-pli-image--<?php echo esc_attr( $orient ); ?> <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
										<div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
											<?php echo $link_start_escaped; ?>
												<img
													src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
													width=<?php echo absint( $thmb_width ); ?> 
													height=<?php echo absint( $thmb_height ); ?> 
													alt="<?php the_title(); ?>">
											<?php echo $link_end_escaped; ?>
										</div><!-- .shadowcore-div-image -->
									</div><!-- .shadowcore-pli-image -->
									<?php
									}
								}
								# Content Part
								?>
								<div class="shadowcore-pli-content">
									<div class="shadowcore-pli-head">
										<?php
										if ( 'small' == $listing_type ) {
											# Get Featured Image Thumbnail
											if ( $thmb_meta ) {
												if ( array_key_exists( 'shadowcore-retina-thumb', $thmb_meta['sizes'] ) ) {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-retina-thumb' );
												} else {
													$thmb_url = wp_get_attachment_image_url( $image[ 'id' ], 'thumbnail' );
												}
												$thmb_width = $thmb_height = $thmb_size;
											} else if ( ! empty( $image[ 'url' ] ) ) {
												$thmb_meta = true;
												$thmb_url = $image[ 'url' ];
												$thmb_width = $thmb_height = $thmb_size;
											}
											if ( $thmb_meta ) {
											?>
											<div class="shadowcore-pli-image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
												<div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
													<a href="<?php echo esc_url( get_permalink() ); ?>">
														<img
															src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
															width=<?php echo absint( $thmb_width ); ?> 
															height=<?php echo absint( $thmb_height ); ?> 
															alt="<?php the_title(); ?>">
													</a>
												</div><!-- .shadowcore-div-image -->
											</div><!-- .shadowcore-pli-image -->
											<?php
											}
										}
										?>
										<div class="shadowcore-pli-title">
											<?php 
											if ( ! empty( $item[ 'title' ] ) ) {
												echo '<h4 class="shadowcore-pli__title">' . $link_start_escaped . esc_html( $item[ 'title' ] ) . $link_end_escaped . '</h4>';
											}
											?>
											<?php
											if ( ! empty( $item[ 'caption' ] ) ) {
												echo '<div class="shadowcore-pli-meta shadowcore-pli-meta--top">' . esc_html( $item[ 'caption' ] ) . '</div><!-- .shadowcore-pli-meta--top -->';
											}
											?>
										</div><!-- .shadowcore-pli-title -->
									</div><!-- .shadowcore-pli-head -->
									<?php
									if ( !empty( $item[ 'excerpt' ] ) ) {
										echo '<div class="shadowcore-pli-excerpt">' . esc_html( $item[ 'excerpt' ] ) . '</div>';
									}
									if ( ! empty( $link[ 'url' ] ) ) {
									?>
									<div class="shadowcore-pli-footer shadowcore-pli-footer--custom">
										<?php
										echo '
											<div class="shadowcore-pli-footer-rp shadowcore-pli-read-more">
												' . $link_start_escaped . '<span>'. esc_html( $settings ['read_more_label' ] ) .'</span>' . $link_end_escaped . '
											</div>';
										?>
									</div><!-- .shadowcore-pli--footer -->
									<?php } ?>
								</div><!-- .shadowcore-pli-content -->
							</div><!-- .shadowcore-pli--inner -->
						</div><!-- .shadowcore-posts-list--item -->
						<?php
					}
				}
			}
			?>
			</div><!-- .shadowcore-posts-grid -->
			<?php
			if ( 'custom' !== $post_type ) {
				if ( 'button' == $settings[ 'loading' ] ) {
					$prop = array(
						'url' => admin_url( 'admin-ajax.php' ),
						'nonce' => wp_create_nonce('shadowcore_secure'),
						'args' => $args
					);
					if ( is_array( $options ) ) {
						$prop[ 'options' ] = $options;
					}
					$prop['args']['posts_per_page'] = $settings[ 'posts_per_load' ];
					echo '
					<div class="shadowcore-pli--button-wrap">
						<a href="#" 
							data-shown="'. esc_attr( $settings[ 'posts_per_page' ] ) .'" 
							data-count="'. esc_attr( $posts_count ) .'" 
							data-prop="'. htmlspecialchars(json_encode($prop), ENT_QUOTES, 'UTF-8') .'" 
							class="shadowcore-pli--more shadowcore-'. $settings[ 'button_style' ] .'-button '. esc_attr( 'theme' == $settings[ 'button_style' ] ? st_get_theme_prefix().'-button' : null) .'">' . $settings[ 'load_more_label' ] . '</a>
					</div><!-- .shadowcore-pli--button-wrap -->';
				}
				if ( 'scroll' == $settings[ 'loading' ] ) {
					$prop = array(
						'url' => admin_url( 'admin-ajax.php' ),
						'nonce' => wp_create_nonce('shadowcore_secure'),
						'args' => $args
					);
					if ( is_array( $options ) ) {
						$prop[ 'options' ] = $options;
					}
					echo '
					<div class="shadowcore-pli--load" 
						data-shown="'. esc_attr( $settings[ 'posts_per_page' ] ) .'" 
						data-count="'. esc_attr( $posts_count ) .'" 
						data-prop="'. htmlspecialchars(json_encode($prop), ENT_QUOTES, 'UTF-8') .'" ></div><!-- .shadowcore-pli--load -->';
				}
				if ( 'pagination' == $settings[ 'loading' ] ) {
					$global_query = $GLOBALS['wp_query'];
					$GLOBALS['wp_query'] = $query;
					get_template_part( 'template-parts/pagination' );
					$GLOBALS['wp_query'] = $global_query;
				}
			}
			?>
		</div><!-- .shadowcore-posts-grid-wrap -->
		<?php
		if ( 'custom' !== $post_type ) {
			# Reset Query
			wp_reset_query();
		}
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Query_Listing_Widget() );