<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Query_Grid_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-query-grid';
	}
	
	public function get_title() {
		return esc_html__( 'Posts Grid', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-posts-grid';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}
	
	public function get_script_depends() {
		return [ 'shadowcore-brickwall' ];
	}
	
	protected function register_controls() {	
		# Defaults
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$post_types_list = array();
		if ( array_key_exists('post_types', $defs ) ) {
			foreach ( $defs['post_types'] as $s => $n ) {
				if ( post_type_exists($s) ) {
					$post_types_list[$s] = $n;
				}
			}
		} else {
			foreach ( get_post_types(false, 'objects') as $slug => $obj ) {
				$this_post = get_object_vars($obj);
				if ( ! $this_post[ 'exclude_from_search' ] && $this_post[ 'name' ] !== 'attachment' ) {
					$post_types_list[ $this_post[ 'name' ] ] = $this_post[ 'label' ];
				}
			}
		}		
		$post_types_list['custom'] = esc_html__( 'Custom Items', 'shadowcore' );

		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Query Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);
		$this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Select Post Type', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_type', $defs) ? $defs[ 'post_type' ] : 'post' ),
				'options' => $post_types_list
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Select Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Title', 'shadowcore' )
			]
		);
		$repeater->add_control(
			'caption',
			[
				'label' => esc_html__( 'Meta (Caption)', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Caption', 'shadowcore' )
			]
		);
		$repeater->add_control(
            'excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
            ]
		);
		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'false',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);
		
		$this->add_control(
			'custom_items',
			[
				'label' => esc_html__( 'Custom Items', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default' => [
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 01', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 02', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 03', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
				],
				'condition' => [
					'post_type' => 'custom'
				]
			]
		);

		# Advanced Query
		$tax_filter_opts = array();
		$tax_filter_cond = array();
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				$tax_filter_opts[$type] = array();
				array_push($tax_filter_cond, $type);
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
							'list' => array()
						);
						$tax_filter_opts[$type][$n] = $props[ 'label' ];
						foreach ( $terms as $term ) {
							$term_arr['list'][$term->slug] = $term->name;
						}
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}
				if ( count( $tax_arr ) > 0 ) {
					$this->add_control(
						$type . '-tax-filter',
						[
							'label' => esc_html__( 'Taxonomies Arguments', 'shadowcore' ),
							'type' => Controls_Manager::POPOVER_TOGGLE,
							'condition' => [
								'post_type' => $type
							]
						]
					);
					$this->start_popover();
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							$type . '-' . $term_arr['slug'] . '-tax',
							[
								'label' => $term_arr['label'],
								'type' => Controls_Manager::SELECT2,
								'options' => $term_arr['list'],
								'multiple' => true,
							]
						);
					}
					$this->end_popover();
				}
			}
		}
		# Filter
		if ( count($tax_filter_cond) > 0 ) {
			$this->add_control(
				'divider-filter',
				[
					'type' => Controls_Manager::DIVIDER,
					'condition' => [
						'post_type' => $tax_filter_cond
					]
				]
			);
			$this->add_control(
				'tax_filter',
				[
					'label' => esc_html__( 'Taxonomy Filter', 'shadowcore' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => esc_html__( 'Yes', 'shadowcore' ),
					'label_off' => esc_html__( 'No', 'shadowcore' ),
					'return_value' => 'yes',
					'default' => ( array_key_exists('tax_filter', $defs) ? $defs[ 'tax_filter' ] : 'no' ),
					'condition' => [
						'post_type' => $tax_filter_cond
					]
				]
			);
			if ( count($tax_filter_opts) > 0 ) {
				foreach( $tax_filter_opts as $type => $options) {
					$this->add_control(
						$type . '_tax_filter_type',
						[
							'label' => esc_html__( 'Select Taxonomy for Filter', 'shadowcore' ),
							'label_block' => true,
							'type' => Controls_Manager::SELECT,
							'default' => ( array_key_exists($type . '_tax_filter_type', $defs) ? $defs[ $type . '_tax_filter_type' ] : key($options) ),
							'options' => $options,
							'condition' => [
								'post_type' => $type,
								'tax_filter' => 'yes'
							]
						]
					);
				}
			}
		}
		$this->add_control(
			'divider-order',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Sort Posts By', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('orderby', $defs) ? $defs[ 'orderby' ] : 'date' ),
				'options' => [
					'title' => esc_html__( 'Title', 'shadowcore' ),
					'date' => esc_html__( 'Date', 'shadowcore' ),
					'name' => esc_html__( 'Name (slug)', 'shadowcore' ),
					'rand' => esc_html__( 'Random', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Posts Order', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('order', $defs) ? $defs[ 'order' ] : 'DESC' ),
				'options' => [
					'DESC' => esc_html__( 'Descending', 'shadowcore' ),
					'ASC' => esc_html__( 'Ascending', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-post-layout',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'gallery_type',
			[
				'label' => esc_html__( 'Layout Style', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('gallery_type', $defs) ? $defs[ 'gallery_type' ] : 'grid' ),
				'options' => [
					'grid' => esc_html__( 'Grid', 'shadowcore' ),
					'masonry' => esc_html__( 'Masonry', 'shadowcore' ),
					'adjusted' => esc_html__( 'Adjusted', 'shadowcore' ),
				],
			]
		);
		$this->add_control(
			'divider-layout-type',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_responsive_control(
			'columns',
			[
				'label' => esc_html__( 'Columns Count', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 5,
						'step' => 1
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'default' => ( array_key_exists('columns_desktop', $defs) ? $defs[ 'columns_desktop' ] : [ 
					'unit' => 'px',
                    'size' => 3,
				]),
				'tablet_default' => ( array_key_exists('columns_tablet', $defs) ? $defs[ 'columns_tablet' ] : [ 
					'unit' => 'px',
                    'size' => 2,
				]),
				'mobile_default' => ( array_key_exists('columns_mobile', $defs) ? $defs[ 'columns_mobile' ] : [ 
					'unit' => 'px',
                    'size' => 1,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-grid--item' => 'width: calc( 100% / {{SIZE}} );',
				],
			]
		);
		$this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 120,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'default' => ( array_key_exists('items_spacing_desktop', $defs) ? $defs[ 'items_spacing_desktop' ] : [ 
					'unit' => 'px',
                    'size' => 40,
				]),
				'tablet_default' => ( array_key_exists('items_spacing_tablet', $defs) ? $defs[ 'items_spacing_tablet' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				]),
				'mobile_default' => ( array_key_exists('items_spacing_mobile', $defs) ? $defs[ 'items_spacing_mobile' ] : [ 
					'unit' => 'px',
                    'size' => 20,
				]),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-posts-grid' => 'margin: calc( -0.5 * {{SIZE}}{{UNIT}} );',
					'{{WRAPPER}} .shadowcore-posts-grid--item' => 'padding: calc( 0.5 * {{SIZE}}{{UNIT}} );',
				],
			]
		);
		$this->add_control(
			'divider-lazy',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Images Lazy Loading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lazy', $defs) ? $defs[ 'lazy' ] : 'yes' ),
			]
		);

		$this->add_control(
			'divider-loading',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'loading',
			[
				'label' => esc_html__( 'Posts Loading/Pagination', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('loading', $defs) ? $defs[ 'loading' ] : 'none' ),
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'all' => esc_html__( 'Show all posts', 'shadowcore' ),
					'button' => esc_html__( '"Load More" button', 'shadowcore' ),
					'scroll' => esc_html__( 'Load on Scroll', 'shadowcore' ),
					'pagination' => esc_html__( 'Pagination', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
            'posts_per_page',
            [
                'label' => esc_html__( 'Posts to Show', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('posts_per_page', $defs) ? $defs[ 'posts_per_page' ] : '9' ),
                'min' => '1',
                'step' => '1',
				'condition' => [
					'loading!' => 'all',
					'post_type!' => 'custom'
				]
            ]
		);
		$this->add_control(
            'posts_per_load',
            [
                'label' => esc_html__( 'Posts Load per Time', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
                'default' => ( array_key_exists('posts_per_load', $defs) ? $defs[ 'posts_per_load' ] : '6' ),
                'min' => '1',
                'step' => '1',
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
            ]
		);
		$this->add_control(
			'load_more_label',
			[
				'label' => esc_html__( 'Button Label', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => ( array_key_exists('load_more_label', $defs) ? $defs[ 'load_more_label' ] : 'Load More' ),
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
			]
		);
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Template
		$this->start_controls_section(
			'section_style_template',
			[
				'label' => esc_html__( 'Image and Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-grid-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_control(
			'image_width',
			[
				'label' => esc_html__( 'Thumbnail Width', 'shadowcore' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '960',
				'min' => '100',
				'step' => '1',
				'condition' => [
					'gallery_type' => 'grid',
				]
			]
		);
		$this->add_control(
			'image_height',
			[
				'label' => esc_html__( 'Thumbnail Height', 'shadowcore' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '640',
				'min' => '100',
				'step' => '1',
				'condition' => [
					'gallery_type' => 'grid',
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'post_content',
			[
				'label' => esc_html__( 'Content Position', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_content', $defs) ? $defs[ 'post_content' ] : 'below' ),
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'below' => esc_html__( 'Below the Image', 'shadowcore' ),
					'above' => esc_html__( 'Above the Image', 'shadowcore' ),
					'top' => esc_html__( 'At the Image Top', 'shadowcore' ),
					'bottom' => esc_html__( 'At the Image Bottom', 'shadowcore' ),
				],
				'prefix_class' => 'shadowcore-pgi-content--',
			]
		);
		$this->add_control(
			'post_content_hover_o',
			[
				'label' => esc_html__( 'Fade In/Out on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_content_hover_o', $defs) ? $defs[ 'post_content_hover_o' ] : 'yes' ),
				'condition' => [
					'post_content' => ['top', 'bottom'],
				],
				'prefix_class' => 'shadowcore-pgi-content-hoverO--',
			]
		);
		$this->add_control(
			'post_content_hover_t',
			[
				'label' => esc_html__( 'Move In/Out on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_content_hover_t', $defs) ? $defs[ 'post_content_hover_t' ] : 'no' ),
				'condition' => [
					'post_content' => ['top', 'bottom'],
				],
				'prefix_class' => 'shadowcore-pgi-content-hoverT--',
			]
		);
		$this->add_control(
			'divider-style-tamplate02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_title',
			[
				'label' => esc_html__( 'Show Post Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_title', $defs) ? $defs[ 'post_title' ] : 'yes' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta',
			[
				'label' => esc_html__( 'Show Post Meta', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta', $defs) ? $defs[ 'post_meta' ] : 'yes' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__date',
			[
				'label' => esc_html__( 'Show Post Date', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__date', $defs) ? $defs[ 'post_meta__date' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__author',
			[
				'label' => esc_html__( 'Show Post Author', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__author', $defs) ? $defs[ 'post_meta__author' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		
		# Custom Taxonomies (Default Template)
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
						);
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							'post_meta__' . $term_arr['slug'],
							[
								'label' => esc_html__( 'Show', 'shadowcore' ) . ' ' . $term_arr['label'],
								'type' => Controls_Manager::SWITCHER,
								'label_on' => esc_html__( 'Yes', 'shadowcore' ),
								'label_off' => esc_html__( 'No', 'shadowcore' ),
								'return_value' => 'yes',
								'default' => ( array_key_exists('post_meta__' . $term_arr['slug'], $defs) ? $defs[ 'post_meta__' . $term_arr['slug'] ] : 'no' ),
								'condition' => [
									'post_meta' => 'yes',
									'post_content!' => 'none',
									'post_type' => $type
								]
							]
						);
					}
				}
			}
		}
		
		$this->add_control(
			'post_meta__comments',
			[
				'label' => esc_html__( 'Show Post Comments Count', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__comments', $defs) ? $defs[ 'post_meta__comments' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_excerpt',
			[
				'label' => esc_html__( 'Show Post Excerpt', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_excerpt', $defs) ? $defs[ 'post_excerpt' ] : 'no' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content Styles', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_content!' => 'none',
				]
			]
		);
		$this->add_responsive_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__content-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('padding', $defs) ? $defs[ 'padding' ] : [ 
					'top' => '20',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false,
					'unit' => 'px'
					] ),
			]
		);
		$this->add_responsive_control(
			'content_br',
			[
				'label' => esc_html__( 'Content Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__content-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('content_br', $defs) ? $defs[ 'content_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				] ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__content-inner' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('align', $defs) ? $defs[ 'align' ] : 'left' ),
				'prefix_class' => 'shadowcore-pgi-align--',
				'toggle' => false,
			
			]
		);
		$this->add_control(
			'head_swap',
			[
				'label' => esc_html__( 'Meta Before Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('head_swap', $defs) ? $defs[ 'head_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-pgi-swap--',
			]
		);
		$this->add_control(
			'divider-style-content01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => esc_html__( 'Title Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('title_spacing', $defs) ? $defs[ 'title_spacing' ] : [ 
					'unit' => 'px',
					'size' => 10,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__meta' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: 0;',
					'{{WRAPPER}}.shadowcore-pgi-swap--yes .shadowcore-pgi__meta' => 'padding-bottom: {{SIZE}}{{UNIT}}; padding-top: 0;',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__title' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Title Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pgi__title',
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-content02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'meta_item_spacing',
			[
				'label' => esc_html__( 'Meta Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('meta_item_spacing', $defs) ? $defs[ 'meta_item_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__meta > div:before' => 'margin-left: calc(0.5 * {{SIZE}}{{UNIT}}); margin-right: calc(0.5 * {{SIZE}}{{UNIT}});',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-pgi__meta a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typo',
				'label' => esc_html__( 'Meta Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pgi__meta',
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_control(
			'divider-style-content03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'excerpt_spacing',
			[
				'label' => esc_html__( 'Excerpt Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('excerpt_spacing', $defs) ? $defs[ 'excerpt_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__excerpt' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_control(
			'excerpt_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi__excerpt' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typo',
				'label' => esc_html__( 'Excerpt Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pgi__excerpt',
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->end_controls_section();

		# Section: Filter
		$this->start_controls_section(
			'section_style_filter',
			[
				'label' => esc_html__( 'Filter', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'tax_filter' => 'yes'
				]
			]
		);
		$this->add_control(
			'filter_align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('filter_align', $defs) ? $defs[ 'filter_align' ] : 'flex-start' ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-brickwall-filter' => 'justify-content: {{VALUE}}',
				],
				'toggle' => false,
			
			]
		);
		$this->add_responsive_control(
			'filter_spacing',
			[
				'label' => esc_html__( 'Filter Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-brickwall-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('filter_spacing', $defs) ? $defs[ 'filter_spacing' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '28',
					'left' => '0',
					'isLinked' => false,
					'unit' => 'px'
				]),
			]
		);
		$this->add_control(
			'divider-style-filter00',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'filter_items_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('filter_items_spacing', $defs) ? $defs[ 'filter_items_spacing' ] : [ 
					'unit' => 'px',
					'size' => 40,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-brickwall-filter' => 'margin-left: calc(-0.5 * {{SIZE}}{{UNIT}}); margin-right: calc(-0.5 * {{SIZE}}{{UNIT}}); margin-top: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-brickwall-filter a' => 'margin-left: calc(0.5 * {{SIZE}}{{UNIT}}); margin-right: calc(0.5 * {{SIZE}}{{UNIT}}); margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'filter_items_padding',
			[
				'label' => esc_html__( 'Items Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-brickwall-filter a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('filter_items_padding', $defs) ? $defs[ 'filter_items_padding' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false,
					'unit' => 'px'
				]),
			]
		);
		$this->add_control(
			'divider-style-filter01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'filter_item_border',
				'label' => esc_html__( 'Border', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-brickwall-filter a',
			]
		);
		$this->add_responsive_control(
			'filter_item_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-brickwall-filter a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('filter_item_br', $defs) ? $defs[ 'filter_item_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_control(
			'divider-style-filter02',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'filter_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-brickwall-filter a',
			]
		);
		$this->add_control(
			'divider-style-filter03',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->start_controls_tabs(
			'filter_style_tabs'
		);
			$this->start_controls_tab(
				'filter_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' ),
				]
			);
				$this->add_control(
					'filter_normal_color',
					[
						'label' => esc_html__( 'Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-brickwall-filter a' => 'color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'filter_normal_bg',
					[
						'label' => esc_html__( 'Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-brickwall-filter a' => 'background-color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'filter_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' ),
				]
			);
				$this->add_control(
					'filter_hover_color',
					[
						'label' => esc_html__( 'Hover: Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-brickwall-filter a:hover' => 'color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'filter_hover_bg',
					[
						'label' => esc_html__( 'Hover: Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-brickwall-filter a:hover' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'filter_hover_border',
					[
						'label' => esc_html__( 'Hover: Border Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-brickwall-filter a:hover' => 'border-color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'filter_active_tab',
				[
					'label' => esc_html__( 'Active', 'shadowcore' ),
				]
			);
				$this->add_control(
					'filter_active_color',
					[
						'label' => esc_html__( 'Active: Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-brickwall-filter a.is-active' => 'color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'filter_active_bg',
					[
						'label' => esc_html__( 'Active: Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-brickwall-filter a.is-active' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'filter_active_border',
					[
						'label' => esc_html__( 'Active: Border Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .shadowcore-brickwall-filter a.is-active' => 'border-color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		# Section: Hover Effects
		$this->start_controls_section(
			'section_style_hover',
			[
				'label' => esc_html__( 'Hover Effect', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_content!' => 'none',
				]
			]
		);
		$this->add_control(
			'fade_items',
			[
				'label' => esc_html__( 'Fade not Hover Items', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('fade_items', $defs) ? $defs[ 'fade_items' ] : 'yes' ),
				'prefix_class' => 'shadowcore-pgi-fade--',
			]
		);
		$this->add_control(
			'fade_items_opacity',
			[
				'label' => esc_html__( 'Item Opacity', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('fade_items_opacity', $defs) ? $defs[ 'fade_items_opacity' ] : [ 
					'unit' => '%',
					'size' => 50,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-pgi-fade--yes .shadowcore-posts-grid:hover .shadowcore-posts-grid--item:not(:hover)' => 'opacity: calc({{SIZE}} * 0.01);',
				],
				'condition' => [
					'fade_items' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-hover',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'items_scale',
			[
				'label' => esc_html__( 'Item Zoom on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('items_zoom', $defs) ? $defs[ 'items_zoom' ] : 'no' ),
				'prefix_class' => 'shadowcore-pgi-scale--',
			]
		);
		$this->add_control(
			'items_scale_factor',
			[
				'label' => esc_html__( 'Zoom Value, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 150
					],
				],
				'default' => ( array_key_exists('items_scale_factor', $defs) ? $defs[ 'items_scale_factor' ] : [ 
					'unit' => '%',
					'size' => 105,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-pgi-scale--yes .shadowcore-posts-grid--item:hover' => 'z-index: 11!important;',
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-pgi-scale--yes .shadowcore-posts-grid--item:hover .shadowcore-pgi--inner' => 'transform: scale(calc({{SIZE}} * 0.01));',
				],
				'condition' => [
					'items_scale' => 'yes'
				]
			]
		);
		$this->end_controls_section();

		# Section: Button Style
		$this->start_controls_section(
			'section_style_button',
			[
				'label' => esc_html__( 'Button', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'loading' => 'button',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'button_style',
			[
				'label' => esc_html__( 'Button Style', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'theme',
				'options' => [
					'theme' => esc_html__( 'Use Theme Style', 'shadowcore' ),
					'custom' => esc_html__( 'Customize', 'shadowcore' ),
				],	
			]
		);
		$this->add_control(
			'button_align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('button_align', $defs) ? $defs[ 'button_align' ] : 'center' ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi--button-wrap' => 'justify-content: {{VALUE}};',
				],
				'toggle' => false,
			
			]
		);
		$this->add_responsive_control(
			'button_spacing',
			[
				'label' => esc_html__( 'Button Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('button_spacing', $defs) ? $defs[ 'button_spacing' ] : [ 
					'unit' => 'px',
					'size' => 40,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pgi--button-wrap' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'divider-style-button00',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-custom-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('button_padding', $defs) ? $defs[ 'button_padding' ] : [ 
					'top' => '18',
					'right' => '32',
					'bottom' => '18',
					'left' => '32',
					'isLinked' => false,
					'unit' => 'px'
				]),
				'condition' => [
					'button_style' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'button_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-custom-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('button_br', $defs) ? $defs[ 'button_br' ] : [ 
					'top' => '12',
					'right' => '12',
					'bottom' => '12',
					'left' => '12',
					'isLinked' => true,
					'unit' => 'px'
				] ),
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_control(
			'divider-style-button01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typo',
				'label' => esc_html__( 'Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-custom-button',
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->add_control(
			'divider-style-button02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'button_style' => 'custom',
				]
			]
		);
		$this->start_controls_tabs(
			'button_style_tabs'
		);
			$this->start_controls_tab(
				'button_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'shadowcore' ),
					'condition' => [
						'button_style' => 'custom',
					]
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_normal_border',
						'label' => esc_html__( 'Border', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-custom-button',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_normal_shadow',
						'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
						'selector' => '{{WRAPPER}} .shadowcore-custom-button',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'divider-style-button03',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'button_normal_bg',
					[
						'label' => esc_html__( 'Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_normal_bg', $defs) ? $defs[ 'button_normal_bg' ] : '#0F47BF' ),
						'selectors' => [
							'{{WRAPPER}} .shadowcore-custom-button' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_normal_color',
					[
						'label' => esc_html__( 'Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_normal_color', $defs) ? $defs[ 'button_normal_color' ] : '#FFFFFF' ),
						'selectors' => [
							'{{WRAPPER}} .shadowcore-custom-button' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'button_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'shadowcore' ),
					'condition' => [
						'button_style' => 'custom',
					]
				]
			);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'button_hover_border',
						'label' => esc_html__( 'Hover: Border', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'button_hover_shadow',
						'label' => esc_html__( 'Hover: Box Shadow', 'shadowcore' ),
						'selector' => 'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover',
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'divider-style-button04',
					[
						'type' => Controls_Manager::DIVIDER,
						'condition' => [
							'button_style' => 'custom',
						]
					]
				);
				$this->add_control(
					'button_hover_bg',
					[
						'label' => esc_html__( 'Hover: Background Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_hover_color', $defs) ? $defs[ 'button_hover_color' ] : '#2152BC' ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover' => 'background-color: {{VALUE}};'
						]
					]
				);
				$this->add_control(
					'button_hover_color',
					[
						'label' => esc_html__( 'Hover: Text Color', 'shadowcore' ),
						'type' => Controls_Manager::COLOR,
						'condition' => [
							'button_style' => 'custom',
						],
						'default' => ( array_key_exists('button_hover_color', $defs) ? $defs[ 'button_hover_color' ] : '#FFFFFF' ),
						'selectors' => [
							'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-custom-button:hover' => 'color: {{VALUE}};'
						]
					]
				);
			$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();

		# Section: Breadcrumbs
		$this->start_controls_section(
			'section_style_pagination',
			[
				'label' => esc_html__( 'Pagination', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'loading' => 'pagination',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_responsive_control(
			'pagination_spacing',
			[
				'label' => esc_html__( 'Pagination Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('pagination_spacing', $defs) ? $defs[ 'pagination_spacing' ] : [ 
					'unit' => 'px',
					'size' => 40,
					] ),
				'selectors' => [
					'{{WRAPPER}} nav.navigation' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_type = $settings[ 'post_type' ];
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$grid_type = $settings[ 'gallery_type' ];
		$hasTax = 'custom' !== $post_type ? get_object_taxonomies( $post_type ) : [];
		$taxonomies = $hasTax ? get_object_taxonomies( $post_type, 'objects' ) : [];
		
		if ( 'custom' !== $post_type ) {
			# Paged
			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} else if ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			} else {
				$paged = 1;
			}
			if ( 'all' !== $settings[ 'loading' ] ) {
				$ppp = absint( $settings[ 'posts_per_page' ] );
			} else {
				$ppp = -1;
			}
			
			# Query Args
			$args = array(
				'post_type' 	 => $post_type,
				'post_status' 	 => 'publish',
				'paged' 		 => absint( $paged ),
				'posts_per_page' => $ppp,
				'orderby' 		 => esc_attr( $settings[ 'orderby' ] ),
				'order' 		 => esc_attr( $settings[ 'order' ] ),
			);

			# Taxonomies
			if ( array_key_exists($post_type . '-tax-filter', $settings) && 'yes' == $settings[ $post_type . '-tax-filter' ] ) {
				if ( count( $taxonomies ) > 0 ) {
					$tax_query = array();
					foreach ( $taxonomies as $n => $o) {
						$terms = get_terms( $n );
						if ( count( $terms ) > 0 ) {
							$selected_terms = $settings[ $post_type . '-' . $n . '-tax' ];
							if ( is_array( $selected_terms ) && count( $selected_terms ) > 0 ) {
								$this_term = array(
									'taxonomy' => $n,
									'field'    => 'slug',
									'terms'    => $selected_terms
								);
								array_push( $tax_query, $this_term );
							}
						}
					}
					if ( count( $tax_query ) > 0 ) {
						$args['tax_query'] = $tax_query;
					}
				}
			}

			$display_tax_arr = Array();
			if ( count( $hasTax ) > 0 ) {
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						array_push( $display_tax_arr, $n );
					}
				}
			}
		} else {
			$options = false;
		}
		?>
		<div class="shadowcore-posts-grid-wrap" data-loading="<?php echo esc_attr( $settings[ 'loading' ] ); ?>">
			<?php
			if ( 'custom' !== $post_type ) {
				if ( count( $taxonomies ) > 0 ) {
					$tax_filter = $settings[ $post_type . '_tax_filter_type' ];
					if ('yes' == $settings[ 'tax_filter' ] && !empty( $tax_filter ) ) {
						# Taxonimy Filter Options
						$tax_filter_terms = get_terms( $tax_filter );
						$tax_filter_arr = array();
						if ( count( $tax_filter_terms ) > 0 ) {
							foreach( $tax_filter_terms as $term ) {
								$tax_filter_arr[$term->slug] = $term->name;
							}
						}
						# Remove unused filter options
						if ( array_key_exists( 'tax_query', $args ) ) {
							$selected_tax = array();
							foreach( $args['tax_query'] as $tax_args ) {
								if ( $tax_filter == $tax_args['taxonomy'] ) {
									$selected_tax = $tax_args['terms'];
									foreach( $tax_filter_arr as $s => $n ) {
										if ( ! in_array ($s, $selected_tax ) ) {
											unset( $tax_filter_arr[$s] );
										}
									}
								}
							}
						}
						
						# Render Filter
						echo '<div class="shadowcore-posts-grid-filter shadowcore-brickwall-filter">';
						echo '<a href="#all" class="is-active">'. esc_html__( 'All', 'shadowcore' ) .'</a>';
						foreach( $tax_filter_arr as $s => $n ) {
							echo '<a href="#'. esc_attr( $s ) .'">'. esc_html__( $n ) .'</a>';
						}
						echo '</div><!-- .shadowcore-posts-grid-filter -->';
					} else {
						$tax_filter = false;
					}
				} else {
					$tax_filter = false;
				}

				$options = Array(
					'type' => $grid_type,
					'filter_tax' => ( $settings[ 'tax_filter' ] == 'yes' ? $tax_filter : false ),
					'i_width' => $settings['image_width'],
					'i_height' => $settings['image_height'],
					'lazy' => $settings[ 'lazy' ],
					'title' => ( $settings[ 'post_title' ] == 'yes' ? true : false),
					'meta' => ( $settings[ 'post_meta' ] == 'yes' ? true : false),
					'meta_values' => array(
						'date' => ( $settings[ 'post_meta__date' ] == 'yes' ? true : false),
						'author' => ( $settings[ 'post_meta__author' ] == 'yes' ? true : false),
						'comments' => ( $settings[ 'post_meta__comments' ] == 'yes' ? true : false),
					),
					'excerpt' => ( $settings[ 'post_excerpt' ] == 'yes' ? true : false),
				);
				if ( count( $display_tax_arr ) > 0 ) {
					foreach ( $display_tax_arr as $n ) {
						$options[ 'meta_custom_values' ][ $n ] = ( $settings[ 'post_meta__' . $n ] == 'yes' ? true : false);
					}
				}
			}
			?>
			<div class="shadowcore-posts-grid" data-type="<?php echo esc_attr( $grid_type ); ?>">
			<?php
			if ( 'custom' !== $post_type ) {
				# Query Grid
				$query = new WP_Query( $args );
				$posts_count = $query->found_posts;
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
						
						$i_meta = false;
						if ( has_post_thumbnail() ) {
							$i_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
							if ( is_array( $i_meta ) ) {
								# has_image
								if ( array_key_exists( 'shadowcore-hhd', $i_meta[ 'sizes' ] ) ) {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-hhd' );
								} else {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
								}
							} else {
								# No Image Found
								$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
							}
						} else {
							# No Image Specified
							$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
						}
						
						# Detect Image size according to Grid Size
						if ( 'grid' == $grid_type ) {
							# Grid
							$i_width = $settings['image_width'];
							$i_height = $settings['image_height'];
						} else {
							# Masonry and Adjusted
							if ( is_array( $i_meta ) ) {
								$i_width = $i_meta[ 'width' ];
								$i_height = $i_meta[ 'height' ];
							} else {
								# No Image Found
								$i_width = 1200;
								$i_height = 800;
							}
						}
						$post_class = 'shadowcore-posts-grid--item';
						$post_filter = false;

						if ( $tax_filter ) {
							$filter_term_list = get_the_terms( get_the_id(), $tax_filter );
							if ( is_array($filter_term_list) ) {
								foreach ( $filter_term_list as $term ) {
									$post_class .= ' brickwall-filter--' . $term->slug; 
								}
							} else {
								$post_class .= ' brickwall-filter--empty';
							}
						}
						?>
						<div id="shadowcore-uqgi-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( $post_class ); ?>>
							<div class="shadowcore-pgi--inner">
								<?php 
								if ( ! empty( $i_url ) ) {
									?>
									<div class="shadowcore-pgi__image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
										<div class="shadowcore-grid-image <?php echo esc_attr( is_array( $i_meta ) ? 'has-post-thmb' : 'no-post-thmb' ) . ' ' . esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $i_url ); ?>">
											<img 
												src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $i_width ); ?>%20<?php echo absint( $i_height ); ?>'%3E%3C/svg%3E"
												alt="<?php echo get_the_title(); ?>" 
												width="<?php echo esc_attr( $i_width ); ?>" 
												height="<?php echo esc_attr( $i_height ); ?>">
										</div><!-- .shadowcore-gallery-image -->
									</div><!-- .shadowcore-pgi__image -->
									<?php
								}
								?>
								<div class="shadowcore-pgi__content">
									<div class="shadowcore-pgi__content-inner">
										<div class="shadowcore-pgi__content_head">
										<?php
										if ( $options[ 'title' ] ) {
											echo '<div class="shadowcore-pgi__title">'. get_the_title() .'</div>';
										}
										if ( $options[ 'meta' ] ) {
											echo '<div class="shadowcore-pgi__meta">';
											if ( array_key_exists('meta_custom_values', $options) && is_array( $options[ 'meta_custom_values' ] ) ) {
												if ( $options[ 'meta_values' ][ 'date' ] ) {
													echo '<div class="shadowcore-pgi__meta--date">'. get_the_date() .'</div>';
												}
												if ( $options[ 'meta_values' ][ 'author' ] ) {
													echo '<div class="shadowcore-pgi__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
												}
												foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
													if ( $state ) {
														$term_list = get_the_terms( get_the_id(), $n );
														$term_string = '';
														if ( is_array( $term_list ) ) {
															foreach ( $term_list as $term ) {
																$term_string .= $term->name . ", ";
															}
															$term_string = substr( $term_string, 0, -2 );
															echo '<div class="shadowcore-pgi__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
														}
													}
												}
												if ( $options[ 'meta_values' ][ 'comments' ] ) {
													echo '<div class="shadowcore-pgi__meta--comments">'. get_comments_number() .' '. esc_html__( 'Comments', 'shadowcore' ) .'</div>';
												}
											}
											echo '</div><!-- .shadowcore-pgi__meta -->';
										}
										?>
										</div><!-- .shadowcore-pgi__content_head -->
										<?php 
										if ( $options[ 'excerpt' ] ) {
											echo '<div class="shadowcore-pgi__excerpt">' . get_the_excerpt() . '</div>';
										}
										?>
									</div><!-- .shadowcore-pgi__content-inner -->
								</div><!-- .shadowcore-pgi__content -->
								<a href="<?php the_permalink(); ?>" class="shadowcore-pgi-link"></a>
							</div><!-- .shadowcore-pgi--inner -->
						</div><!-- .shadowcore-posts-grid--item -->
						<?php
					}
				} else {
					echo '<p>' . esc_html__( 'Oops! Nothing to show here :(', 'shadowcore' ) . '</p>';
				}
			} else {
				# Custom Grid
				if ( count( $settings[ 'custom_items' ] ) ) {

					foreach ( $settings[ 'custom_items' ] as $item ) {
						$image = $item[ 'image' ];
						$i_meta = false;
						if ( ! empty ( $image[ 'id' ] ) ) {
							$i_meta = wp_get_attachment_metadata( $image[ 'id' ] );
							if ( array_key_exists( 'shadowcore-hhd', $i_meta[ 'sizes' ] ) ) {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-hhd' );
							} else {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'large' );
							}
						} else {
							$i_url = $image[ 'url' ];
						}

						if ( 'grid' == $grid_type ) {
							# Grid
							$i_width = $settings['image_width'];
							$i_height = $settings['image_height'];
						} else {
							# Masonry and Adjusted
							if ( is_array( $i_meta ) ) {
								$i_width = $i_meta[ 'width' ];
								$i_height = $i_meta[ 'height' ];
							} else {
								# No Image Found
								$i_width = 1200;
								$i_height = 800;
							}
						}
						$link = $item[ 'link_url' ];
						?>
						<div class="shadowcore-posts-grid--item shadowcore-posts-grid--item-custom">
							<div class="shadowcore-pgi--inner">
								<div class="shadowcore-pgi__image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>">
									<div class="shadowcore-grid-image <?php echo esc_attr( is_array( $i_meta ) ? 'has-post-thmb' : 'no-post-thmb' ) . ' ' . esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $i_url ); ?>">
										<img 
											src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $i_width ); ?>%20<?php echo absint( $i_height ); ?>'%3E%3C/svg%3E"
											alt="<?php echo esc_attr( $item[ 'title' ] ); ?>" 
											width="<?php echo esc_attr( $i_width ); ?>" 
											height="<?php echo esc_attr( $i_height ); ?>">
									</div><!-- .shadowcore-gallery-image -->
								</div><!-- .shadowcore-pgi__image -->
								<div class="shadowcore-pgi__content">
									<div class="shadowcore-pgi__content_head">
									<?php
									if ( ! empty( $item[ 'title' ] ) ) {
										echo '<div class="shadowcore-pgi__title">'. esc_html( $item[ 'title' ] ) .'</div>';
									}
									if ( ! empty( $item[ 'caption' ] ) ) {
										echo '<div class="shadowcore-pgi__meta"><div class="shadowcore-pgi__meta--caption">'.  esc_html( $item[ 'caption' ] ) .'</div></div>';
									}
									?>
									</div><!-- .shadowcore-pgi__content_head -->
									<?php 
									if ( !empty( $item[ 'excerpt' ] ) ) {
										echo '<div class="shadowcore-pgi__excerpt">' . esc_html( $item[ 'excerpt' ] ) . '</div>';
									}
									?>
								</div><!-- .shadowcore-pgi__content -->
								<?php
								if ( ! empty( $link[ 'url' ] ) ) {
									echo '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . ' class="shadowcore-pgi-link"></a>';
								}
								?>
							</div><!-- .shadowcore-pgi--inner -->
						</div><!-- .shadowcore-posts-grid--item -->
						<?php
					}
				}
			}
			?>
			</div><!-- .shadowcore-posts-grid -->
			<?php
			if ( 'custom' !== $post_type ) {
				if ( 'button' == $settings[ 'loading' ] ) {
					$prop = array(
						'url' => admin_url( 'admin-ajax.php' ),
						'nonce' => wp_create_nonce('shadowcore_secure'),
						'args' => $args
					);
					if ( is_array( $options ) ) {
						$prop[ 'options' ] = $options;
					}
					$prop['args']['posts_per_page'] = $settings[ 'posts_per_load' ];
					echo '
					<div class="shadowcore-pgi--button-wrap">
						<a href="#" 
							data-shown="'. esc_attr( $settings[ 'posts_per_page' ] ) .'" 
							data-count="'. esc_attr( $posts_count ) .'" 
							data-prop="'. htmlspecialchars(json_encode($prop), ENT_QUOTES, 'UTF-8') .'" 
							class="shadowcore-pgi--more shadowcore-'. $settings[ 'button_style' ] .'-button '. esc_attr( 'theme' == $settings[ 'button_style' ] ? st_get_theme_prefix().'-button' : null) .'">' . $settings[ 'load_more_label' ] . '</a>
					</div><!-- .shadowcore-pgi--button-wrap -->';
				}
				if ( 'scroll' == $settings[ 'loading' ] ) {
					$prop = array(
						'url' => admin_url( 'admin-ajax.php' ),
						'nonce' => wp_create_nonce('shadowcore_secure'),
						'args' => $args
					);
					if ( is_array( $options ) ) {
						$prop[ 'options' ] = $options;
					}
					echo '
					<div class="shadowcore-pgi--load" 
						data-shown="'. esc_attr( $settings[ 'posts_per_page' ] ) .'" 
						data-count="'. esc_attr( $posts_count ) .'" 
						data-prop="'. htmlspecialchars(json_encode($prop), ENT_QUOTES, 'UTF-8') .'" ></div><!-- .shadowcore-pgi--load -->';
				}
				if ( 'pagination' == $settings[ 'loading' ] ) {
					$global_query = $GLOBALS['wp_query'];
					$GLOBALS['wp_query'] = $query;
					get_template_part( 'template-parts/pagination' );
					$GLOBALS['wp_query'] = $global_query;
				}
			}
			?>
		</div><!-- .shadowcore-posts-grid-wrap -->
		<?php
		if ( 'custom' !== $post_type ) {
			# Reset Query
			wp_reset_query();
		}
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Query_Grid_Widget() );