<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Query_Slider_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-query-slider';
	}
	
	public function get_title() {
		return esc_html__( 'Posts Slider', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-post-slider';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}

	public function get_script_depends() {
		return [ 'shadowcore_slide_gallery' ];
	}
	
	protected function register_controls() {	
		# Defaults
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$post_types_list = array();
		if ( array_key_exists('post_types', $defs ) ) {
			foreach ( $defs['post_types'] as $s => $n ) {
				if ( post_type_exists($s) ) {
					$post_types_list[$s] = $n;
				}
			}
		} else {
			foreach ( get_post_types(false, 'objects') as $slug => $obj ) {
				$this_post = get_object_vars($obj);
				if ( ! $this_post[ 'exclude_from_search' ] && $this_post[ 'name' ] !== 'attachment' ) {
					$post_types_list[ $this_post[ 'name' ] ] = $this_post[ 'label' ];
				}
			}
		}		
		$post_types_list['custom'] = esc_html__( 'Custom Items', 'shadowcore' );

		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);
		$this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Select Post Type', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_type', $defs) ? $defs[ 'post_type' ] : 'post' ),
				'options' => $post_types_list
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Select Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Title', 'shadowcore' )
			]
		);
		$repeater->add_control(
			'caption',
			[
				'label' => esc_html__( 'Meta (Caption)', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Caption', 'shadowcore' )
			]
		);
		$repeater->add_control(
            'excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
            ]
		);
		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'false',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);
		
		$this->add_control(
			'custom_items',
			[
				'label' => esc_html__( 'Custom Items', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default' => [
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 01', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 02', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 03', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
				],
				'condition' => [
					'post_type' => 'custom'
				]
			]
		);

		# Advanced Query
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
							'list' => array()
						);
						foreach ( $terms as $term ) {
							$term_arr['list'][$term->slug] = $term->name;
						}
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					$this->add_control(
						$type . '-tax-filter',
						[
							'label' => esc_html__( 'Taxonomies Filter', 'shadowcore' ),
							'type' => Controls_Manager::POPOVER_TOGGLE,
							'label_off' => esc_html__( 'All', 'shadowcore' ),
							'label_on' => esc_html__( 'Custom', 'shadowcore' ),
							'return_value' => 'yes',
							'condition' => [
								'post_type' => $type
							]
						]
					);
					$this->start_popover();
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							$type . '-' . $term_arr['slug'] . '-tax',
							[
								'label' => $term_arr['label'],
								'type' => Controls_Manager::SELECT2,
								'options' => $term_arr['list'],
								'multiple' => true,
							]
						);
					}
					$this->end_popover();
				}
			}
		}
		$this->add_control(
			'posts_ignore',
			[
				'label' => esc_html__( 'Hide posts without Featured Image', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('posts_ignore', $defs) ? $defs[ 'posts_ignore' ] : 'yes' ),
			]
		);

		$this->add_control(
			'divider-order',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Sort Posts By', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('orderby', $defs) ? $defs[ 'orderby' ] : 'date' ),
				'options' => [
					'title' => esc_html__( 'Title', 'shadowcore' ),
					'date' => esc_html__( 'Date', 'shadowcore' ),
					'name' => esc_html__( 'Name (slug)', 'shadowcore' ),
					'rand' => esc_html__( 'Random', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Posts Order', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('order', $defs) ? $defs[ 'order' ] : 'DESC' ),
				'options' => [
					'DESC' => esc_html__( 'Descending', 'shadowcore' ),
					'ASC' => esc_html__( 'Ascending', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);

		$this->add_control(
			'divider-slider-height',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'height_type',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('height_type', $defs) ? $defs[ 'height_type' ] : 'screen' ),
                'options' => [
					'screen'  => esc_attr__( 'Screen Height', 'shadowcore' ),
					'custom'  => esc_attr__( 'Custom', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-slider-height--',
			]
		);
        
        $this->add_responsive_control(
			'custom_height',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height', $defs) ? $defs[ 'custom_height' ] : [ 
					'unit' => 'vh',
                    'size' => 100,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-height--custom .shadowcore-slider-wrap' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'height_type' => 'custom'
				],
			]
		);

		$this->add_control(
			'custom_height_reduce',
			[
				'label' => esc_html__( 'Reduce Height?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'prefix_class' => 'shadowcore-slider-height-reduce--',
				'default' => ( array_key_exists('custom_height_reduce', $defs) ? $defs[ 'custom_height_reduce' ] : 'no' ),
				'condition' => [
					'height_type' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'custom_height_reduce_val',
			[
				'label' => esc_attr__( 'Height Reduction Value', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
                        'max' => 1280
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height_reduce_val', $defs) ? $defs[ 'custom_height_reduce_val' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-height--custom.shadowcore-slider-height-reduce--yes .shadowcore-slider-wrap' => 'height: calc({{custom_height.SIZE}}{{custom_height.UNIT}} - {{SIZE}}{{UNIT}});',
				],
                'condition' => [
					'height_type' => 'custom',
					'custom_height_reduce' => 'yes',
				],
			]
		);
		$this->add_control(
			'divider-post-content',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'post_content',
			[
				'label' => esc_html__( 'Show Post Content', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_content', $defs) ? $defs[ 'post_content' ] : 'yes' ),
			]
		);
		$this->add_control(
			'divider-style-tamplate01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_title',
			[
				'label' => esc_html__( 'Show Post Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_title', $defs) ? $defs[ 'post_title' ] : 'yes' ),
				'condition' => [
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta',
			[
				'label' => esc_html__( 'Show Post Meta', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta', $defs) ? $defs[ 'post_meta' ] : 'yes' ),
				'condition' => [
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__date',
			[
				'label' => esc_html__( 'Show Post Date', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__date', $defs) ? $defs[ 'post_meta__date' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__author',
			[
				'label' => esc_html__( 'Show Post Author', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__author', $defs) ? $defs[ 'post_meta__author' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		
		# Custom Taxonomies (Default Template)
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
						);
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							'post_meta__' . $term_arr['slug'],
							[
								'label' => esc_html__( 'Show', 'shadowcore' ) . ' ' . $term_arr['label'],
								'type' => Controls_Manager::SWITCHER,
								'label_on' => esc_html__( 'Yes', 'shadowcore' ),
								'label_off' => esc_html__( 'No', 'shadowcore' ),
								'return_value' => 'yes',
								'default' => ( array_key_exists('post_meta__' . $term_arr['slug'], $defs) ? $defs[ 'post_meta__' . $term_arr['slug'] ] : 'no' ),
								'condition' => [
									'post_meta' => 'yes',
									'post_content' => 'yes',
									'post_type' => $type
								]
							]
						);
					}
				}
			}
		}
		
		$this->add_control(
			'post_meta__comments',
			[
				'label' => esc_html__( 'Show Post Comments Count', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__comments', $defs) ? $defs[ 'post_meta__comments' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_excerpt',
			[
				'label' => esc_html__( 'Show Post Excerpt', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_excerpt', $defs) ? $defs[ 'post_excerpt' ] : 'no' ),
				'condition' => [
					'post_content' => 'yes',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-slider-props',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'fit_type',
			[
				'label' => esc_attr__( 'Content Fitting', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('fit_type', $defs) ? $defs[ 'fit_type' ] : 'cover' ),
                'options' => [
					'cover'  => esc_attr__( 'Cover', 'shadowcore' ),
					'fit-all'  => esc_attr__( 'Fit Always', 'shadowcore' ),
					'fit-v'  => esc_attr__( 'Fit Vertical', 'shadowcore' ),
					'fit-h'  => esc_attr__( 'Fit Horizontal', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-slider--',
			]
		);
        
        $this->add_control(
			'slide_type',
			[
				'label' => esc_attr__( 'Transition Effect', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('slide_type', $defs) ? $defs[ 'slide_type' ] : 'simple' ),
                'options' => [
					'simple'  => esc_attr__( 'Simple', 'shadowcore' ),
					'parallax'  => esc_attr__( 'Parallax', 'shadowcore' ),
					'fade'  => esc_attr__( 'Fade', 'shadowcore' )
				]
			]
		);
        
        $this->add_control(
			'divider-gallery-nav',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_control(
			'slider_nav',
			[
				'label' => esc_attr__( 'Navigation Type', 'shadowcore' ),
                'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('slider_nav', $defs) ? $defs[ 'slider_nav' ] : 'none' ),
                'options' => [
					'none'  => esc_attr__( 'None', 'shadowcore' ),
					'arrows'  => esc_attr__( 'Arrows', 'shadowcore' ),
					'text'  => esc_attr__( 'Text Labels', 'shadowcore' ),
					'dots'  => esc_attr__( 'Dots', 'shadowcore' ),
				]
			]
		);
        
        $this->add_control(
			'slider_nav_label_prev',
			[
				'label' => esc_html__( '"Prev" label:', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Prev', 'shadowcore' ),
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'slider_nav_label_next',
			[
				'label' => esc_html__( '"Next" label:', 'shadowcore' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Next', 'shadowcore' ),
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'divider-gallery-anim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
			'zoom',
			[
				'label' => esc_html__( 'Zoom Factor, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 200
					],
				],
				'default' => ( array_key_exists('zoom', $defs) ? $defs[ 'zoom' ] : [ 
					'unit' => '%',
                    'size' => 100,
				 ] ),
			]
		);
        $this->add_control(
            'transition',
            [
				'label' => esc_attr__( 'Transition Speed, ms', 'shadowcore' ),
                'type' => Controls_Manager::NUMBER,
				'default' => ( array_key_exists('transition', $defs) ? $defs[ 'transition' ] : '1000' ),
                'min' => '500',
				'step' => '100',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider[data-type="fade"].is-animating .shadowcore-slider-item' => 'transition: opacity {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider[data-type="simple"].is-animating .shadowcore-slider-item' => 'transition: transform {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider[data-type="parallax"].is-animating .shadowcore-slider-item' => 'transition: transform {{VALUE}}ms;',
					'{{WRAPPER}} .shadowcore-slider.is-animating .shadowcore-slider-item .shadowcore-slider-item--image' => 'transition: transform {{VALUE}}ms;',
				],
            ]
		);
		
		$this->end_controls_section();
		
		# TAB: STYLE
		# Section: Caption Styles
		$this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Gallery', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'overlay_state',
			[
				'label' => esc_html__( 'Gallery Overlay', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'shadowcore' ),
				'label_off' => esc_html__( 'Off', 'shadowcore' ),
				'default' => ( array_key_exists('overlay_state', $defs) ? $defs[ 'overlay_state' ] : 'no' ),
                'prefix_class' => 'shadowcore-slider-overlay--',
			]
		);
        $this->add_control(
			'overlay_color',
			[
				'label' => esc_html__( 'Overlay Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'overlay_state' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-overlay' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'divider-br',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider',
			]
		);
        
		$this->end_controls_section();
        
		# Post Content Styles
        $this->start_controls_section(
			'section_styles_content',
			[
				'label' => esc_html__( 'Post Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_content' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'content_width',
			[
				'label' => esc_attr__( 'Content Width', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('content_width', $defs) ? $defs[ 'content_width' ] : [ 
					'unit' => '%',
                    'size' => 50,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-content' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'divider-styles-content-width',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_title_typo',
				'label' => esc_html__( 'Title Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-psi-title',
                'condition' => [
					'post_title' => 'yes'
				],
			]
		);
        $this->add_control(
			'post_title_color',
			[
				'label' => esc_html__( 'Title Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'post_title' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-psi-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-psi-title a' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_control(
			'divider-styles-content-title',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_title' => 'yes'
				],
			]
		);
		$this->add_control(
			'head_swap',
			[
				'label' => esc_html__( 'Meta Before Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('head_swap', $defs) ? $defs[ 'head_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-psi-swap--',
				'condition' => [
					'post_meta' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'meta_spacing',
			[
				'label' => esc_html__( 'Meta and Title Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('meta_spacing', $defs) ? $defs[ 'meta_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				 'selectors' => [
					'{{WRAPPER}} .shadowcore-psi__meta' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: 0;',
					'{{WRAPPER}}.shadowcore-psi-swap--yes .shadowcore-psi__meta' => 'padding-bottom: {{SIZE}}{{UNIT}}; padding-top: 0;',
				],
                'condition' => [
					'post_meta' => 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'meta_item_spacing',
			[
				'label' => esc_html__( 'Meta Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('meta_item_spacing', $defs) ? $defs[ 'meta_item_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-psi__meta > div:before' => 'margin-left: calc(0.5 * {{SIZE}}{{UNIT}}); margin-right: calc(0.5 * {{SIZE}}{{UNIT}});',
				],
				'condition' => [
					'post_meta' => 'yes'
				],
			]
		);
		$this->add_control(
			'post_meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'post_meta' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-psi__meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-psi__meta a' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_meta_typo',
				'label' => esc_html__( 'Meta Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-psi__meta',
                'condition' => [
					'post_meta' => 'yes'
				],
			]
		);
        $this->add_control(
			'divider-styles-content-meta',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_meta' => 'yes'
				],
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'post_excerpt_typo',
				'label' => esc_html__( 'Excerpt Typography', 'shadowcore' ),
                'condition' => [
					'post_excerpt' => 'yes'
				],
				'selector' => '{{WRAPPER}} .shadowcore-psi__excerpt'
			]
		);
        $this->add_control(
			'descr_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'post_excerpt' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-psi__excerpt' => 'color: {{VALUE}};'
				]
			]
		);
        $this->add_responsive_control(
			'description_spacing',
			[
				'label' => esc_html__( 'Excerpt Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('description_spacing', $defs) ? $defs[ 'description_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-psi__excerpt' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'post_excerpt' => 'yes'
				],
			]
		);
        $this->add_control(
			'divider-caption-descr',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_excerpt' => 'yes'
				],
			]
		);
        $this->add_control(
			'content_v_position',
			[
				'label' => esc_attr__( 'Content Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('content_v_position', $defs) ? $defs[ 'content_v_position' ] : 'flex-end' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-item' => 'align-items: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'content_h_position',
			[
				'label' => esc_attr__( 'Content Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('content_h_position', $defs) ? $defs[ 'content_h_position' ] : 'flex-start' ),
                'options' => [
					'flex-start' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'flex-end' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-item' => 'justify-content: {{VALUE}};',
				],
			]
		);
        $this->add_control(
			'divider-content-padding',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
		$this->add_responsive_control(
			'caption_margin',
			[
				'label' => esc_html__( 'Content Margin', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_margin', $defs) ? $defs[ 'caption_margin' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);

        $this->add_responsive_control(
			'caption_padding',
			[
				'label' => esc_html__( 'Content Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_padding', $defs) ? $defs[ 'caption_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_control(
			'caption_bg',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-content' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_responsive_control(
			'caption_br',
			[
				'label' => esc_html__( 'Caption Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_br', $defs) ? $defs[ 'caption_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'caption_shadow',
				'label' => esc_html__( 'Caption Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-content',
			]
		);
        
		$this->end_controls_section();
        
        # Navigation Style Section
        $this->start_controls_section(
			'section_styles_nav',
			[
				'label' => esc_html__( 'Navigation', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
        
        $this->add_control(
			'no_nav',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Navigation elements are disabled by the "Navigation Type" option.', 'shadowcore' ),
				'content_classes' => 'shadowcore-elementor-message shadowcore-no-captions',
				'condition' => [
					'slider_nav' => 'none'
				],
			]
		);
        
        $this->add_control(
			'nav_v_position',
			[
				'label' => esc_attr__( 'Navigation Vertical Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('nav_v_position', $defs) ? $defs[ 'nav_v_position' ] : 'middle' ),
                'options' => [
					'top' => [
						'title' => esc_attr__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_attr__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_attr__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
                'prefix_class' => 'shadowcore-slider-nav--',
			]
		);
        $this->add_control(
			'nav_h_position',
			[
				'label' => esc_attr__( 'Navigation Horizontal Position', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => ( array_key_exists('nav_h_position', $defs) ? $defs[ 'nav_h_position' ] : 'center' ),
                'options' => [
					'left' => [
						'title' => esc_attr__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_attr__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => esc_attr__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-h-align-right',
					],
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
                'prefix_class' => 'shadowcore-slider-nav--',
			]
		);
        
        $this->add_control(
			'divider-nav-position',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'nav_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('nav_spacing', $defs) ? $defs[ 'nav_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a:last-child' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a:last-child' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-nav .shadowcore-slider-dots a:not(:first-child)' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_responsive_control(
			'nav_padding',
			[
				'label' => esc_html__( 'Navigation Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('nav_padding', $defs) ? $defs[ 'nav_padding' ] : [ 
					'top' => '40',
					'right' => '40',
					'bottom' => '40',
					'left' => '40',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_control(
			'divider-nav-spacing',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        $this->add_responsive_control(
			'nav_size',
			[
				'label' => esc_html__( 'Items Size', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('nav_size', $defs) ? $defs[ 'nav_size' ] : [ 
					'unit' => 'px',
                    'size' => 24,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a i' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'slider_nav' => [ 'dots','arrows' ]
				],
			]
		);
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'nav_typo',
				'label' => esc_html__( 'Labels Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a',
                'condition' => [
					'slider_nav' => 'text'
				],
			]
		);
        
        $this->add_control(
			'divider-nav-borders',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'nav_dots_border',
                'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a',
                'condition' => [
                    'slider_nav' => 'dots'
                ]
            ]
        );
        $this->add_control(
			'nav_dots_radius',
			[
				'label' => esc_html__( 'Dots Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ '%', 'px' ],
				'default' => ( array_key_exists('nav_dots_radius', $defs) ? $defs[ 'nav_dots_radius' ] : [ 
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'isLinked' => true,
					'unit' => '%'
				 ] ),
                'condition' => [
					'slider_nav' => 'dots',
				],
                'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'nav_dots_shadow',
				'label' => esc_html__( 'Dots Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a',
				'condition' => [
					'slider_nav' => 'dots',
				],
			]
		);
        
        $this->add_control(
			'divider-nav-block',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        
        $this->add_control(
			'nav_dots_wrapper',
			[
				'label' => esc_html__( 'Show Dots Wrapper?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('nav_dots_wrapper', $defs) ? $defs[ 'nav_dots_wrapper' ] : 'no' ),
                'prefix_class' => 'shadowcore-slider-nav-wrap--',
                'condition' => [
					'slider_nav' => 'dots'
				],
			]
		);
        $this->add_control(
			'nav_wrapper_bg',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'background-color: {{VALUE}};'
				]
			]
		);
        $this->add_responsive_control(
			'nav_wrapper_padding',
			[
				'label' => esc_html__( 'Inner Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('nav_wrapper_padding', $defs) ? $defs[ 'nav_wrapper_padding' ] : [ 
					'top' => '10',
					'right' => '10',
					'bottom' => '10',
					'left' => '10',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'divider-before-wrap-border',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav' => 'dots',
					'nav_dots_wrapper' => 'yes'
				],
			]
		);
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'nav_wrapper_border',
                'selector' => '{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots',
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
            ]
        );
        $this->add_control(
			'divider-after-wrap-border',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav' => 'dots',
					'nav_dots_wrapper' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'nav_wrapper_radius',
			[
				'label' => esc_html__( 'Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ '%', 'px' ],
				'default' => ( array_key_exists('nav_wrapper_radius', $defs) ? $defs[ 'nav_wrapper_radius' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				 ] ),
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_wrapper' => 'yes'
				],
                'selectors' => [
					'{{WRAPPER}}.shadowcore-slider-nav-wrap--yes .shadowcore-slider-nav--dots .shadowcore-slider-dots' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				]
			]
		);
        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'nav_wrapper_shadow',
				'label' => esc_html__( 'Box Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots',
				'condition' => [
					'slider_nav' => 'dots',
					'nav_dots_wrapper' => 'yes'
				],
			]
		);
        
        $this->add_control(
			'divider-nav-colors',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'slider_nav!' => 'none'
				],
			]
		);
        
        $this->add_control(
			'nav_color_n',
			[
				'label' => esc_html__( 'Normal Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav!' => 'none'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a' => 'color: {{VALUE}}',
				]
			]
		);
        $this->add_control(
			'nav_color_h',
			[
				'label' => esc_html__( 'Hover Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav!' => 'none'
				],
                'return_value' => 'no',
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a:hover' => 'background-color: {{VALUE}};',
                    'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--arrows .shadowcore-slider-nav a:hover' => 'color: {{VALUE}}',
                    'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--text .shadowcore-slider-nav a:hover' => 'color: {{VALUE}}',
				]
			]
		);
        $this->add_control(
			'nav_color_a',
			[
				'label' => esc_html__( 'Active Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots'
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a.is-active' => 'background-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'divider-nav-border-colors',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
			]
		);
        $this->add_control(
			'nav_border_n',
			[
				'label' => esc_html__( 'Normal Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a' => 'border-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'nav_border_h',
			[
				'label' => esc_html__( 'Hover Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a:hover' => 'border-color: {{VALUE}};',
				]
			]
		);
        $this->add_control(
			'nav_border_a',
			[
				'label' => esc_html__( 'Active Border Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
                'condition' => [
					'slider_nav' => 'dots',
                    'nav_dots_border!' => 'none',
				],
                'return_value' => 'no',
				'selectors' => [
					'{{WRAPPER}} .shadowcore-slider-nav--dots .shadowcore-slider-dots a.is-active' => 'border-color: {{VALUE}};',
				]
			]
		);
        
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_type = $settings[ 'post_type' ];
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$nav_type = $settings[ 'slider_nav' ];
		$hasTax = 'custom' !== $post_type ? get_object_taxonomies( $post_type ) : [];
		$taxonomies = $hasTax ? get_object_taxonomies( $post_type, 'objects' ) : [];

		if ( 'custom' !== $post_type ) {
			# Paged
			$paged = 1;

			# Query Args
			$args = array(
				'post_type' 	 => $post_type,
				'post_status' 	 => 'publish',
				'paged' 		 => absint( $paged ),
				'posts_per_page' => -1,
				'orderby' 		 => esc_attr( $settings[ 'orderby' ] ),
				'order' 		 => esc_attr( $settings[ 'order' ] ),
			);

			# Taxonomies
			if ( array_key_exists($post_type . '-tax-filter', $settings) && count( $hasTax ) > 0 && 'yes' == $settings[ $post_type . '-tax-filter' ] ) {
				if ( count( $taxonomies ) > 0 ) {
					$tax_query = array();
					foreach ( $taxonomies as $n => $o) {
						$terms = get_terms( $n );
						if ( count( $terms ) > 0 ) {
							$selected_terms = $settings[ $post_type . '-' . $n . '-tax' ];
							if ( is_array( $selected_terms ) && count( $selected_terms ) > 0 ) {
								$this_term = array(
									'taxonomy' => $n,
									'field'    => 'slug',
									'terms'    => $selected_terms
								);
								array_push( $tax_query, $this_term );
							}
						}
					}
					if ( count( $tax_query ) > 0 ) {
						$args['tax_query'] = $tax_query;
					}
				}
			}

			$display_tax_arr = Array();
			if ( count( $hasTax ) > 0 ) {
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						array_push( $display_tax_arr, $n );
					}
				}
			}
		} else {
			$options = false;
		}
		?>
		<div class="shadowcore-posts-slider-wrap shadowcore-slider-wrap shadowcore-slider-nav--<?php echo esc_attr( $nav_type ); ?>" data-nav="<?php echo esc_attr( $nav_type ); ?>">
			<?php
				if ( 'custom' !== $post_type ) {
				$options = Array(
					'title' => ( $settings[ 'post_title' ] == 'yes' ? true : false),
					'meta' => ( $settings[ 'post_meta' ] == 'yes' ? true : false),
					'meta_values' => array(
						'date' => ( $settings[ 'post_meta__date' ] == 'yes' ? true : false),
						'author' => ( $settings[ 'post_meta__author' ] == 'yes' ? true : false),
						'comments' => ( $settings[ 'post_meta__comments' ] == 'yes' ? true : false),
					),
					'excerpt' => ( $settings[ 'post_excerpt' ] == 'yes' ? true : false),
				);
				if ( count( $display_tax_arr ) > 0 ) {
					foreach ( $display_tax_arr as $n ) {
						$options[ 'meta_custom_values' ][ $n ] = ( $settings[ 'post_meta__' . $n ] == 'yes' ? true : false);
					}
				}
			}
			?>
			<div class="shadowcore-posts-slider shadowcore-slider shadowcore-cursor--scrollH" data-type="<?php echo esc_attr( $settings['slide_type'] ); ?>" data-zoom="<?php echo esc_attr( $settings[ 'zoom' ][ 'size' ] ); ?>" data-id="<?php echo esc_attr( $this->get_id() ); ?>">
			<?php
			$i = 0;
			if ( 'custom' !== $post_type ) {
				# Query slider
				$query = new WP_Query( $args );
				$posts_count = $query->found_posts;
				$has_thmb = false;
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
					
						if ( has_post_thumbnail() ) {
							$i_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
							if ( is_array( $i_meta ) ) {
								# has_image
								if ( array_key_exists( 'shadowcore-fhd', $i_meta[ 'sizes' ] ) ) {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-fhd' );
								} else {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
								}
								$has_thmb = true;
								$i_width = $i_meta[ 'width' ];
								$i_height = $i_meta[ 'height' ];
							} else {
								# No Image Found
								$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
								$i_width = 800;
								$i_height = 1200;
							}
						} else {
							# No Image Specified
							$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
							$i_width = 800;
							$i_height = 1200;
						}
						$image_ratio = round( $i_width / $i_height, 3 );
						$post_class = 'shadowcore-posts-slider--item shadowcore-slider-item';
						if ($has_thmb) {
							?>
							<div class="shadowcore-slider-item shadowcore-post-slider-item" data-ind="<?php echo esc_attr( $i ); ?>">
	                            <div class="shadowcore-slider-item--image" data-src="<?php echo esc_url( $i_url ); ?>"></div>
	                            <div class="shadowcore-slider-overlay"></div>
	                            <?php if ( $settings[ 'post_content' ] == 'yes' ) { ?>
	                            <div class="shadowcore-slider-content">
									<?php
									if ( $options[ 'title' ] || $options[ 'meta' ] ) {
										echo '<div class="shadowcore-psi__content_head">';
									}
									if ( $options[ 'title' ] ) {
										echo '<div class="shadowcore-slider-caption shadowcore-psi__title">'. get_the_title() .'</div>';
									}
									if ( $options[ 'meta' ] ) {
										echo '<div class="shadowcore-psi__meta">';
										if ( array_key_exists('meta_custom_values', $options) && is_array( $options[ 'meta_custom_values' ] ) ) {
											if ( $options[ 'meta_values' ][ 'date' ] ) {
												echo '<div class="shadowcore-psi__meta--date">'. get_the_date() .'</div>';
											}
											if ( $options[ 'meta_values' ][ 'author' ] ) {
												echo '<div class="shadowcore-psi__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
											}
											foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
												if ( $state ) {
													$term_list = get_the_terms( get_the_id(), $n );
													$term_string = '';
													if ( is_array( $term_list ) ) {
														foreach ( $term_list as $term ) {
															$term_string .= $term->name . ", ";
														}
														$term_string = substr( $term_string, 0, -2 );
														echo '<div class="shadowcore-psi__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
													}
												}
											}
											if ( $options[ 'meta_values' ][ 'comments' ] ) {
												$comment_count = get_comments_number();
												if ( 'product' == $post_type ) {
													if ( $comment_count === '1' ) {
														$comment_label = esc_html__( 'Review', 'shadowcore' );
													} else {
														$comment_label = esc_html__( 'Reviews', 'shadowcore' );
													}
												} else {
													if ( $comment_count === 1 ) {
														$comment_label = esc_html__( 'Comment', 'shadowcore' );
													} else {
														$comment_label = esc_html__( 'Comments', 'shadowcore' );
													}
												}
												echo '<div class="shadowcore-psi__meta--comments">'. esc_html( $comment_count ) .' '. $comment_label .'</div>';
											}
										}
										echo '</div><!-- .shadowcore-psi__meta -->';
									}
									if ( $options[ 'title' ] || $options[ 'meta' ] ) {
										echo '</div><!-- .shadowcore-psi__content_head -->';
									}
									if ( $options[ 'excerpt' ] ) {
										echo '<div class="shadowcore-psi__excerpt">' . get_the_excerpt() . '</div>';
									}
									?>
	                            </div><!-- .shadowcore-slider-content -->
	                        	<?php } ?>
								<a href="<?php the_permalink(); ?>" class="shadowcore-psi-link shadowcore-slider-link"></a>
	                        </div><!-- .shadowcore-slider-item -->
							<?php
							$i++;
						}

					}
				} else {
					echo '<p>' . esc_html__( 'Oops! Nothing to show here :(', 'shadowcore' ) . '</p>';
				}
			} else {
				# Custom slider
				if ( count( $settings[ 'custom_items' ] ) ) {
					foreach ( $settings[ 'custom_items' ] as $item ) {
						$image = $item[ 'image' ];
						if ( ! empty ( $image[ 'id' ] ) ) {
							$i_meta = wp_get_attachment_metadata( $image[ 'id' ] );
							if ( array_key_exists( 'shadowcore-fhd', $i_meta[ 'sizes' ] ) ) {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-fhd' );
							} else {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'full' );
							}
							$i_width = $i_meta[ 'width' ];
							$i_height = $i_meta[ 'height' ];
						} else {
							$i_url = $image[ 'url' ];
							$i_width = 1200;
							$i_height = 800;
						}
						$post_class = 'shadowcore-posts-slider--item shadowcore-custom-slider--item shadowcore-slider-item';
						$link = $item[ 'link_url' ];
						?>
						<div class="shadowcore-slider-item shadowcore-post-slider-item" data-ind="<?php echo esc_attr( $i ); ?>">
							<div class="shadowcore-slider-item--image" data-src="<?php echo esc_url( $i_url ); ?>"></div>
							<div class="shadowcore-slider-overlay"></div>
							<div class="shadowcore-slider-content">
								<?php 
								if ( ! empty( $item[ 'title' ] ) || ! empty( $item[ 'caption' ] ) ) {
									echo '<div class="shadowcore-psi__content_head">';
									if ( ! empty( $item[ 'title' ] ) ) {
										echo '<div class="shadowcore-slider-caption shadowcore-psi__title">'. esc_html( $item[ 'title' ] ) .'</div>';
									}
									if ( ! empty( $item[ 'caption' ] ) ) {
										echo '<div class="shadowcore-psi__meta"><div class="shadowcore-psi__meta--caption">'.  esc_html( $item[ 'caption' ] ) .'</div></div>';
									}
									echo '</div><!-- .shadowcore-psi__content_head -->';
								}
								if ( ! empty( $item[ 'excerpt' ] ) ) {
									echo '<div class="shadowcore-psi__excerpt">';
									echo esc_attr( nl2br( $item[ 'excerpt' ] ) );
									echo '</div><!-- .shadowcore-psi__excerpt -->';
								}
								?>
							</div><!-- .shadowcore-slider-content -->
							<?php
							if ( ! empty( $link[ 'url' ] ) ) {
								echo '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . ' class="shadowcore-psi-link shadowcore-slider-link"></a>';
							}
							?>
						</div><!-- .shadowcore-posts-slider--item -->
						<?php
						$i++;
					}
				}
			}
			?>
			</div><!-- .shadowcore-posts-slider -->
			<?php
			# Navigation
			if ( 'none' !== $nav_type ) {
				echo '<nav class="shadowcore-slider-nav">';
				if ( 'arrows' == $nav_type) {
					# Arrows Navigation
					echo '
					<a href="javascript:void(0)" class="shadowcore-slider-prev">
						<i class="eicon-chevron-left"></i>
					</a>
					<a href="javascript:void(0)" class="shadowcore-slider-next">
						<i class="eicon-chevron-right"></i>
					</a>
					';
				}
				if ( 'text' == $nav_type) {
					# Text Navigation
					echo '
					<a href="javascript:void(0)" class="shadowcore-slider-prev">
						'. esc_html( $settings[ 'slider_nav_label_prev' ]) .'
					</a>
					<a href="javascript:void(0)" class="shadowcore-slider-next">
						'. esc_html( $settings[ 'slider_nav_label_next' ]) .'
					</a>
					';

				}
				if ( 'dots' == $nav_type) {
					echo '<div class="shadowcore-slider-dots">';
					# Dots Navigation
					$c = 0;
					while ( $c < $i ) {
						echo '<a href="javascript:void(0)" data-ind="'. esc_attr( $c ) .'" class="shadowcore-slider-dot"></a>';
						$c++;
					}
					echo '</div><!-- .shadowcore-slider-dots -->';
				}
				echo '</nav><!-- .shadowcore-slider-nav -->';
			}
			?>
		</div><!-- .shadowcore-posts-slider-wrap -->
		<?php
		if ( 'custom' !== $post_type ) {
			# Reset Query
			wp_reset_query();
		}
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Query_Slider_Widget() );