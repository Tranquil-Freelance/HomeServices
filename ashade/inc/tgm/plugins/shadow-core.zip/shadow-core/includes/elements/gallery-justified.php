<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Gallery_Justified_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-gallery-justified';
	}
	
	public function get_title() {
		return esc_html__( 'Gallery: Justified', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-gallery-justified';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}

	public function get_script_depends() {
		return [ 'jquery-justified-gallery' ];
	}

	public function get_style_depends() {
		return [ 'justified-gallery' ];
	}
	
	protected function register_controls() {
		# Defaults
        $defs = shadowcore_get_widget_defaults( $this->get_name() );
        
		# TAB: CONTENT
		# Section: Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Gallery Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);

		if ( get_theme_support( 'shadowcore-video-galleries' ) ) {
			$this->add_control(
				'content_type',
				[
					'label' => esc_html__( 'Gallery Content Type', 'shadowcore' ),
					'label_block' => true,
					'type' => Controls_Manager::SELECT,
					'default' => 'images',
					'options' => [
						'images' => esc_html__( 'Images', 'shadowcore' ),
						'mixed' => esc_html__( 'Mixed', 'shadowcore' )
					]
				]
			);
			
			// Mixed Type
			$repeater = new Repeater();

			$repeater->add_control(
				'item_image',
				[
					'label' => esc_html__( 'Select Image:', 'shadowcore' ),
					'type' => Controls_Manager::MEDIA,
					'default' => [
						'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
					],
				]
			);
			$repeater->add_control(
				'video_url',
				[
					'label' => esc_html__( 'Video Embed URL:', 'shadowcore' ),
					'label_block' => true,
					'description' => esc_html__( 'Youtube or Viemo video URL only.', 'shadowcore' ),
					'type' => Controls_Manager::TEXT,
					'default' => ''
				]
			);
			$repeater->add_control(
				'link_type',
				[
					'label' => esc_html__( 'Item Link Type', 'shadowcore' ),
					'label_block' => true,
					'type' => Controls_Manager::SELECT,
					'default' => 'lightbox',
					'options' => [
						'lightbox' => esc_html__( 'Open Lightbox', 'shadowcore' ),
						'custom' => esc_html__( 'Custom Link', 'shadowcore' )
					]
				]
			);
			$repeater->add_control(
				'link_url',
				[
					'label' => esc_html__( 'Link URL', 'shadowcore' ),
					'type' => Controls_Manager::URL,
					'default' => [
						'url' => '',
						'is_external' => 'true',
					],
					'condition' => [
						'link_type' => 'custom'
					],
					'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
				]
			);
			$this->add_control(
				'mixed_gallery',
				[
					'label' => esc_html__( 'Add Items', 'shadowcore' ),
					'type' => Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'item_image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
							'video_url' => '',
							'link_type' => 'lightbox',
							'link_url' => ['url' => '', 'is_external' => 'true']
						],
						[
							'item_image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
							'video_url' => '',
							'link_type' => 'lightbox',
							'link_url' => ['url' => '', 'is_external' => 'true']
						],
					],
					'condition' => [
						'content_type' => 'mixed'
					],
				]
			);
			
			// Image Type
			$this->add_control(
				'gallery',
				[
					'label' => esc_html__( 'Add Images', 'shadowcore' ),
					'type' => Controls_Manager::GALLERY,
					'default' => [],
					'condition' => [
						'content_type' => 'images'
					],
				]
			);
		} else {
			$this->add_control(
				'gallery',
				[
					'label' => esc_html__( 'Add Images', 'shadowcore' ),
					'type' => Controls_Manager::GALLERY,
					'default' => [],
				]
			);
		}
		$this->add_control(
			'randomize_images',
			[
				'label' => esc_html__( 'Randomize Gallery?', 'shadowcore' ),
				'description' => esc_html__( 'Shuffle images on each time gallery loads.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('randomize_images', $defs) ? $defs[ 'randomize_images' ] : 'no' ),
			]
		);
		$this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Images Lazy Loading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'default' => ( array_key_exists('lazy', $defs) ? $defs[ 'lazy' ] : 'yes' ),
			]
		);
		$this->add_control(
			'lightbox_state',
			[
				'label' => esc_html__( 'Open images in Lightbox', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lightbox_state', $defs) ? $defs[ 'lightbox_state' ] : 'yes' ),
			]
		);
		$this->add_control(
			'divider-gallery',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
            'row_height',
            [
                'label' => esc_html__( 'Row Height', 'shadowcore' ),
				'type' => Controls_Manager::NUMBER,
				'description' => esc_html__( 'The preferred rows height in pixel.', 'shadowcore' ),
				'default' => ( array_key_exists('row_height', $defs) ? $defs[ 'row_height' ] : '250' ),
                'min' => '100',
				'step' => '1',
            ]
		);
		$this->add_control(
			'last_row',
			[
				'label' => esc_html__( 'Justify Last Row?', 'shadowcore' ),
				'description' => esc_html__( 'The last row height may be different than others.', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => 'no',
				'default' => ( array_key_exists('last_row', $defs) ? $defs[ 'last_row' ] : 'no' ),
			]
		);
		
		$this->add_control(
			'divider-gallery-dim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'item_spacing',
			[
				'label' => esc_html__( 'Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('item_spacing', $defs) ? $defs[ 'item_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 10,
				 ] ),
			]
		);
		$this->add_control(
			'divider-captions',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'captions',
			[
				'label' => esc_html__( 'Image Captions', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('captions', $defs) ? $defs[ 'captions' ] : 'none' ),
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'on_photo' => esc_html__( 'On Image', 'shadowcore' ),
					'on_hover' => esc_html__( 'On Hover', 'shadowcore' ),
				],
				'prefix_class' => 'shadowcore-grid-caption--',
			]
		);
		$this->add_control(
			'in_lightbox',
			[
				'label' => esc_html__( 'Lightbox Caption', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('in_lightbox', $defs) ? $defs[ 'in_lightbox' ] : 'none' ),
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'caption' => esc_html__( 'Show Caption', 'shadowcore' ),
					'description' => esc_html__( 'Show Description', 'shadowcore' ),
				],
				'condition' => [
					'lightbox_state' => 'yes'
				]
			]
		);

		$this->end_controls_section();

		# TAB: STYLE
		# Section: Image
		$this->start_controls_section(
			'section_style_template',
			[
				'label' => esc_html__( 'Image', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-gallery-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-gallery-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				]),
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'image_shadow',
				'label' => esc_html__( 'Image Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-gallery-image',
			]
		);
		# EOS
		$this->end_controls_section();

		# Section: Caption Styles
		$this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'Caption Styles', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'no_captions',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Captions are disabled by element settings.', 'shadowcore' ),
				'content_classes' => 'shadowcore-elementor-message shadowcore-no-captions',
				'condition' => [
					'captions' => 'none'
				],
			]
		);
		$this->add_responsive_control(
			'caption_spacing',
			[
				'label' => esc_html__( 'Caption Spacing', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_spacing', $defs) ? $defs[ 'caption_spacing' ] : [ 
					'top' => '5',
					'right' => '10',
					'bottom' => '5',
					'left' => '10',
					'isLinked' => false,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-grid-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ]
				],
			]
		);
		$this->add_responsive_control(
			'caption_br',
			[
				'label' => esc_html__( 'Caption Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => ( array_key_exists('caption_br', $defs) ? $defs[ 'caption_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false,
					'unit' => 'px'
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-grid-caption' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ]
				],
			]
		);
		$this->add_control(
			'caption_fullheight',
			[
				'label' => esc_html__( 'Stretch Caption Wrapper?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('caption_fullheight', $defs) ? $defs[ 'caption_fullheight' ] : 'no' ),
				'prefix_class' => 'shadowcore-stretch-caption--',
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ]
				],
			]
		);
		$this->add_control(
			'caption_alignment',
			[
				'label' => esc_html__( 'Caption Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('caption_alignment', $defs) ? $defs[ 'caption_alignment' ] : 'center' ),
				'toggle' => false,
				'condition' => [
					'captions!' => 'none'
				],
				'prefix_class' => 'shadowcore-caption-halign--',
			]
		);
		$this->add_control(
			'caption_valign_flex',
			[
				'label' => esc_html__( 'Caption Vertical Align', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'center' => [
						'title' => esc_html__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'flex-end' => [
						'title' => esc_html__( 'Bottom', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => ( array_key_exists('caption_valign_flex', $defs) ? $defs[ 'caption_valign_flex' ] : 'center' ),
				'toggle' => false,
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ],
					'caption_fullheight' => 'yes'
				],
				'selectors' => [
					'{{WRAPPER}}.shadowcore-stretch-caption--yes .shadowcore-grid-caption' => 'align-items: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'caption_valign_absolute',
			[
				'label' => esc_html__( 'Vertical Align', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => esc_html__( 'Top', 'shadowcore' ),
						'icon' => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Middle', 'shadowcore' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'default' => ( array_key_exists('caption_valign_absolute', $defs) ? $defs[ 'caption_valign_absolute' ] : 'bottom' ),
				'toggle' => false,
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ],
					'caption_fullheight!' => 'yes'
				],
				'prefix_class' => 'shadowcore-caption-valign--',
			]
		);
		$this->add_control(
			'divider-captions-color',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'captions!' => 'none'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'caption_typo',
				'label' => esc_html__( 'Caption Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-grid-caption',
				'condition' => [
					'captions!' => 'none'
				],
			]
		);
		$this->add_control(
			'caption_color',
			[
				'label' => esc_html__( 'Caption Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-grid-caption' => 'color: {{VALUE}};'
				],
				'condition' => [
					'captions!' => 'none'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'caption_shadow',
				'label' => esc_html__( 'Caption Text Shadow', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-grid-caption',
				'condition' => [
					'captions!' => 'none'
				],
			]
		);
		$this->add_control(
			'divider-captions-bg',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'captions!' => 'none'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'caption_bg',
				'label' => esc_html__( 'Background', 'shadowcore' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .shadowcore-grid-caption',
				'condition' => [
					'captions' => [ 'on_photo', 'on_hover' ]
				],
			]
		);

		$this->end_controls_section();

		# Section: Hover Effects
		$this->start_controls_section(
			'section_style_hover',
			[
				'label' => esc_html__( 'Hover Effect', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'fade_items',
			[
				'label' => esc_html__( 'Fade not Hover Items', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('fade_items', $defs) ? $defs[ 'fade_items' ] : 'yes' ),
				'prefix_class' => 'shadowcore-gallery-grid-fade--',
			]
		);
		$this->add_control(
			'fade_items_opacity',
			[
				'label' => esc_html__( 'Item Opacity', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('fade_items_opacity', $defs) ? $defs[ 'fade_items_opacity' ] : [ 
					'unit' => '%',
					'size' => 50,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-gallery-grid-fade--yes .shadowcore-justified-gallery:hover .shadowcore-gallery-image:not(:hover)' => 'opacity: calc({{SIZE}} * 0.01);',
				],
				'condition' => [
					'fade_items' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-hover',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'items_scale',
			[
				'label' => esc_html__( 'Item Zoom on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('items_zoom', $defs) ? $defs[ 'items_zoom' ] : 'no' ),
				'prefix_class' => 'shadowcore-gallery-grid-scale--',
			]
		);
		$this->add_control(
			'items_scale_factor',
			[
				'label' => esc_html__( 'Zoom Value, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 150
					],
				],
				'default' => ( array_key_exists('items_scale_factor', $defs) ? $defs[ 'items_scale_factor' ] : [ 
					'unit' => '%',
					'size' => 105,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-gallery-grid-scale--yes .shadowcore-justified-gallery:hover > a:hover' => 'z-index: 111!important; transform: scale(calc({{SIZE}} * 0.01));',
				],
				'condition' => [
					'items_scale' => 'yes'
				]
			]
		);
		$this->end_controls_section();
	}
	
	protected function render() {
		$type = 'image';
		$settings = $this->get_settings_for_display();
		$gallery = $settings[ 'gallery' ];
		$row_height = $settings[ 'row_height' ];
		$last_row = $settings[ 'last_row' ];
		$item_spacing = $settings[ 'item_spacing' ];
		$randomize_images = $settings[ 'randomize_images' ];
		$in_lightbox = $settings[ 'in_lightbox' ];
		$lightbox_state = $settings[ 'lightbox_state' ];

		if ( get_theme_support( 'shadowcore-video-galleries' ) ) {
			$type = $settings[ 'content_type' ];
			if ( 'mixed' == $type ) {
				$gallery = $settings[ 'mixed_gallery' ];
			} else {
				$gallery = $settings[ 'gallery' ];
			}
		} else {
			$gallery = $settings[ 'gallery' ];
		}
		
		if ( empty( $gallery ) ) {
            echo '<div class="shadowcore-widget-holder"><i class="'. esc_attr( $this->get_icon() ) .'"></i><span>'. esc_html__( 'No Images', 'shadowcore' ) .'</span></div>';
		} else {
			if ( 'yes' == $randomize_images ) {
				shuffle( $gallery );
			}
			?>
			<div class="shadowcore-justified-gallery" 
				data-row-height="<?php echo esc_attr( $row_height ); ?>" 
				data-last-row="<?php echo esc_attr( $last_row ); ?>" 
				data-spacing="<?php echo esc_attr( $item_spacing[ 'size' ] ); ?>">
				<?php 
				foreach ( $gallery as $item ) {
					$hasImage = false;
					$hasLink = false;
					$hasVideo = false;
					
					if ( 'mixed' == $type ) {
						if ( $item[ 'item_image' ][ 'id' ] ) {
							$hasImage = true;
							$imageID = $item[ 'item_image' ][ 'id' ];
							$alt = get_post_meta( $imageID, '_wp_attachment_image_alt', true );
						}
						if ( $item[ 'video_url' ] ) {
							if (strpos( $item[ 'video_url' ], 'outube') || strpos( $item[ 'video_url' ], 'imeo') ) {
								$hasVideo = true;
								if ( strpos( $item[ 'video_url' ], 'outube') ) {
									$videoType = 'youtube';
									$videoID = explode('=', $item[ 'video_url' ] )[1];
									// Check and Remove additional params
									if ( strpos( $item[ 'video_url' ], '&') ) {
										$videoID = explode('&', $videoID )[0];
									}
									if ( ! $hasImage ) {
										$thmb_url = 'https://img.youtube.com/vi/' . esc_attr( $videoID ) . '/0.jpg';
										$alt = esc_attr__( 'Youtube Video Preview', 'shadowcore' );
										$original_image_width = 1920;
										$original_image_height = 1080;
									}
									$href = 'https://www.youtube.com/embed/' . esc_attr( $videoID );
								}
								if ( strpos( $item[ 'video_url' ], 'imeo') ) {
									$videoType = 'vimeo';
									$videoID = explode('.com/', $item[ 'video_url' ] )[1];
									if ( ! $hasImage ) {
										$thmb_request = wp_remote_get( "http://vimeo.com/api/v2/video/$videoID.php" );
										$thmb_data = unserialize( wp_remote_retrieve_body( $thmb_request ) );
										$thmb_url = $thmb_data[0]['thumbnail_large'];
										$image_caption = $thmb_data[0]['title'];
										$alt = $thmb_data[0]['title'];
										if ( 'caption' == $in_lightbox ) {
											$lightbox_text = $image_caption;
										}
										if ( 'description' == $in_lightbox ) {
											$lightbox_text = $thmb_data[0]['description'];
										}
										$original_image_width = $thmb_data[0]['width'];
										$original_image_height = $thmb_data[0]['height'];
									}
									$href = 'https://player.vimeo.com/video/' . esc_attr( $videoID );
								}
							}
						}
						if ( 'custom' == $item[ 'link_type' ] && is_array( $item[ 'link_url'] ) ) {
							$hasLink = true;
						}
					} else {
						$hasImage = true;
						$imageID = $item[ 'id' ];
						$alt = get_post_meta( $imageID, '_wp_attachment_image_alt', true );
					}
					
					if ( $hasImage ) {
						$image_post = get_post( $imageID );
						$image_caption = $image_post->post_excerpt;
						$lightbox_text = '';
						if ( 'caption' == $in_lightbox ) {
							$lightbox_text = $image_caption;
						}
						if ( 'description' == $in_lightbox ) {
							$lightbox_text = $image_post->post_content;
						}
						$meta = wp_get_attachment_metadata( $imageID );
						$original_image_width = $meta[ 'width' ];
						$original_image_height = $meta[ 'height' ];
						$thmb_url = wp_get_attachment_image_url( $imageID, 'large' );
						$original_image_ratio = $original_image_height/$original_image_width;
						$thmb_image_height = absint( $row_height ) * 2;
						$thmb_image_width = $thmb_image_height/$original_image_ratio;
						if ( ! $hasVideo && ! $hasLink ) {
							$href = wp_get_attachment_url( $imageID );
						}
					} else {
						$original_image_ratio = $original_image_height/$original_image_width;
						$thmb_image_height = absint( $row_height ) * 2;
						$thmb_image_width = $thmb_image_height/$original_image_ratio;
						if ( ! $hasVideo ) {
							$thmb_url = get_template_directory_uri() . '/assets/img/holders/image-holder.png';
							$href = get_template_directory_uri() . '/assets/img/holders/image-holder.png';
							$original_image_width = 600;
							$original_image_height = 600;
							$thmb_image_width = $thmb_image_height = 600;
							$image_caption = '';
							$lightbox_text = '';
							$alt = esc_attr__( 'No Image Specified', 'shadowcore' );;
						}
					}
					if ( $hasLink ) {
						echo '<a href="' . esc_url( $item[ 'link_url'][ 'url' ] ) . '" ' . ( $item[ 'link_url'][ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $item[ 'link_url'][ 'nofollow' ] ? 'rel="nofollow"' : '' ) . ' class="'. esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ) .'">';
					} else if ( $lightbox_state == 'yes' ) { ?>
					<a href="<?php echo esc_url( $href ); ?>" 
						class="shadowcore-lightbox-link <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy-await' : '' ); ?>" 
						data-elementor-open-lightbox="no" 
						data-gallery = "justified_<?php echo esc_attr( $this->get_id() ); ?>" 
						<?php 
						if ( $hasVideo ) {
							echo 'data-video-type="'. esc_attr( $videoType ) .'" ';
						}
						if ( ! empty( $lightbox_text ) ) {
							echo 'data-caption="'. esc_attr( $lightbox_text ) .'" ';
						} ?>
						data-size="<?php echo esc_attr( $original_image_width ); ?>x<?php echo esc_attr( $original_image_height ); ?>">
					<?php } else {
						echo '<div class="shadowcore-justified-item">';
					}?>
						<div class="shadowcore-gallery-image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
							<img 
								src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_image_width ); ?>%20<?php echo absint( $thmb_image_height ); ?>'%3E%3C/svg%3E"
								alt="<?php echo esc_attr( get_post_meta( $item[ 'id' ], '_wp_attachment_image_alt', true ) ); ?>" 
								width="<?php echo intval( $thmb_image_width ); ?>" 
								height="<?php echo intval( $thmb_image_height ); ?>">
						</div>
					<div class="shadowcore-grid-caption"><?php echo esc_html( $image_caption ); ?></div>
				<?php if ( $hasLink ) {
						echo '</a>';
					} else if ( $lightbox_state == 'yes' ) {
						echo '</a>';
					} else {
						echo '</div>';
					}
				} ?>
			</div><!-- .shadowcore-grid -->
			<?php
		}
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Gallery_Justified_Widget() );