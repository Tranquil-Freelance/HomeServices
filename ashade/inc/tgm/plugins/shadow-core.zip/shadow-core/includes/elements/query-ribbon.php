<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
namespace Elementor;

use WP_Query;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Shadow_Query_Ribbon_Widget extends Widget_Base {
	
	public function get_name() {
		return 'shadow-query-ribbon';
	}
	
	public function get_title() {
		return esc_html__( 'Posts Ribbon', 'shadowcore' );
	}
	
	public function get_icon() {
		return 'eicon-posts-carousel';
	}
	
	public function get_categories() {
		return [ 'shadow-elements' ];
	}

	public function get_script_depends() {
		return [ 'shadowcore_ribbon_gallery' ];
	}
	
	protected function register_controls() {	
		# Defaults
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$post_types_list = array();
		if ( array_key_exists('post_types', $defs ) ) {
			foreach ( $defs['post_types'] as $s => $n ) {
				if ( post_type_exists($s) ) {
					$post_types_list[$s] = $n;
				}
			}
		} else {
			foreach ( get_post_types(false, 'objects') as $slug => $obj ) {
				$this_post = get_object_vars($obj);
				if ( ! $this_post[ 'exclude_from_search' ] && $this_post[ 'name' ] !== 'attachment' ) {
					$post_types_list[ $this_post[ 'name' ] ] = $this_post[ 'label' ];
				}
			}
		}		
		$post_types_list['custom'] = esc_html__( 'Custom Items', 'shadowcore' );

		# TAB: CONTENT
		# Section: Content Settings
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Query Settings', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_CONTENT
			]
		);
		$this->add_control(
			'post_type',
			[
				'label' => esc_html__( 'Select Post Type', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_type', $defs) ? $defs[ 'post_type' ] : 'post' ),
				'options' => $post_types_list
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Select Image', 'shadowcore' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Title', 'shadowcore' )
			]
		);
		$repeater->add_control(
			'caption',
			[
				'label' => esc_html__( 'Meta (Caption)', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Item Caption', 'shadowcore' )
			]
		);
		$repeater->add_control(
            'excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'shadowcore' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXTAREA,
				'default' => '',
            ]
		);
		$repeater->add_control(
            'link_url',
            [
                'label' => esc_html__( 'Link URL', 'shadowcore' ),
                'type' => Controls_Manager::URL,
				'default' => [
					'url' => '',
					'is_external' => 'false',
				],
				'placeholder' => esc_html__( 'https://your-link.com/', 'shadowcore' ),
            ]
		);
		
		$this->add_control(
			'custom_items',
			[
				'label' => esc_html__( 'Custom Items', 'shadowcore' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ title }}}',
				'default' => [
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 01', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 02', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
					[
						'image' => ['url' => get_template_directory_uri() . '/assets/img/holders/image-holder.png'],
						'title' => esc_html__( 'Item 03', 'shadowcore' ),
						'excerpt' => '',
						'caption' => esc_html__( 'Item Caption', 'shadowcore' ),
						'link_url' => ['url' => '', 'is_external' => 'true']
					],
				],
				'condition' => [
					'post_type' => 'custom'
				]
			]
		);

		# Advanced Query
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
							'list' => array()
						);
						foreach ( $terms as $term ) {
							$term_arr['list'][$term->slug] = $term->name;
						}
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					$this->add_control(
						$type . '-tax-filter',
						[
							'label' => esc_html__( 'Taxonomies Filter', 'shadowcore' ),
							'type' => Controls_Manager::POPOVER_TOGGLE,
							'label_off' => esc_html__( 'All', 'shadowcore' ),
							'label_on' => esc_html__( 'Custom', 'shadowcore' ),
							'return_value' => 'yes',
							'condition' => [
								'post_type' => $type
							]
						]
					);
					$this->start_popover();
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							$type . '-' . $term_arr['slug'] . '-tax',
							[
								'label' => $term_arr['label'],
								'type' => Controls_Manager::SELECT2,
								'options' => $term_arr['list'],
								'multiple' => true,
							]
						);
					}
					$this->end_popover();
				}
			}
		}
		$this->add_control(
			'divider-order',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Sort Posts By', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('orderby', $defs) ? $defs[ 'orderby' ] : 'date' ),
				'options' => [
					'title' => esc_html__( 'Title', 'shadowcore' ),
					'date' => esc_html__( 'Date', 'shadowcore' ),
					'name' => esc_html__( 'Name (slug)', 'shadowcore' ),
					'rand' => esc_html__( 'Random', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Posts Order', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('order', $defs) ? $defs[ 'order' ] : 'DESC' ),
				'options' => [
					'DESC' => esc_html__( 'Descending', 'shadowcore' ),
					'ASC' => esc_html__( 'Ascending', 'shadowcore' ),
				],
				'condition' => [
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-post-type',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'height_type',
			[
				'label' => esc_attr__( 'Gallery Height', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('height_type', $defs) ? $defs[ 'height_type' ] : 'screen' ),
                'options' => [
					'screen'  => esc_attr__( 'Screen Height', 'shadowcore' ),
					'custom'  => esc_attr__( 'Custom', 'shadowcore' ),
				],
                'prefix_class' => 'shadowcore-ribbon-height--',
			]
		);
        
        $this->add_responsive_control(
			'custom_height',
			[
				'label' => esc_attr__( 'Gallery Height, px', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 100,
                        'max' => 2560
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height', $defs) ? $defs[ 'custom_height' ] : [ 
					'unit' => 'vh',
                    'size' => 100,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-ribbon-height--custom .shadowcore-ribbon-wrap' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
					'height_type' => 'custom'
				],
			]
		);

		$this->add_control(
			'custom_height_reduce',
			[
				'label' => esc_html__( 'Reduce Height?', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'prefix_class' => 'shadowcore-ribbon-height-reduce--',
				'default' => ( array_key_exists('custom_height_reduce', $defs) ? $defs[ 'custom_height_reduce' ] : 'no' ),
				'condition' => [
					'height_type' => 'custom',
				],
			]
		);

		$this->add_responsive_control(
			'custom_height_reduce_val',
			[
				'label' => esc_attr__( 'Height Reduction Value', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 0,
                        'max' => 1280
					],
					'vh' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('custom_height_reduce_val', $defs) ? $defs[ 'custom_height_reduce_val' ] : [ 
					'unit' => 'px',
                    'size' => 0,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-ribbon-height--custom.shadowcore-ribbon-height-reduce--yes .shadowcore-ribbon-wrap' => 'height: calc({{custom_height.SIZE}}{{custom_height.UNIT}} - {{SIZE}}{{UNIT}});',
				],
                'condition' => [
					'height_type' => 'custom',
					'custom_height_reduce' => 'yes',
				],
			]
		);

		$this->add_control(
			'divider-spacing',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_type!' => 'custom'
				]
				
			]
		);
        $this->add_responsive_control(
			'items_spacing',
			[
				'label' => esc_html__( 'Items Spacing, PX', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 5
					],
				],
				'default' => ( array_key_exists('items_spacing', $defs) ? $defs[ 'items_spacing' ] : [ 
					'unit' => 'px',
                    'size' => 40,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}:not(.shadowcore-pri-side-spacing--yes) .shadowcore-ribbon' => 'margin-left: -{{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-ribbon > div' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.shadowcore-pri-side-spacing--yes .shadowcore-ribbon .shadowcore-ribbon' => 'margin-right: {{SIZE}}{{UNIT}};',

					'(mobile) {{WRAPPER}}:not(.shadowcore-pri-side-spacing--yes) .shadowcore-ribbon.vertical-mobile-layout' => 'margin-left: 0;',
					'(mobile) {{WRAPPER}}.shadowcore-pri-side-spacing--yes .shadowcore-ribbon.vertical-mobile-layout' => 'margin-left: 0; padding-left: {{SIZE}}{{UNIT}}; padding-right: {{SIZE}}{{UNIT}}; margin-top: -{{SIZE}}{{UNIT}}',
					'(mobile) {{WRAPPER}} .shadowcore-ribbon.vertical-mobile-layout > div' => 'margin-left: 0; margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_control(
			'side_spacing',
			[
				'label' => esc_html__( 'Side Spacings', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('side_spacing', $defs) ? $defs[ 'side_spacing' ] : 'no' ),
				'prefix_class' => 'shadowcore-pri-side-spacing--',
			]
		);
		$this->add_control(
			'divider-lazy',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'lazy',
			[
				'label' => esc_html__( 'Images Lazy Loading', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('lazy', $defs) ? $defs[ 'lazy' ] : 'yes' ),
			]
		);
		$this->add_control(
			'vertical_mobile',
			[
				'label' => esc_html__( 'Vertical Layout for Mobile', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('vertical_mobile', $defs) ? $defs[ 'vertical_mobile' ] : 'no' ),
			]
		);
		$this->add_control(
			'divider-gallery-anim',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control(
			'd-speed',
			[
				'label' => esc_html__( 'Mouse Scroll Speed, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 300,
						'step' => 5
					],
				],
				'default' => ( array_key_exists('d-speed', $defs) ? $defs[ 'd-speed' ] : [ 
					'unit' => '%',
                    'size' => 150,
				 ] ),
			]
		);
		
		$this->add_responsive_control(
			't-speed',
			[
				'label' => esc_html__( 'Touch Scroll Speed, %', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 300
					],
				],
				'default' => ( array_key_exists('t-speed', $defs) ? $defs[ 't-speed' ] : [ 
					'unit' => '%',
                    'size' => 200,
				 ] ),
			]
		);
		
		$this->end_controls_section();

		# TAB: STYLE
		# Section: Template
		$this->start_controls_section(
			'section_style_template',
			[
				'label' => esc_html__( 'Image and Content', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'image_br',
			[
				'label' => esc_html__( 'Image Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-ribbon-item--image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .shadowcore-ribbon-item--image.no-post-thmb:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('image_br', $defs) ? $defs[ 'image_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				] ),
			]
		);
		$this->add_control(
			'divider-style-tamplate01',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'post_content',
			[
				'label' => esc_html__( 'Content Position', 'shadowcore' ),
				'type' => Controls_Manager::SELECT,
				'default' => ( array_key_exists('post_content', $defs) ? $defs[ 'post_content' ] : 'below' ),
				'options' => [
					'none' => esc_html__( 'None', 'shadowcore' ),
					'below' => esc_html__( 'Below the Image', 'shadowcore' ),
					'above' => esc_html__( 'Above the Image', 'shadowcore' ),
					'top' => esc_html__( 'At the Image Top', 'shadowcore' ),
					'bottom' => esc_html__( 'At the Image Bottom', 'shadowcore' ),
				],
				'prefix_class' => 'shadowcore-pri-content--',
			]
		);
		$this->add_control(
			'post_content_fw',
			[
				'label' => esc_html__( 'Stretch Content Block', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_content_fw', $defs) ? $defs[ 'post_content_fw' ] : 'yes' ),
				'prefix_class' => 'shadowcore-pri-content-fw--',
				'condition' => [
					'post_content' => ['top', 'bottom']
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_title',
			[
				'label' => esc_html__( 'Show Post Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_title', $defs) ? $defs[ 'post_title' ] : 'yes' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta',
			[
				'label' => esc_html__( 'Show Post Meta', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta', $defs) ? $defs[ 'post_meta' ] : 'yes' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__date',
			[
				'label' => esc_html__( 'Show Post Date', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__date', $defs) ? $defs[ 'post_meta__date' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_meta__author',
			[
				'label' => esc_html__( 'Show Post Author', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__author', $defs) ? $defs[ 'post_meta__author' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		
		# Custom Taxonomies (Default Template)
		foreach ( $post_types_list as $type => $label ) {
			$taxonomies = get_object_taxonomies( $type, 'objects' );
			if ( count( $taxonomies ) > 0 ) {
				$tax_arr = Array();
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						$term_arr = array(
							'slug' => $n,
							'label' => $props[ 'label' ],
						);
					} else {
						$term_arr = array();
					}
					if ( count( $term_arr ) > 0 ) {
						array_push( $tax_arr, $term_arr );
					}
				}

				if ( count( $tax_arr ) > 0 ) {
					foreach( $tax_arr as $term_arr ) {
						$this->add_control(
							'post_meta__' . $term_arr['slug'],
							[
								'label' => esc_html__( 'Show', 'shadowcore' ) . ' ' . $term_arr['label'],
								'type' => Controls_Manager::SWITCHER,
								'label_on' => esc_html__( 'Yes', 'shadowcore' ),
								'label_off' => esc_html__( 'No', 'shadowcore' ),
								'return_value' => 'yes',
								'default' => ( array_key_exists('post_meta__' . $term_arr['slug'], $defs) ? $defs[ 'post_meta__' . $term_arr['slug'] ] : 'no' ),
								'condition' => [
									'post_meta' => 'yes',
									'post_content!' => 'none',
									'post_type' => $type
								]
							]
						);
					}
				}
			}
		}
		
		$this->add_control(
			'post_meta__comments',
			[
				'label' => esc_html__( 'Show Post Comments Count', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_meta__comments', $defs) ? $defs[ 'post_meta__comments' ] : 'no' ),
				'condition' => [
					'post_meta' => 'yes',
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'divider-style-tamplate03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->add_control(
			'post_excerpt',
			[
				'label' => esc_html__( 'Show Post Excerpt', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('post_excerpt', $defs) ? $defs[ 'post_excerpt' ] : 'no' ),
				'condition' => [
					'post_content!' => 'none',
					'post_type!' => 'custom'
				]
			]
		);
		$this->end_controls_section();

		# Section: Content
		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content Styles', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_content!' => 'none',
				]
			]
		);
		$this->add_responsive_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'default' => ( array_key_exists('padding', $defs) ? $defs[ 'padding' ] : [ 
					'top' => '20',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => false,
					'unit' => 'px'
					] ),
			]
		);
		$this->add_responsive_control(
			'content_br',
			[
				'label' => esc_html__( 'Content Border Radius', 'shadowcore' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => ( array_key_exists('content_br', $defs) ? $defs[ 'content_br' ] : [ 
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'isLinked' => true,
					'unit' => 'px'
				] ),
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Background Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__content' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'shadowcore' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'shadowcore' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'shadowcore' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'shadowcore' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => ( array_key_exists('align', $defs) ? $defs[ 'align' ] : 'left' ),
				'prefix_class' => 'shadowcore-pri-align--',
				'toggle' => false,
			
			]
		);
		$this->add_control(
			'head_swap',
			[
				'label' => esc_html__( 'Meta Before Title', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('head_swap', $defs) ? $defs[ 'head_swap' ] : 'no' ),
				'prefix_class' => 'shadowcore-pri-swap--',
			]
		);
		$this->add_control(
			'divider-style-content01',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_responsive_control(
			'title_spacing',
			[
				'label' => esc_html__( 'Title Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('title_spacing', $defs) ? $defs[ 'title_spacing' ] : [ 
					'unit' => 'px',
					'size' => 10,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__meta' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: 0;',
					'{{WRAPPER}}.shadowcore-pri-swap--yes .shadowcore-pri__meta' => 'padding-bottom: {{SIZE}}{{UNIT}}; padding-top: 0;',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__title' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Title Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pri__title',
				'condition' => [
					'post_title' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-content02',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'meta_item_spacing',
			[
				'label' => esc_html__( 'Meta Items Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('meta_item_spacing', $defs) ? $defs[ 'meta_item_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
				 ] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__meta > div:before' => 'margin-left: calc(0.5 * {{SIZE}}{{UNIT}}); margin-right: calc(0.5 * {{SIZE}}{{UNIT}});',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Meta Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__meta' => 'color: {{VALUE}};',
					'{{WRAPPER}} .shadowcore-pri__meta a' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typo',
				'label' => esc_html__( 'Meta Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pri__meta',
				'condition' => [
					'post_meta' => 'yes',
				]
			]
		);
		$this->add_control(
			'divider-style-content03',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_responsive_control(
			'excerpt_spacing',
			[
				'label' => esc_html__( 'Excerpt Spacing', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('excerpt_spacing', $defs) ? $defs[ 'excerpt_spacing' ] : [ 
					'unit' => 'px',
					'size' => 20,
					] ),
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__excerpt' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_control(
			'excerpt_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'shadowcore' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shadowcore-pri__excerpt' => 'color: {{VALUE}};',
				],
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typo',
				'label' => esc_html__( 'Excerpt Typography', 'shadowcore' ),
				'selector' => '{{WRAPPER}} .shadowcore-pri__excerpt',
				'condition' => [
					'post_excerpt' => 'yes',
				]
			]
		);
		$this->end_controls_section();

		# Section: Hover Effects
		$this->start_controls_section(
			'section_style_hover',
			[
				'label' => esc_html__( 'Hover Effect', 'shadowcore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'fade_items',
			[
				'label' => esc_html__( 'Fade not Hover Items', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('fade_items', $defs) ? $defs[ 'fade_items' ] : 'no' ),
				'prefix_class' => 'shadowcore-pri-fade--',
			]
		);
		$this->add_control(
			'fade_items_opacity',
			[
				'label' => esc_html__( 'Item Opacity', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100
					],
				],
				'default' => ( array_key_exists('fade_items_opacity', $defs) ? $defs[ 'fade_items_opacity' ] : [ 
					'unit' => '%',
					'size' => 50,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-pri-fade--yes .shadowcore-posts-ribbon:hover .shadowcore-posts-ribbon--item:not(:hover)' => 'opacity: calc({{SIZE}} * 0.01);',
				],
				'condition' => [
					'fade_items' => 'yes'
				]
			]
		);
		$this->add_control(
			'opacity_anim_speed',
			[
				'label' => esc_html__( 'Transition Speed, ms', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 1500
					],
				],
				'default' => ( array_key_exists('opacity_anim_speed', $defs) ? $defs[ 'opacity_anim_speed' ] : [ 
					'unit' => '%',
					'size' => 500,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-pri-fade--yes .shadowcore-posts-ribbon--item' => 'transition-duration: {{SIZE}}ms;',
				],
				'condition' => [
					'fade_items' => 'yes'
				]
			]
		);
		$this->add_control(
			'divider-style-hover',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'items_scale',
			[
				'label' => esc_html__( 'Image Zoom on Hover', 'shadowcore' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'shadowcore' ),
				'label_off' => esc_html__( 'No', 'shadowcore' ),
				'return_value' => 'yes',
				'default' => ( array_key_exists('items_zoom', $defs) ? $defs[ 'items_zoom' ] : 'no' ),
				'prefix_class' => 'shadowcore-pri-scale--',
			]
		);
		$this->add_control(
			'items_scale_factor',
			[
				'label' => esc_html__( 'Item Opacity', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 150
					],
				],
				'default' => ( array_key_exists('items_scale_factor', $defs) ? $defs[ 'items_scale_factor' ] : [ 
					'unit' => '%',
					'size' => 105,
				 ] ),
				'selectors' => [
					'body:not(.shadowcore-touch) {{WRAPPER}}.shadowcore-pri-scale--yes .shadowcore-posts-ribbon--item:hover .shadowcore-ribbon-item--image' => 'background-size: {{SIZE}}%;',
				],
				'condition' => [
					'items_scale' => 'yes'
				]
			]
		);
		$this->add_control(
			'scale_anim_speed',
			[
				'label' => esc_html__( 'Transition Speed, ms', 'shadowcore' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'%' => [
						'min' => 100,
						'max' => 3000
					],
				],
				'default' => ( array_key_exists('scale_anim_speed', $defs) ? $defs[ 'scale_anim_speed' ] : [ 
					'unit' => '%',
					'size' => 1000,
				 ] ),
				'selectors' => [
					'{{WRAPPER}}.shadowcore-pri-scale--yes .shadowcore-ribbon-item--image' => 'transition-duration: {{SIZE}}ms;',
				],
				'condition' => [
					'items_scale' => 'yes'
				]
			]
		);
		
		$this->end_controls_section();
	}
	
	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_type = $settings[ 'post_type' ];
		$defs = shadowcore_get_widget_defaults( $this->get_name() );
		$hasTax = 'custom' !== $post_type ? get_object_taxonomies( $post_type ) : [];
		$taxonomies = $hasTax ? get_object_taxonomies( $post_type, 'objects' ) : [];

		if ( 'custom' !== $post_type ) {
			# Paged
			$paged = 1;

			# Query Args
			$args = array(
				'post_type' 	 => $post_type,
				'post_status' 	 => 'publish',
				'paged' 		 => absint( $paged ),
				'posts_per_page' => -1,
				'orderby' 		 => esc_attr( $settings[ 'orderby' ] ),
				'order' 		 => esc_attr( $settings[ 'order' ] ),
			);

			# Taxonomies
			if ( array_key_exists($post_type . '-tax-filter', $settings) && count( $hasTax ) > 0 && 'yes' == $settings[ $post_type . '-tax-filter' ] ) {
				if ( count( $taxonomies ) > 0 ) {
					$tax_query = array();
					foreach ( $taxonomies as $n => $o) {
						$terms = get_terms( $n );
						if ( count( $terms ) > 0 ) {
							$selected_terms = $settings[ $post_type . '-' . $n . '-tax' ];
							if ( is_array( $selected_terms ) && count( $selected_terms ) > 0 ) {
								$this_term = array(
									'taxonomy' => $n,
									'field'    => 'slug',
									'terms'    => $selected_terms
								);
								array_push( $tax_query, $this_term );
							}
						}
					}
					if ( count( $tax_query ) > 0 ) {
						$args['tax_query'] = $tax_query;
					}
				}
			}

			$display_tax_arr = Array();
			if ( count( $hasTax ) > 0 ) {
				foreach ( $taxonomies as $n => $o) {
					$terms = get_terms( $n );
					$props = get_object_vars( $o );
					if ( count( $terms ) > 0 ) {
						array_push( $display_tax_arr, $n );
					}
				}
			}
		} else {
			$options = false;
		}
		?>
		<div class="shadowcore-posts-ribbon-wrap shadowcore-ribbon-wrap <?php echo esc_attr( $settings[ 'vertical_mobile' ] ? 'vertical-mobile-wrap' : '' ); ?>">
			<?php
				if ( 'custom' !== $post_type ) {
				$options = Array(
					'lazy' => $settings[ 'lazy' ],
					'title' => ( $settings[ 'post_title' ] == 'yes' ? true : false),
					'meta' => ( $settings[ 'post_meta' ] == 'yes' ? true : false),
					'meta_values' => array(
						'date' => ( $settings[ 'post_meta__date' ] == 'yes' ? true : false),
						'author' => ( $settings[ 'post_meta__author' ] == 'yes' ? true : false),
						'comments' => ( $settings[ 'post_meta__comments' ] == 'yes' ? true : false),
					),
					'excerpt' => ( $settings[ 'post_excerpt' ] == 'yes' ? true : false),
				);
				if ( count( $display_tax_arr ) > 0 ) {
					foreach ( $display_tax_arr as $n ) {
						$options[ 'meta_custom_values' ][ $n ] = ( $settings[ 'post_meta__' . $n ] == 'yes' ? true : false);
					}
				}
			}
			?>
			<div class="shadowcore-posts-ribbon shadowcore-ribbon shadowcore-cursor--scrollH <?php echo esc_attr( $settings[ 'vertical_mobile' ] ? 'vertical-mobile-layout' : '' ); ?>" 
				data-id="<?php echo esc_attr( $this->get_id() ); ?>"
				data-dspeed="<?php echo esc_attr( $settings[ 'd-speed' ][ 'size' ] ); ?>" 
				data-tspeed="<?php echo esc_attr( $settings[ 't-speed' ][ 'size' ] ); ?>" 
				data-side-spacing="<?php echo esc_attr( $settings[ 'side_spacing' ] == 'yes' ? 'yes' : 'no'); ?>" 
				data-lazy="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? '1' : '0' ); ?>">
			<?php
			$i = 0;
			if ( 'custom' !== $post_type ) {
				# Query Ribbon
				$query = new WP_Query( $args );
				$posts_count = $query->found_posts;
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();
					
						if ( has_post_thumbnail() ) {
							$i_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
							if ( is_array( $i_meta ) ) {
								# has_image
								if ( array_key_exists( 'shadowcore-fhd', $i_meta[ 'sizes' ] ) ) {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-fhd' );
								} else {
									$i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
								}
								$i_width = $i_meta[ 'width' ];
								$i_height = $i_meta[ 'height' ];
							} else {
								# No Image Found
								$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
								$i_width = 800;
								$i_height = 1200;
							}
						} else {
							# No Image Specified
							$i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
							$i_width = 800;
							$i_height = 1200;
						}
						$image_ratio = round( $i_width / $i_height, 3 );
						$post_class = 'shadowcore-posts-ribbon--item shadowcore-ribbon-item' . esc_attr( $settings[ 'lazy' ] == 'yes' ? ' shadowcore-lazy-await' : '' );
						?>
						<div id="shadowcore-uqc-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( $post_class ); ?> data-ind="<?php echo esc_attr( $i ); ?>" data-ratio="<?php echo esc_attr( $image_ratio); ?>">
							<div class="shadowcore-ribbon-item--image <?php echo esc_attr( has_post_thumbnail() ? 'has-post-thmb' : 'no-post-thmb' ) . ' ' . esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $i_url ); ?>">
								<img 
									src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $i_width ); ?>%20<?php echo absint( $i_height ); ?>'%3E%3C/svg%3E"
									alt="<?php echo get_the_title(); ?>" 
									width="<?php echo esc_attr( $i_width ); ?>" 
									height="<?php echo esc_attr( $i_height ); ?>">
							</div><!-- .shadowcore-gallery-image -->
							<div class="shadowcore-ribbon-content">
								<div class="shadowcore-pri__content">
									<div class="shadowcore-pri__content_head">
									<?php
									if ( $options[ 'title' ] ) {
										echo '<div class="shadowcore-pri__title">'. get_the_title() .'</div>';
									}
									if ( $options[ 'meta' ] ) {
										echo '<div class="shadowcore-pri__meta">';
										if ( array_key_exists('meta_custom_values', $options) && is_array( $options[ 'meta_custom_values' ] ) ) {
											if ( $options[ 'meta_values' ][ 'date' ] ) {
												echo '<div class="shadowcore-pri__meta--date">'. get_the_date() .'</div>';
											}
											if ( $options[ 'meta_values' ][ 'author' ] ) {
												echo '<div class="shadowcore-pri__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
											}
											foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
												if ( $state ) {
													$term_list = get_the_terms( get_the_id(), $n );
													$term_string = '';
													if ( is_array( $term_list ) ) {
														foreach ( $term_list as $term ) {
															$term_string .= $term->name . ", ";
														}
														$term_string = substr( $term_string, 0, -2 );
														echo '<div class="shadowcore-pri__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
													}
												}
											}
											if ( $options[ 'meta_values' ][ 'comments' ] ) {
												$comment_count = get_comments_number();
												if ( 'product' == $post_type ) {
													if ( $comment_count === '1' ) {
														$comment_label = esc_html__( 'Review', 'shadowcore' );
													} else {
														$comment_label = esc_html__( 'Reviews', 'shadowcore' );
													}
												} else {
													if ( $comment_count === 1 ) {
														$comment_label = esc_html__( 'Comment', 'shadowcore' );
													} else {
														$comment_label = esc_html__( 'Comments', 'shadowcore' );
													}
												}
												echo '<div class="shadowcore-pri__meta--comments">'. esc_html( $comment_count ) .' '. $comment_label .'</div>';
											}
										}
										echo '</div><!-- .shadowcore-pri__meta -->';
									}
									?>
									</div><!-- .shadowcore-pri__content_head -->
									<?php 
									if ( $options[ 'excerpt' ] ) {
										echo '<div class="shadowcore-pri__excerpt">' . get_the_excerpt() . '</div>';
									}
									?>
								</div><!-- .shadowcore-pri__content -->
							</div><!-- .shadowcore-ribbon-content -->
							<a href="<?php the_permalink(); ?>" class="shadowcore-pri-link"></a>
						</div><!-- .shadowcore-posts-ribbon--item -->
						<?php
						$i++;
					}
				} else {
					echo '<p>' . esc_html__( 'Oops! Nothing to show here :(', 'shadowcore' ) . '</p>';
				}
			} else {
				# Custom Ribbon
				if ( count( $settings[ 'custom_items' ] ) ) {
					foreach ( $settings[ 'custom_items' ] as $item ) {
						$image = $item[ 'image' ];

						if ( ! empty ( $image[ 'id' ] ) ) {
							$i_meta = wp_get_attachment_metadata( $image[ 'id' ] );
							if ( array_key_exists( 'shadowcore-fhd', $i_meta[ 'sizes' ] ) ) {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'shadowcore-fhd' );
							} else {
								$i_url = wp_get_attachment_image_url( $image[ 'id' ], 'full' );
							}
							$i_width = $i_meta[ 'width' ];
							$i_height = $i_meta[ 'height' ];
						} else {
							$i_url = $image[ 'url' ];
							$i_width = 1200;
							$i_height = 800;
						}
						$link = $item[ 'link_url' ];

						$image_ratio = round( $i_width / $i_height, 3 );
						$post_class = 'shadowcore-posts-ribbon--item shadowcore-custom-ribbon--item shadowcore-ribbon-item' . esc_attr( $settings[ 'lazy' ] == 'yes' ? ' shadowcore-lazy-await' : '' );
						?>
						<div class="<?php echo esc_attr( $post_class ); ?>" data-ind="<?php echo esc_attr( $i ); ?>" data-ratio="<?php echo esc_attr( $image_ratio); ?>">
							<div class="shadowcore-ribbon-item--image <?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $i_url ); ?>">
								<img 
									src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $i_width ); ?>%20<?php echo absint( $i_height ); ?>'%3E%3C/svg%3E"
									alt="<?php echo get_the_title(); ?>" 
									width="<?php echo esc_attr( $i_width ); ?>" 
									height="<?php echo esc_attr( $i_height ); ?>">
							</div><!-- .shadowcore-gallery-image -->
							<div class="shadowcore-ribbon-content">
								<div class="shadowcore-pri__content">
									<div class="shadowcore-pri__content_head">
									<?php
									if ( ! empty( $item[ 'title' ] ) ) {
										echo '<div class="shadowcore-pri__title">'. esc_html( $item[ 'title' ] ) .'</div>';
									}
									if ( ! empty( $item[ 'caption' ] ) ) {
										echo '<div class="shadowcore-pri__meta"><div class="shadowcore-pri__meta--caption">'.  esc_html( $item[ 'caption' ] ) .'</div></div>';
									}
									?>
									</div><!-- .shadowcore-pri__content_head -->
								</div><!-- .shadowcore-pri__content -->
							</div><!-- .shadowcore-ribbon-content -->
							<?php
							if ( ! empty( $link[ 'url' ] ) ) {
								echo '<a href="' . esc_url( $link[ 'url' ] ) . '" ' . ( $link[ 'is_external' ] ? 'target="_blank"' : 'target="_self"' ) . ' ' . ( $link[ 'nofollow' ] ? 'rel="nofollow"' : '' ) . ' class="shadowcore-pri-link"></a>';
							}
							?>
						</div><!-- .shadowcore-posts-ribbon--item -->
						<?php
						$i++;
					}
				}
			}
			?>
			</div><!-- .shadowcore-posts-ribbon -->
		</div><!-- .shadowcore-posts-ribbon-wrap -->
		<?php
		if ( 'custom' !== $post_type ) {
			# Reset Query
			wp_reset_query();
		}
	}
}
Plugin::instance()->widgets_manager->register( new Shadow_Query_Ribbon_Widget() );