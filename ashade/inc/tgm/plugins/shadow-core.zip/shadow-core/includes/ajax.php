<?php
/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('wp_ajax_shadowcore_query_posts', 'shadowcore_query_posts');
add_action('wp_ajax_nopriv_shadowcore_query_posts', 'shadowcore_query_posts');

if ( ! function_exists( 'shadowcore_query_posts' ) ) {
	function shadowcore_query_posts() {
        check_ajax_referer( 'shadowcore_secure', 'security' );

        $prop = json_decode( stripslashes( html_entity_decode( $_POST[ 'query_prop' ] ) ), true );
        $offset = $_POST[ 'offset' ];
        $options = $prop[ 'options' ];
        $args = $prop[ 'args' ];
        $post_type = $args[ 'post_type' ];
        $tax_filter = $options['filter_tax'];
        $args[ 'offset' ] = $offset;
        $grid_type = $options['type'];
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();

                $post_class = 'shadowcore-posts-grid--item not-loaded';
                $post_filter = false;

                if ( $tax_filter ) {
                    $filter_term_list = get_the_terms( get_the_id(), $tax_filter );
                    foreach ( $filter_term_list as $term ) {
                        $post_class .= ' brickwall-filter--' . $term->slug; 
                    }
                }
                $i_meta = false;
                if ( has_post_thumbnail() ) {
                    $i_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
                    if ( is_array( $i_meta ) ) {
                        # has_image
                        if ( array_key_exists( 'shadowcore-hhd', $i_meta[ 'sizes' ] ) ) {
                            $i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-hhd' );
                        } else {
                            $i_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
                        }
                    } else {
                        # No Image Found
                        $i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
                    }
                } else {
                    # No Image Specified
                    $i_url = SHADOWCORE_ASSETS_URL . '/img/null.png';
                }
                
                # Detect Image size according to Grid Size
                if ( 'grid' == $grid_type ) {
                    # Grid
                    $i_width = $options['i_width'];
                    $i_height = $options['i_height'];
                } else {
                    # Masonry and Adjusted
                    if ( is_array( $i_meta ) ) {
                        $i_width = $i_meta[ 'width' ];
                        $i_height = $i_meta[ 'height' ];
                    } else {
                        # No Image Found
                        $i_width = 1200;
                        $i_height = 800;
                    }
                }
                ?><div id="shadowcore-uqgi-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( $post_class ); ?>>
                <div class="shadowcore-pgi--inner">
                    <?php 
                    if ( ! empty( $i_url ) ) {
                        ?>
                        <div class="shadowcore-pgi__image">
                            <div class="shadowcore-grid-image <?php echo esc_attr( is_array( $i_meta ) ? 'has-post-thmb' : 'no-post-thmb' ) . ' ' . esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $i_url ); ?>">
                                <img 
                                    src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $i_width ); ?>%20<?php echo absint( $i_height ); ?>'%3E%3C/svg%3E"
                                    alt="<?php echo get_the_title(); ?>" 
                                    width="<?php echo esc_attr( $i_width ); ?>" 
                                    height="<?php echo esc_attr( $i_height ); ?>">
                            </div><!-- .shadowcore-gallery-image -->
                        </div><!-- .shadowcore-pgi__image -->
                        <?php
                    }
                    ?>
                    <div class="shadowcore-pgi__content">
                        <div class="shadowcore-pgi__content-inner">
                            <div class="shadowcore-pgi__content_head">
                            <?php
                            if ( $options[ 'title' ] ) {
                                echo '<div class="shadowcore-pgi__title">'. get_the_title() .'</div>';
                            }
                            if ( $options[ 'meta' ] ) {
                                echo '<div class="shadowcore-pgi__meta">';
                                if ( array_key_exists('meta_custom_values', $options) && is_array( $options[ 'meta_custom_values' ] ) ) {
                                    if ( $options[ 'meta_values' ][ 'date' ] ) {
                                        echo '<div class="shadowcore-pgi__meta--date">'. get_the_date() .'</div>';
                                    }
                                    if ( $options[ 'meta_values' ][ 'author' ] ) {
                                        echo '<div class="shadowcore-pgi__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
                                    }
                                    foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
                                        if ( $state ) {
                                            $term_list = get_the_terms( get_the_id(), $n );
                                            $term_string = '';
                                            if ( is_array( $term_list ) ) {
                                                foreach ( $term_list as $term ) {
                                                    $term_string .= $term->name . ", ";
                                                }
                                                $term_string = substr( $term_string, 0, -2 );
                                                echo '<div class="shadowcore-pgi__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
                                            }
                                        }
                                    }
                                    if ( $options[ 'meta_values' ][ 'comments' ] ) {
                                        echo '<div class="shadowcore-pgi__meta--comments">'. get_comments_number() .' '. esc_html__( 'Comments', 'shadowcore' ) .'</div>';
                                    }
                                }
                                echo '</div><!-- .shadowcore-pgi__meta -->';
                            }
                            ?>
                            </div><!-- .shadowcore-pgi__content_head -->
                        </div><!-- .shadowcore-pgi__content-inner -->
                        <?php 
                        if ( $options[ 'excerpt' ] ) {
                            echo '<div class="shadowcore-pgi__excerpt">' . get_the_excerpt() . '</div>';
                        }
                        ?>
                    </div><!-- .shadowcore-pgi__content -->
                    <a href="<?php the_permalink(); ?>" class="shadowcore-pgi-link"></a>
                </div><!-- .shadowcore-pgi--inner -->
            </div><!-- .shadowcore-posts-grid--item --><?php
            }
        }
        wp_reset_query();
        # Exit
		die();
	}
}

add_action('wp_ajax_shadowcore_query_posts_list', 'shadowcore_query_posts_list');
add_action('wp_ajax_nopriv_shadowcore_query_posts_list', 'shadowcore_query_posts_list');

if ( ! function_exists( 'shadowcore_query_posts_list' ) ) {
	function shadowcore_query_posts_list() {
        check_ajax_referer( 'shadowcore_secure', 'security' );
        
        $prop = json_decode( stripslashes( html_entity_decode( $_POST[ 'query_prop' ] ) ), true );
        $offset = $_POST[ 'offset' ];
        $options = $prop[ 'options' ];
        $args = $prop[ 'args' ];
        $post_type = $args[ 'post_type' ];
        $args[ 'offset' ] = $offset;
        $query = new WP_Query( $args );

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_class = 'shadowcore-posts-list--item not-loaded';
                if ( has_post_thumbnail() ) {
                    $post_class .= ' has-post-thumbnail';
                } else {
                    $post_class .= ' no-post-thumbnail';
                }
                ?>
                <div id="shadowcore-uqli-<?php echo esc_attr( get_the_ID() ); ?>" <?php post_class( $post_class ); ?>>
                    <div class="shadowcore-pli--inner">
                    <?php 
                        if ( has_post_thumbnail() && 'small' !== $listing_type ) {
                            # Get Featured Image
                            $thmb_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
                            $thmb_width = $thmb_meta[ 'width' ];
                            $thmb_height = $thmb_meta[ 'height' ];
                            $orient = ( $thmb_width > $thmb_height ? 'land' : 'port' );
                            if ( 'port' == $orient ) {
                                if ( array_key_exists( 'shadowcore-hhd', $thmb_meta[ 'sizes' ] ) ) {
                                    $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-hhd' );
                                    $thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-hhd' ][ 'width' ];
                                    $thmb_height = $thmb_meta[ 'sizes'] [ 'shadowcore-hhd' ][ 'height' ];
                                } else {
                                    if ( 'medium' == $listing_type ) {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
                                    } else {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
                                    }
                                }
                            } else {
                                if ( 'medium' == $listing_type ) {
                                    if ( array_key_exists( 'large', $thmb_meta[ 'sizes' ] ) ) {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
                                        $thmb_width  = $thmb_meta[ 'sizes' ][ 'large' ][ 'width' ];
                                        $thmb_height = $thmb_meta[ 'sizes' ][ 'large' ][ 'height' ];
                                    } else {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
                                    }
                                } else {
                                    if ( array_key_exists( 'shadowcore-fhd', $thmb_meta['sizes'] ) ) {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-fhd' );
                                        $thmb_width  = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'width' ];
                                        $thmb_height = $thmb_meta[ 'sizes' ][ 'shadowcore-fhd' ][ 'height' ];
                                    } else {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'full' );
                                    }
                                }
                            }
                            ?>
                            <div class="shadowcore-pli-image shadowcore-pli-image--<?php echo esc_attr( $orient ); ?>">
                                <div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
                                    <a href="<?php echo esc_url( get_permalink() ); ?>">
                                        <img
                                            src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
                                            width=<?php echo absint( $thmb_width ); ?> 
                                            height=<?php echo absint( $thmb_height ); ?> 
                                            alt="<?php the_title(); ?>">
                                    </a>
                                </div><!-- .shadowcore-div-image -->
                            </div><!-- .shadowcore-pli-image -->
                            <?php
                        }
                        # Content Part
                        ?>
                        <div class="shadowcore-pli-content">
                            <div class="shadowcore-pli-head">
                                <?php
                                if ( has_post_thumbnail() && 'small' == $listing_type ) {
                                    # Get Featured Image Thumbnail
                                    $thmb_meta = wp_get_attachment_metadata( get_post_thumbnail_id() );
                                    if ( array_key_exists( 'shadowcore-retina-thumb', $thmb_meta['sizes'] ) ) {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'shadowcore-retina-thumb' );
                                    } else {
                                        $thmb_url = wp_get_attachment_image_url( get_post_thumbnail_id(), 'thumbnail' );
                                    }
                                    $thmb_width = $thmb_height = $thmb_size;
                                    ?>
                                    <div class="shadowcore-pli-image">
                                        <div class="<?php echo esc_attr( $settings[ 'lazy' ] == 'yes' ? 'shadowcore-lazy' : 'shadowcore-div-image' ); ?>" data-src="<?php echo esc_url( $thmb_url ); ?>">
                                            <a href="<?php echo esc_url( get_permalink() ); ?>">
                                                <img
                                                    src="data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20<?php echo absint( $thmb_width ); ?>%20<?php echo absint( $thmb_height ); ?>'%3E%3C/svg%3E" 
                                                    width=<?php echo absint( $thmb_width ); ?> 
                                                    height=<?php echo absint( $thmb_height ); ?> 
                                                    alt="<?php the_title(); ?>">
                                            </a>
                                        </div><!-- .shadowcore-div-image -->
                                    </div><!-- .shadowcore-pli-image -->
                                    <?php
                                }
                                ?>
                                <div class="shadowcore-pli-title">
                                    <?php if ( $options[ 'title' ] ) { ?>
                                    <h4><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                    <?php } ?>
                                    <?php
                                    if ( $options[ 'meta' ] ) {
                                        echo '<div class="shadowcore-pli-meta shadowcore-pli-meta--top">';
                                            if ( 'top' == $options[ 'meta_values' ][ 'date' ] ) {
                                                echo '<div class="shadowcore-pli__meta--date">'. get_the_date() .'</div>';
                                            }
                                            if ( 'top' == $options[ 'meta_values' ][ 'author' ] ) {
                                                echo '<div class="shadowcore-pli__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
                                            }
                                            foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
                                                if ( 'top' == $state ) {
                                                    $term_list = get_the_terms( get_the_id(), $n );
                                                    $term_string = '';
                                                    if ( is_array( $term_list ) ) {
                                                        foreach ( $term_list as $term ) {
                                                            $term_string .= $term->name . ", ";
                                                        }
                                                        $term_string = substr( $term_string, 0, -2 );
                                                        echo '<div class="shadowcore-pli__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
                                                    }
                                                }
                                            }
                                            if ( 'top' == $options[ 'meta_values' ][ 'comments' ] ) {
                                                echo '<div class="shadowcore-pli__meta--comments">'. get_comments_number() .' '. esc_html__( 'Comments', 'shadowcore' ) .'</div>';
                                            }
                                        echo '</div><!-- .shadowcore-pli-meta--top -->';
                                    }
                                    ?>
                                </div><!-- .shadowcore-pli-title -->
                            </div><!-- .shadowcore-pli-head -->
                            <?php
                            if ( $options[ 'excerpt' ] ) {
                                $excerpt = get_the_excerpt();
                                if ( ! empty( $excerpt ) && $excerpt !== '&nbsp;' ) {
                                    echo '<div class="shadowcore-pli-excerpt">'. wp_specialchars_decode( $excerpt ) .'</div>';
                                }
                            }
                            ?>
                            <div class="shadowcore-pli-footer">
                                <?php
                                if ( $options[ 'meta' ] ) {
                                    echo '<div class="shadowcore-pli-footer-lp shadowcore-pli-meta shadowcore-pli-meta--bottom">';
                                        if ( 'bottom' == $options[ 'meta_values' ][ 'date' ] ) {
                                            echo '<div class="shadowcore-pli__meta--date">'. get_the_date() .'</div>';
                                        }
                                        if ( 'bottom' == $options[ 'meta_values' ][ 'author' ] ) {
                                            echo '<div class="shadowcore-pli__meta--author">'. get_the_author_meta( 'display_name' ) .'</div>';
                                        }
                                        foreach( $options[ 'meta_custom_values' ] as $n => $state ) {
                                            if ( 'bottom' == $state ) {
                                                $term_list = get_the_terms( get_the_id(), $n );
                                                $term_string = '';
                                                if ( is_array( $term_list ) ) {
                                                    foreach ( $term_list as $term ) {
                                                        $term_string .= $term->name . ", ";
                                                    }
                                                    $term_string = substr( $term_string, 0, -2 );
                                                    echo '<div class="shadowcore-pli__meta--'. esc_attr( $n ) .'">'. esc_html( $term_string ) .'</div>'; 
                                                }
                                            }
                                        }
                                        if ( 'bottom' == $options[ 'meta_values' ][ 'comments' ] ) {
                                            echo '<div class="shadowcore-pli__meta--comments">'. get_comments_number() .' '. esc_html__( 'Comments', 'shadowcore' ) .'</div>';
                                        }
                                    echo '</div><!-- .shadowcore-pli-footer-lp -->';
                                }
                                echo '
                                    <div class="shadowcore-pli-footer-rp shadowcore-pli-read-more">
                                        <a class="shadowcore-pli--more" href="'. esc_url( get_permalink() ) .'"><span>'. esc_html( $options ['read_more_label' ] ) .'</span></a>
                                    </div>';
                                ?>
                            </div><!-- .shadowcore-pli--footer -->
                        </div><!-- .shadowcore-pli-content -->
                    </div><!-- .shadowcore-pli--inner -->
                </div><!-- .shadowcore-posts-list--item -->
                <?php
            }
        }
        wp_reset_query();
        # Exit
		die();
	}
}