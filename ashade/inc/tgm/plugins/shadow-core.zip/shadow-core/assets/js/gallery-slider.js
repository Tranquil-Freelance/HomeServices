/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
"use strict";

/* Class: Slide Gallery */
class ShadowCore_SlideGallery {
    constructor( $el ) {
        if ($el instanceof jQuery) {
            let this_class = this;
            $el.addClass('is-animating');
            let duration = $el.children().css('transition-duration');
            $el.removeClass('is-animating');
            // Set Variables
            this.$el = $el;
            this.inUse = false;
            this.isTouched = false;
            this.isDragged = false;
            this.isSingle = this.$el.hasClass('is-single') ? true : false;
            this.type = $el.data('type');
            this.navType = this.$el.parent().data('nav');
            this.itemsCount = $el.children('div').length;
			if ( this.itemsCount < 4) {
				// Double Posts if < 4
				$el.append($el.html());
				this.itemsCount = $el.children('div').length;
				$el.children('div').each(function() {
					jQuery(this).attr('data-ind', jQuery(this).index());
				});
			}
            this.maxCount = this.itemsCount - 1;
            this.index = {
                prev   : this.itemsCount > 1 ? (this.itemsCount - 1) : 0,
                active : 0,
                next   : this.itemsCount > 1 ? 1 : 0,
            }
            this.move = {
                iX : -1,
                dir : false,
                dot: false,
            }
            this.player = {
                vimeo: Array(),
                youtube: Array(),
            }
            this.isBusy = false;
            this.scaleFactor = this.$el.data('zoom') * 0.01;
            
			this.linkDown = false;
			this.linkMove = false;
			
            if ( duration.indexOf('ms') > 0 ) {
                this.speed = parseInt(duration, 10);
            } else if ( duration.indexOf('s') > 0 ) {
                this.speed = parseInt(duration, 10) * 1000;
            } else {
                this.speed = 1000;
            }
            
            //Init Slider
            this.$el.find('[data-src]').each(function() {
                jQuery(this).css( 'background-image', 'url('+ jQuery(this).data('src') +')' );
            });
            
            if ( this.isSingle ) {
                this.$el.children().css('opacity', '1');
                this.$el.children().children('.shadowcore-slider-item--image').css('transform', 'scale(1)');
            } else {
                this.change();
            }
            
            // Slider Events
            this.$el.on('mousedown', function(e) {
				if ( jQuery(e.target).is('a.shadowcore-slider-link') ) {
					this_class.linkDown = true;
				}
                if ( ! this_class.isBusy ) {
                    this_class.isTouched = true;
                    this_class.$el.addClass('is-grabbed');
                    this_class.move.iX = e.clientX;
                }
            }).on('mouseup', function() {
				this_class.linkDown = false;
                this_class.$el.removeClass('is-grabbed');
                this_class.move.iX = -1;
                if ( this_class.isDragged ) {
                    if ( this_class.move.dir == 'prev' ) {
                        if ( this_class.isTouched ) {
                            this_class.$el.addClass('is-dropped');
                            this_class.isTouched = false;
                        }
                        this_class.prev();
                    } else if ( this_class.move.dir == 'next' ) {
                        if ( this_class.isTouched ) {
                            this_class.$el.addClass('is-dropped');
                            this_class.isTouched = false;
                        }
                        this_class.next();
                    } else {
                        this_class.change();
                    }
                }
                this_class.$el.removeClass('is-moving');
            }).on('mouseleave', function(){
				this_class.linkDown = false;
                this_class.isTouched = false;
                this_class.$el.removeClass('is-grabbed');
                this_class.move.iX = -1;
                if ( this_class.isDragged ) {
                    if ( this_class.move.dir == 'prev' ) {
                        this_class.prev();
                    } else if ( this_class.move.dir == 'next' ) {
                        this_class.next();
                    } else {
                        this_class.change();
                    }
                }
                this_class.$el.removeClass('is-moving');
            });
            
            // Mouse Drag
            this.$el.on('mousemove', function(e) {
                if ( ! this_class.isBusy && this_class.isTouched && this_class.move.iX > -1 ) {
                    let cX = e.clientX,
                        dX = this_class.move.iX - cX,
                        adX = Math.abs(dX),
                        dF = dX > 0 ? -1 : 1;
                    
                    if (adX > 0) {
                        this_class.isDragged = true;
                        let percent = parseFloat( adX / this_class.$el.width()*0.75 ).toFixed(2),
                            sA = 1 + (percent * (this_class.scaleFactor - 1) ),
                            sPN = this_class.scaleFactor - ( percent * ( this_class.scaleFactor - 1 ) );
                        
                        if (cX < this_class.move.iX) {
                            // Move to Next
                            if (adX > 50) {
                                this_class.move.dir = 'next';
                            }
                            // DIR POS - CX POS
                            this_class.moveDrag( this_class.index.next, sPN, percent, dF, 1 );
                        }
                        
                        if (cX > this_class.move.iX) {
                            // Move to Prev
                            if (adX > 50) {
                                this_class.move.dir = 'prev';
                            }
                            this_class.moveDrag( this_class.index.prev, sPN, percent, dF, -1 );
                        }
                        this_class.moveDrag( this_class.index.active, sA, percent, dF, 0 );
                    }
                }
				if (this_class.linkDown) {
                    this_class.$el.addClass('is-moving');
					this_class.linkMove = true;
				} else {
					this_class.linkMove = false;
				}
            });
            
            // Touch Drag
            this.$el[0].addEventListener('touchstart', function(e) {
				if ( jQuery(e.target).is('a.shadowcore-slider-link') ) {
					this_class.linkDown = true;
				}
				if ( ! this_class.isBusy ) {
                    this_class.isTouched = true;
                    this_class.$el.addClass('is-grabbed');
                    this_class.move.iX = e.touches[0].clientX;
                }
			}, false);
			this.$el[0].addEventListener('touchmove', function(e) {
                if ( ! this_class.isBusy && this_class.isTouched && this_class.move.iX > -1 ) {
                    let axis = shadowcore_el.panAxis.getAxis();
                    if ( 'x' == axis ) {
                        e.preventDefault();
                        let cX = e.touches[0].clientX,
                            dX = this_class.move.iX - cX,
                            adX = Math.abs(dX),
                            dF = dX > 0 ? -1 : 1;

                        if (adX > 0) {
                            this_class.isDragged = true;
                            let percent = parseFloat( adX / this_class.$el.width()*0.75 ).toFixed(2),
                                sA = 1 + (percent * (this_class.scaleFactor - 1) ),
                                sPN = this_class.scaleFactor - ( percent * ( this_class.scaleFactor - 1 ) );

                            if (cX < this_class.move.iX) {
                                // Move to Next
                                if (adX > 50) {
                                    this_class.move.dir = 'next';
                                }
                                // DIR POS - CX POS
                                this_class.moveDrag( this_class.index.next, sPN, percent, dF, 1 );
                            }

                            if (cX > this_class.move.iX) {
                                // Move to Prev
                                if (adX > 50) {
                                    this_class.move.dir = 'prev';
                                }
                                this_class.moveDrag( this_class.index.prev, sPN, percent, dF, -1 );
                            }
                            this_class.moveDrag( this_class.index.active, sA, percent, dF, 0 );
							
							if (this_class.linkDown) {
								this_class.linkMove = true;
							} else {
								this_class.linkMove = false;
							}
                        }
                    }
                }
			}, false);
			this.$el[0].addEventListener('touchend', function(e) {
                this_class.$el.removeClass('is-grabbed');
                this_class.move.iX = -1;
				this_class.linkDown = false;
                if ( this_class.isDragged ) {
                    if ( this_class.move.dir == 'prev' ) {
                        if ( this_class.isTouched ) {
                            this_class.$el.addClass('is-dropped');
                            this_class.isTouched = false;
                        }
                        this_class.prev();
                    } else if ( this_class.move.dir == 'next' ) {
                        if ( this_class.isTouched ) {
                            this_class.$el.addClass('is-dropped');
                            this_class.isTouched = false;
                        }
                        this_class.next();
                    } else {
                        this_class.change();
                    }
                }
			}, false);
            
            // Navigation Events
            this.$el.parent().on('click', '.shadowcore-slider-prev', function(e) {
                e.preventDefault();
                if ( ! this_class.isBusy ) {
                    this_class.prev();
                }
            });
            this.$el.parent().on('click', '.shadowcore-slider-next', function(e) {
                e.preventDefault();
                if ( ! this_class.isBusy ) {
                    this_class.next();
                }
            });
            this.$el.parent().on('click', '.shadowcore-slider-dot:not(.is-active)', function(e) {
                e.preventDefault();
                if ( ! this_class.isBusy ) {
                    let iO = this_class.index.active,
                        iN = jQuery(this).data('index');
                    
                    jQuery(this).parent().children('.is-active').removeClass('is-active');
                    jQuery(this).addClass('is-active');
                    
                    this_class.index.active = iN;
                    
                    if ( 'fade' == this_class.type ) {
                        this_class.pnIndex();
                    } else {
                        if (iN == this_class.index.prev || iN == this_class.index.next) {
                            this_class.pnIndex();
                        } else {
                            this_class.move.dot = true;
                            // New Slide Preparing
                            if ( iN > iO ) {
                                // Place Forward
                                this_class.moveSlide(iN, 1);
                            } else {
                                // Place Backward
                                this_class.moveSlide(iN, -1);
                            }
                            
                            // Start Animation
                            this_class.$el.addClass('is-animating');
                            this_class.isBusy = true;
                            
                            // Move Slides
                            
                            let dir = 0;
                            if ( iN < iO ) {
                                dir = 1;
                            } else {
                                dir = -1;
                            }
                            setTimeout(function() {
                                // Move Current
                                this_class.moveSlide(iO, dir);

                                // Move New
                                this_class.moveSlide(iN, 0);
                                
                                // Recalculate Indexes
                                setTimeout(function() {
                                    this_class.$el.removeClass('is-animating');
                                    this_class.pnIndex();
                                }, this_class.speed + 100, this_class);
                            }, 50, this_class);
                        }
                    }                    
                }
            });
			
			/* Prevent links opening after scroll */
			this.$el.on('click', 'a.shadowcore-slider-link', function(e) {
				if (this_class.linkMove) {
					e.preventDefault();
					return false;
				}
				this_class.linkMove = false;
				this_class.linkDown = false;
			});
        } else {
            console.warn('Cannot init Slide Gallery. Element is not an instance of jQuery.');
        }
    }
    moveDrag( ind, sF, percent, dF, dir ) {
        let cX = 0,
            cXP = 0;
            //op = 1 - percent;
        
        if ( dir !== 0 ) {
            cX = 100 * dir;
            cXP = -50 * dir;
        }
        
        if ( 'fade' == this.type ) {
            let op = (dir == 0 ? (1 - percent) : percent);
            this.$el.children('[data-ind="'+ ind +'"]').css('opacity', op);
            this.$el.children('[data-ind="'+ ind +'"]').children('.shadowcore-slider-item--image').css('transform', 'scale('+ sF +')');
        } else {
			if ( ind == this.index.active ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-active');
			}
			if ( ind == this.index.prev ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-prev');
			}
			if ( ind == this.index.next ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-next');
			}
            this.$el.children('[data-ind="'+ ind +'"]').css({
                'z-index' : '3',
                'transform' : 'translateX(' + ((dF * percent * 100) + cX) + '%)'
            });
            if ( 'parallax' == this.type ) {
                this.$el.children('[data-ind="'+ ind +'"]').children('.shadowcore-slider-item--image').css('transform', 'translateX(' + (cXP - (dF * percent * 50) ) + '%) scale('+ sF +')');
            }
        }
    }
    moveSlide( ind, dir ) {
        let cX = 0,
            cXP = 0,
            sF = (dir == 0 ? 1 : this.scaleFactor);
        
        if ( dir !== 0 ) {
            cX = 100 * dir;
            cXP = -50 * dir;
        }
        if ( 'fade' == this.type ) {
            let op = (dir == 0 ? 1 : 0);
            this.$el.children('[data-ind="'+ ind +'"]').css( 'opacity', op );
            this.$el.children('[data-ind="'+ ind +'"]').children('.shadowcore-slider-item--image').css('transform', 'scale('+ sF +')');
        } else {
			if ( ind == this.index.active ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-active');
			}
			if ( ind == this.index.prev ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-prev');
			}
			if ( ind == this.index.next ) {
				this.$el.children('[data-ind="'+ ind +'"]').addClass('is-next');
			}
            this.$el.children('[data-ind="'+ ind +'"]').css({
                'z-index' : ( ind == this.index.active ? '5' : '3' ),
                'transform' : 'translateX('+ cX +'%)'
            });
            if ( 'parallax' == this.type ) {
                this.$el.children('[data-ind="'+ ind +'"]').children('.shadowcore-slider-item--image').css('transform', 'translateX('+ cXP +'%) scale('+ sF +')');
            } else {
                this.$el.children('[data-ind="'+ ind +'"]').children('.shadowcore-slider-item--image').css('transform', 'scale('+ sF +')');
            }
        }
    }
    pnIndex () {
        this.index.prev = this.index.active - 1;
        this.index.next = this.index.active + 1;
        if ( this.index.prev < 0 ) {
            this.index.prev = this.maxCount;
        }
        if ( this.index.prev > this.maxCount ) {
            this.index.prev = 0;
        }
        if ( this.index.next < 0 ) {
            this.index.next = this.maxCount;
        }
        if ( this.index.next > this.maxCount ) {
            this.index.next = 0;
        }
        this.change();
    }
    
    prev () {
        this.index.active = this.index.active - 1;
        if ( this.index.active < 0 ) {
            this.index.active = this.maxCount;
        }
        this.pnIndex();
    }
    
    next () {
        this.index.active = this.index.active + 1;
        if ( this.index.active > this.maxCount ) {
            this.index.active = 0;
        }
        this.pnIndex();
    }
    change () {
        let this_class = this,
            iP = this.index.prev,
            iA = this.index.active,
            iN = this.index.next;
        
        if ( !this.move.dot ) {
            this.$el.addClass('is-animating');
            this.isBusy = true;
        }
        
        // Set Active Dot
        if ( 'dots' == this.navType ) {
            this.$el.parent().children('.shadowcore-slider-nav').find('.is-active').removeClass('is-active');
            this.$el.parent().children('.shadowcore-slider-nav').find('.shadowcore-slider-dot[data-ind="'+ iA +'"]').addClass('is-active');
        }
        
        // Reset not active slides
        if ( 'fade' == this.type ) {
            this.$el.children().css('opacity', '0');
            this.$el.children().children('.shadowcore-slider-item--image').css('transform', 'scale('+ this_class.scaleFactor +')');            
        } else {
            this.$el.children().removeClass('is-prev');
            this.$el.children().removeClass('is-active');
            this.$el.children().removeClass('is-next');
        }
        
        // Set Active Slides
        this.moveSlide(iP, -1);
        this.moveSlide(iA, 0);
        this.moveSlide(iN, 1);
        
        // Reset Options
        this.isDragged = false;
        this.move.dir = 0;
        
        if ( this.move.dot ) {
            this_class.isBusy = false;
            this.move.dot = false;
        } else {
            setTimeout(function() {
                this_class.$el.removeClass('is-animating').removeClass('is-dropped');
                this_class.isBusy = false;
            }, this_class.speed + 100, this_class);
        }
    }
    
    layout() {
        let this_class = this,
            duration = this.$el.children().css('transition-duration');
        
        if ( duration.indexOf('ms') > 0 ) {
            this.speed = parseInt(duration, 10);
        } else if ( duration.indexOf('s') > 0 ) {
            this.speed = parseInt(duration, 10) * 1000;
        } else {
            this.speed = 1000;
        }
        this.scaleFactor = this.$el.data('zoom') * 0.01;
        this.change();
    }
    init_YT() {
        let this_class = this;
    }
    init_Vimeo() {
        let this_class = this;
    }    
}