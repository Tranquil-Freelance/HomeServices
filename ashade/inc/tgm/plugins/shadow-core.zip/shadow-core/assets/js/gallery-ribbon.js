/** 
 * Author: Shadow Themes
 * Author URL: http://shadow-themes.com
 */
"use strict";

/* Class: Slide Gallery */
class ShadowCore_RibbonGallery {
    constructor( $el ) {
        if ($el instanceof jQuery) {
            let this_class = this;
            
			// Set Variables
			this.$el = $el;
			this.id = $el.attr('data-id');
			this.isAnimated = false;
			this.animEvent = false;
            this.isTouched = false;
            this.isDragged = false;
			this.isHover = false;
			this.itemsCount = $el.children('div').length;
            this.maxCount = this.itemsCount - 1;
			this.maxStep = $el.width();
			this.options = {
				inertiaF: 0.1,
				dSpeed: parseInt( $el.attr('data-dspeed'), 10 ) * 0.01,
				tSpeedTouch: parseInt( $el.attr('data-tspeed'), 10 ) * 0.01,
				mozDelta: 33,
				lazy: $el.attr('data-lazy'),
				spacing: parseInt($el.children('[data-ind="0"]').css('margin-left'), 10)
			}
			this.move = {
				tX: 0,
				cX: 0,
				iX: -1,
				oX: 0,
			}
			this.linkDown = false;
			this.linkMove = false;
			this.vMobile = this.$el.hasClass('vertical-mobile-layout') ? true : false;
			
			// Load Images, if lazt disabled
			if ( ! this.options.lazy ) {
				this.$el.children('div').each(function() {
					let $this = jQuery(this).children('.shadowcore-ribbon-item--image');
					$this.css('background-image', 'url('+ $this.attr('data-src') +')');
				});
			}
			
			// Layout Gallery
			this.layout();
			
			// Events
			jQuery(window).on('load', function() {
				this_class.layout();
			}).on('resize', function() {
				this_class.layout();
			});
            this.$el.on('mousedown', function(e) {
				if ( jQuery(e.target).is('a') ) {
					this_class.linkDown = true;
				}
				this_class.i8d = true;
				this_class.isTouched = true;
				this_class.$el.addClass('is-grabbed');
				this_class.move.iX = e.clientX;
            }).on('mouseup', function() {
				this_class.linkDown = false;
				this_class.isTouched = false;
                this_class.$el.removeClass('is-grabbed').removeClass('is-moving');
                this_class.move.iX = -1;
            }).on('mouseleave', function(){
				this_class.linkDown = false;
                this_class.isTouched = false;
                this_class.$el.removeClass('is-grabbed').removeClass('is-moving');;
                this_class.move.iX = -1;
            });
            
            // Mouse Drag
            this.$el.on('mousemove', function(e) {
                if ( this_class.isTouched && this_class.move.iX > -1 ) {
					if ( ! this_class.$el.hasClass('is-moving') ) {
						this_class.$el.addClass('is-moving');
					}
                    let cX = e.clientX,
                        dX = this_class.move.iX - cX;
                    
                    if (dX > 0) {
						// moving forward
                    }
					if (dX < 0) {
						// moving backward
                    }
					
					this_class.move.iX = cX;
					this_class.move.tX = this_class.move.tX - ( dX * this_class.options.dSpeed );
					if (this_class.move.tX < this_class.maxStep) {
						this_class.move.tX = this_class.maxStep;
					}
					if (this_class.move.tX > 0) {
						this_class.move.tX = 0;
					}
					if ( ! this_class.isAnimated && (Math.floor(this_class.move.cX) !== Math.floor(this_class.move.tX)) ) {
						this_class.animate();
					}
                }
				if (this_class.linkDown) {
					this_class.linkMove = true;
				} else {
					this_class.linkMove = false;
				}
            });
            
            // Touch Drag
            this.$el[0].addEventListener('touchstart', function(e) {
				if ( ! this.vMobile || window.innerWidth > 767 ) {
					this_class.i8d = true;
					this_class.isTouched = true;
					this_class.$el.addClass('is-grabbed');
					this_class.move.iX = e.touches[0].clientX;
					if ( jQuery(e.target).is('a') ) {
						this_class.linkDown = true;
					}
				}
			}, false);
			this.$el[0].addEventListener('touchmove', function(e) {
				if ( ! this.vMobile || window.innerWidth > 767 ) {
					if ( this_class.isTouched && this_class.move.iX > -1 ) {
						let axis = shadowcore_el.panAxis.getAxis();
						if ( 'x' == axis ) {
							if ( ! this_class.$el.hasClass('is-moving') ) {
								this_class.$el.addClass('is-moving');
							}
							e.preventDefault();
							let cX = e.touches[0].clientX,
								dX = this_class.move.iX - cX;
							
							this_class.move.iX = cX;
							this_class.move.tX = this_class.move.tX - ( dX * this_class.options.dSpeed );
							if (this_class.move.tX < this_class.maxStep) {
								this_class.move.tX = this_class.maxStep;
							}
							if (this_class.move.tX > 0) {
								this_class.move.tX = 0;
							}
							if ( ! this_class.isAnimated && (Math.floor(this_class.move.cX) !== Math.floor(this_class.move.tX)) ) {
								this_class.animate();
							}
							if (this_class.linkDown) {
								this_class.linkMove = true;
							} else {
								this_class.linkMove = false;
							}
						}
					}
				}
			}, false);
			this.$el[0].addEventListener('touchend', function(e) {
				if ( ! this.vMobile || window.innerWidth > 767 ) {
					this_class.isTouched = false;
					this_class.linkDown = false;
					this_class.$el.removeClass('is-grabbed').removeClass('is-moving');
					this_class.move.iX = -1;
				}
			}, false);
			
			/* Prevent links opening after scroll */
			this.$el.on('click', 'a', function(e) {
				if (this_class.linkMove) {
					e.preventDefault();
					return false;
				}
				this_class.linkMove = false;
				this_class.linkDown = false;
			});
        } else {
            console.warn('Cannot init Slide Gallery. Element is not an instance of jQuery.');
        }
		
		// Start Animation Rendering
		if ( ! this.vMobile || window.innerWidth > 767 ) {
			this.animate();
		}
    }
	animate() {
		let path = this.move.tX - this.move.cX,
			old = this.move.cX;
		
		if ( Math.abs( path ) < 0.1) {
			this.move.cX += 0;
		} else {
			this.move.cX += (path * this.options.inertiaF);
		}
		
		if ( this.move.cX !== old ) {
			this.isAnimated = true;
			this.$el.css('transform', 'translate3d(' + this.move.cX + 'px, 0, 0)');
			this.animEvent = requestAnimationFrame( () =>  this.animate() );
		} else {
			this.isAnimated = false;
			cancelAnimationFrame( this.animEvent );
		}
	}
    layout() {
        let this_class = this;
		if ( ! this.vMobile || window.innerWidth > 767 ) {
			let	iH = this.$el.height(),
				sW = 0;
			
			this.$el.children('div').each(function() {
				let $this = jQuery(this),
					ratio = $this.attr('data-ratio'),
					nW = iH * ratio,
					imgH = iH;
				
				if ( this_class.$el.parents('.elementor-widget').hasClass('shadowcore-pri-content--below') || this_class.$el.parents('.elementor-widget').hasClass('shadowcore-pri-content--above') ) {
					if ( jQuery(this).children('.shadowcore-ribbon-content').length ) {
						imgH = iH - jQuery(this).children('.shadowcore-ribbon-content').height();
						nW = imgH * ratio;
						$this.children('.shadowcore-ribbon-item--image').height(imgH).width(nW);
					}
				} else {
					$this.children('.shadowcore-ribbon-item--image').height(iH).width(nW);
				}
				
				$this.height(iH).width(nW);
				sW = parseInt( sW, 10 ) + parseInt( nW, 10 ) + parseInt( this_class.options.spacing, 10 );
			});
			
			if ( 'yes' == this.$el.attr('data-side-spacing') ) {
				sW = sW + parseInt( this_class.options.spacing, 10 )*2;
			}
			
			this.maxStep = Math.floor( -1 * ( sW - this.$el.parent().width() - this_class.options.spacing ) );
			
			this.$el.width(sW);
			
			if (this_class.move.tX < this_class.maxStep) {
				this_class.move.tX = this_class.maxStep;
			}
			if (this_class.move.tX > 0) {
				this_class.move.tX = 0;
			}
			if ( ! this.isAnimated ) {
				this.animate();
			}
		} else {
			this.$el.children('div').each(function() {
				this.style.removeProperty('width');
				this.style.removeProperty('height');
				jQuery(this).children('.shadowcore-ribbon-item--image')[0].style.removeProperty('width');
				jQuery(this).children('.shadowcore-ribbon-item--image')[0].style.removeProperty('height');
			});
			this.$el.css({
				'width': '100%',
				'transform' : 'translate3d(0px, 0px, 0px)'
			});
		}
    }
	loadImage(img) {
		
	}
    init_YT() {
        let this_class = this;
    }
    init_Vimeo() {
        let this_class = this;
    }    
}